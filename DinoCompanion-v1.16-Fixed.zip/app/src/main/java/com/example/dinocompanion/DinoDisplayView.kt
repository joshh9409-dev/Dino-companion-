package com.example.dinocompanion

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.AnimationDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

/**
 * Small floating companion. The WindowManager owns the screen position; this view
 * never changes it. Only the dinosaur artwork animates in place.
 */
class DinoDisplayView(
    context: Context,
    private val state: DinoState,
    private val compact: Boolean = false,
    private val homeMode: Boolean = false,
    private val onAction: ((String) -> Unit)? = null,
    private val onDragPosition: ((Float, Float) -> Unit)? = null,
    private val onOpenMenu: (() -> Unit)? = null,
    private val onHide: (() -> Unit)? = null
) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * density).toInt()

    // A soft contact shadow, placed immediately below the feet rather than as a
    // detached floating oval elsewhere in the overlay.
    private val shadowView = View(context).apply {
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.argb(0, 0, 0, 0),
                Color.argb(95, 35, 25, 15),
                Color.argb(45, 35, 25, 15),
                Color.argb(0, 0, 0, 0)
            )
        ).apply { shape = GradientDrawable.OVAL }
        alpha = 0.78f
        isClickable = false
    }

    private val imageView = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        adjustViewBounds = true
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = false
        isFocusable = false
        clipToOutline = false
        // Software rendering keeps BitmapDrawable filtering and translucent edges
        // consistent on the transparent application-overlay window.
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    private val controls = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(0, dp(2f), 0, dp(2f))
        visibility = GONE
        alpha = 0f
        clipChildren = false
        clipToPadding = false
    }

    private var animation: AnimationDrawable? = null
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var idleScaleX: ObjectAnimator? = null
    private var idleScaleY: ObjectAnimator? = null

    init {
        setWillNotDraw(true)
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
        isFocusable = true
        clipChildren = false
        clipToPadding = false

        // The overlay is deliberately small. The dino occupies the left side and
        // the compact action menu appears beside it, never over the whole screen.
        addView(imageView, LayoutParams(dp(116f), dp(116f)).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = dp(0f)
            topMargin = dp(2f)
        })
        addView(shadowView, LayoutParams(dp(88f), dp(12f)).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = dp(14f)
            topMargin = dp(116f)
        })
        addView(controls, LayoutParams(dp(76f), dp(130f)).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = dp(120f)
            topMargin = dp(8f)
        })

        controls.addView(menuButton("MENU", Color.rgb(71, 161, 91)) { onOpenMenu?.invoke() },
            LinearLayout.LayoutParams(dp(70f), dp(28f)).apply { bottomMargin = dp(4f) })
        controls.addView(menuButton("HIDE", Color.rgb(225, 77, 61)) { onHide?.invoke() },
            LinearLayout.LayoutParams(dp(70f), dp(28f)).apply { bottomMargin = dp(4f) })
        controls.addView(menuButton("INFO", Color.rgb(118, 77, 197)) { showStatus() },
            LinearLayout.LayoutParams(dp(70f), dp(28f)).apply { bottomMargin = dp(4f) })
        controls.addView(menuButton("×", Color.rgb(86, 61, 34), 24f) { hideControls() },
            LinearLayout.LayoutParams(dp(34f), dp(24f)))

        setDinoAnimation()
        startIdleBreathing()
    }

    private fun menuButton(label: String, color: Int, heightText: Float = 28f, click: () -> Unit) =
        TextView(context).apply {
            text = label
            textSize = if (label == "×") 15f else 8f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(lighten(color, .28f), color, darken(color, .20f))
            ).apply {
                cornerRadius = dp(12f).toFloat()
                setStroke(dp(1.2f), Color.argb(235, 255, 255, 255))
            }
            elevation = dp(5f).toFloat()
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }

    private fun lighten(color: Int, amount: Float): Int = Color.rgb(
        (Color.red(color) + (255 - Color.red(color)) * amount).toInt(),
        (Color.green(color) + (255 - Color.green(color)) * amount).toInt(),
        (Color.blue(color) + (255 - Color.blue(color)) * amount).toInt()
    )

    private fun darken(color: Int, amount: Float): Int = Color.rgb(
        (Color.red(color) * (1f - amount)).toInt(),
        (Color.green(color) * (1f - amount)).toInt(),
        (Color.blue(color) * (1f - amount)).toInt()
    )

    private fun stageNumber(): Int = (state.stage + 1).coerceIn(1, 4)

    private fun currentDinoType(): String = state.dinoType

    private fun frameIds(species: String, stage: Int): IntArray {
        val s = stage.coerceIn(1, 4)
        return when (species.lowercase()) {
            "t-rex", "trex" -> when (s) {
                1 -> intArrayOf(R.drawable.trex_stage1_f1, R.drawable.trex_stage1_f2, R.drawable.trex_stage1_f3)
                2 -> intArrayOf(R.drawable.trex_stage2_f1, R.drawable.trex_stage2_f2, R.drawable.trex_stage2_f3)
                3 -> intArrayOf(R.drawable.trex_stage3_f1, R.drawable.trex_stage3_f2, R.drawable.trex_stage3_f3)
                else -> intArrayOf(R.drawable.trex_stage4_f1, R.drawable.trex_stage4_f2, R.drawable.trex_stage4_f3)
            }
            "triceratops" -> when (s) {
                1 -> intArrayOf(R.drawable.triceratops_stage1_f1, R.drawable.triceratops_stage1_f2, R.drawable.triceratops_stage1_f3)
                2 -> intArrayOf(R.drawable.triceratops_stage2_f1, R.drawable.triceratops_stage2_f2, R.drawable.triceratops_stage2_f3)
                3 -> intArrayOf(R.drawable.triceratops_stage3_f1, R.drawable.triceratops_stage3_f2, R.drawable.triceratops_stage3_f3)
                else -> intArrayOf(R.drawable.triceratops_stage4_f1, R.drawable.triceratops_stage4_f2, R.drawable.triceratops_stage4_f3)
            }
            "pterodactyl" -> when (s) {
                1 -> intArrayOf(R.drawable.pterodactyl_stage1_f1, R.drawable.pterodactyl_stage1_f2, R.drawable.pterodactyl_stage1_f3)
                2 -> intArrayOf(R.drawable.pterodactyl_stage2_f1, R.drawable.pterodactyl_stage2_f2, R.drawable.pterodactyl_stage2_f3)
                3 -> intArrayOf(R.drawable.pterodactyl_stage3_f1, R.drawable.pterodactyl_stage3_f2, R.drawable.pterodactyl_stage3_f3)
                else -> intArrayOf(R.drawable.pterodactyl_stage4_f1, R.drawable.pterodactyl_stage4_f2, R.drawable.pterodactyl_stage4_f3)
            }
            else -> when (s) {
                1 -> intArrayOf(R.drawable.stegosaurus_stage1_f1, R.drawable.stegosaurus_stage1_f2, R.drawable.stegosaurus_stage1_f3)
                2 -> intArrayOf(R.drawable.stegosaurus_stage2_f1, R.drawable.stegosaurus_stage2_f2, R.drawable.stegosaurus_stage2_f3)
                3 -> intArrayOf(R.drawable.stegosaurus_stage3_f1, R.drawable.stegosaurus_stage3_f2, R.drawable.stegosaurus_stage3_f3)
                else -> intArrayOf(R.drawable.stegosaurus_stage4_f1, R.drawable.stegosaurus_stage4_f2, R.drawable.stegosaurus_stage4_f3)
            }
        }
    }

    private fun setDinoAnimation() {
        animation?.stop()
        val stage = stageNumber()
        val next = AnimationDrawable().apply {
            isOneShot = false
            frameIds(currentDinoType(), stage).forEach { id ->
                val drawable = resources.getDrawable(id, null)
                if (drawable is BitmapDrawable) {
                    drawable.paint.isAntiAlias = true
                    drawable.paint.isFilterBitmap = true
                    drawable.paint.isDither = true
                }
                // Deliberately slow frame cadence. The frames are used for a gentle
                // tail/body wag, not rapid facial twitching.
                addFrame(drawable, 1500)
            }
        }
        animation = next
        imageView.setImageDrawable(next)
        imageView.animate().cancel()
        imageView.translationX = 0f
        imageView.translationY = 0f
        imageView.rotation = 0f
        imageView.scaleX = 1f
        imageView.scaleY = 1f
        imageView.pivotX = imageView.width / 2f
        imageView.pivotY = imageView.height.toFloat() * .88f
        next.start()
        resizeDinoForStage(stage)
        startIdleBreathing()
    }

    private fun resizeDinoForStage(stage: Int) {
        val size = when (stage) {
            1 -> 82
            2 -> 94
            3 -> 104
            else -> 114
        }
        val lp = imageView.layoutParams
        lp.width = dp(size.toFloat())
        lp.height = dp(size.toFloat())
        lp.leftMargin = dp(6f)
        lp.topMargin = dp((116 - size).coerceAtLeast(2).toFloat())
        imageView.layoutParams = lp
        imageView.pivotX = imageView.width / 2f
        imageView.pivotY = imageView.height.toFloat() * .88f
    }

    private fun startIdleBreathing() {
        idleScaleX?.cancel()
        idleScaleY?.cancel()
        imageView.scaleX = 1f
        imageView.scaleY = 1f
        val x = ObjectAnimator.ofFloat(imageView, View.SCALE_X, 1f, 1.02f).apply {
            duration = 1800L
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        val y = ObjectAnimator.ofFloat(imageView, View.SCALE_Y, 1f, 1.02f).apply {
            duration = 1800L
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        idleScaleX = x
        idleScaleY = y
        x.start()
        y.start()
    }

    fun refresh() {
        val currentTag = "${currentDinoType()}:${stageNumber()}"
        if (imageView.tag != currentTag) {
            imageView.tag = currentTag
            setDinoAnimation()
        }
        animation?.let { if (!it.isRunning) it.start() }
    }

    /** Reactions animate the body only. They never change the WindowManager X/Y anchor. */
    fun showAction(action: String, showStats: Boolean = true) {
        state.currentAction = action
        val baseX = 1f
        val baseY = 1f
        idleScaleX?.cancel()
        idleScaleY?.cancel()
        imageView.animate().cancel()
        when {
            action.contains("Pet", true) || action.contains("petted", true) ->
                imageView.animate().scaleX(1.025f).scaleY(1.025f).setDuration(220)
                    .withEndAction { imageView.animate().scaleX(baseX).scaleY(baseY).setDuration(420).start() }.start()
            action.contains("Eat", true) || action.contains("Eating", true) ->
                imageView.animate().scaleX(1.03f).scaleY(.99f).setDuration(260)
                    .withEndAction { imageView.animate().scaleX(baseX).scaleY(baseY).setDuration(450).start() }.start()
            action.contains("Play", true) ->
                imageView.animate().rotation(2f).setDuration(280)
                    .withEndAction { imageView.animate().rotation(0f).setDuration(500).start() }.start()
            else -> startIdleBreathing()
        }
        postDelayed({ startIdleBreathing() }, if (showStats) 2200L else 2800L)
        onAction?.invoke(action)
    }

    private fun showStatus() {
        Toast.makeText(
            context,
            "${state.name} • Hunger ${state.hunger.toInt()}% • Happy ${state.happiness.toInt()}% • Energy ${state.energy.toInt()}%",
            Toast.LENGTH_SHORT
        ).show()
        hideControls()
    }

    private fun hideControls() {
        controls.animate().cancel()
        controls.animate().alpha(0f).setDuration(90).withEndAction {
            controls.visibility = GONE
        }.start()
    }

    private fun revealControls() {
        controls.visibility = VISIBLE
        controls.animate().cancel()
        controls.animate().alpha(1f).setDuration(130).start()
    }

    private fun controlsContains(x: Float, y: Float): Boolean {
        return controls.visibility == VISIBLE && x >= controls.left && x <= controls.right &&
            y >= controls.top && y <= controls.bottom
    }

    private fun dinoContains(x: Float, y: Float): Boolean {
        return x >= imageView.left - dp(8f) && x <= imageView.right + dp(8f) &&
            y >= imageView.top - dp(8f) && y <= imageView.bottom + dp(8f)
    }

    override fun onDetachedFromWindow() {
        idleScaleX?.cancel()
        idleScaleY?.cancel()
        idleScaleX = null
        idleScaleY = null
        animation?.stop()
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragging && hypot(dx.toDouble(), dy.toDouble()) > dp(7f)) dragging = true
                if (dragging) onDragPosition?.invoke(dx, dy)
                return true
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (dragging) return true

                val x = event.x
                val y = event.y
                if (controlsContains(x, y)) return true

                if (!dinoContains(x, y)) {
                    // Any tap on the transparent area of the compact overlay dismisses
                    // the menu immediately. It never opens a fullscreen popup.
                    if (controls.visibility == VISIBLE) hideControls()
                    return true
                }

                revealControls()
                val now = System.currentTimeMillis()
                if (now - lastTap < 700L) {
                    state.feed(20f)
                    showAction("Eating", false)
                } else {
                    state.pet()
                    showAction("Being petted", false)
                }
                lastTap = now
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }
}
