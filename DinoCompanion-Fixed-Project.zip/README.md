# Dino Companion Beta V0.8

Home screen tuned for portrait phones: system-bar safe layout, compact responsive dinosaur/egg area, visible action labels, and the floating overlay hides while the app home is open so it does not cover the UI.
