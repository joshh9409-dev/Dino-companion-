package com.example.dinocompanion

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var state: DinoState
    private lateinit var root: LinearLayout
    private var dinoView: DinoDisplayView? = null
    private var permissionStep = 0
    private var launchedPermission = false

    private val bg = Color.rgb(7, 24, 19)
    private val panel = Color.rgb(16, 48, 37)
    private val gold = Color.rgb(244, 185, 62)
    private val cream = Color.rgb(248, 242, 220)
    private val green = Color.rgb(91, 180, 91)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        if (!allRequiredPermissionsGranted()) showPermissionWelcome() else {
            startCompanionService()
            showHome()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!::state.isInitialized) return
        if (launchedPermission) {
            launchedPermission = false
            if (!allRequiredPermissionsGranted()) {
                handlerPostPermissionAdvance()
            } else {
                getSharedPreferences("dino_setup", MODE_PRIVATE).edit().putBoolean("done", true).apply()
                showHome()
            }
        }
        state.applyTimeDecay()
        dinoView?.refresh()
    }

    private fun allRequiredPermissionsGranted(): Boolean =
        Settings.canDrawOverlays(this) && hasUsageAccess()

    private fun handlerPostPermissionAdvance() {
        window.decorView.postDelayed({ advancePermissions() }, 250)
    }

    private fun showPermissionWelcome() {
        val outer = FrameLayout(this).apply { setBackgroundDrawable(gradientBg()) }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(16, 12, 16, 96)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val logo = TextView(this).apply {
            text = "🦖\nDINO COMPANION"
            textSize = 34f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 3f, Color.BLACK)
            setPadding(0, 30, 0, 8)
        }
        box.addView(logo, LinearLayout.LayoutParams(-1, -2))

        box.addView(TextView(this).apply {
            text = "A REAL FRIEND. A WILDER WORLD."
            textSize = 15f
            setTextColor(cream)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        })

        val card = TextView(this).apply {
            text = "Your dinosaur can live on your screen, react to what you do, and keep growing while you're away.\n\nWe'll set up the access it needs now. After setup, you won't have permission controls cluttering the game."
            textSize = 16f
            setTextColor(cream)
            setPadding(24, 24, 24, 24)
            background = rounded(panel, 24f)
        }
        box.addView(card, LinearLayout.LayoutParams(-1, -2))
        box.addView(space(20))

        box.addView(TextView(this).apply {
            text = "TWO QUICK STEPS"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        })

        box.addView(TextView(this).apply {
            text = "1. Allow the dinosaur to appear over other apps.\n2. Allow usage access so it can recognise apps such as YouTube, TikTok and games."
            textSize = 14f
            setTextColor(cream)
            setPadding(18, 8, 18, 20)
        })

        box.addView(Space(this), LinearLayout.LayoutParams(1, 40))
        scroll.addView(box, ScrollView.LayoutParams(-1, -2))
        outer.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val start = actionButton("GET STARTED", ::advancePermissions).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = FrameLayout.LayoutParams(-1, 64).apply {
                gravity = Gravity.BOTTOM
                setMargins(20, 8, 20, 20)
            }
        }
        outer.addView(start)

        setContentView(outer)
    }

    private fun advancePermissions() {
        if (!Settings.canDrawOverlays(this)) {
            launchedPermission = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!hasUsageAccess()) {
            launchedPermission = true
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        getSharedPreferences("dino_setup", MODE_PRIVATE).edit().putBoolean("done", true).apply()
        startCompanionService()
        showHome()
    }

    private fun startCompanionService() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, DinoOverlayService::class.java))
        } catch (_: Exception) { }
    }

    private fun showHome() {
        val outer = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(8, 30, 21))
        }
        outer.addView(JungleBackgroundView(this), FrameLayout.LayoutParams(-1, -1))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(18, 8, 18, 18)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "Dino Companion"
            textSize = 35f
            setTextColor(Color.rgb(185, 242, 83))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 4f, Color.rgb(20, 70, 20))
            setPadding(0, 6, 0, 0)
        }
        content.addView(title, LinearLayout.LayoutParams(-1, 58))

        val identity = TextView(this).apply {
            text = "${state.name}  •  ${state.species}  🐾"
            textSize = 24f
            setTextColor(cream)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT
            setShadowLayer(3f, 0f, 2f, Color.BLACK)
        }
        content.addView(identity, LinearLayout.LayoutParams(-1, 38))

        val stage = TextView(this).apply {
            text = "Stage ${state.stage + 1}/4"
            textSize = 20f
            setTextColor(cream)
            gravity = Gravity.CENTER
            setShadowLayer(3f, 0f, 2f, Color.BLACK)
        }
        content.addView(stage, LinearLayout.LayoutParams(-1, 32))
        content.addView(progressBar(state.evolutionProgress()), LinearLayout.LayoutParams(190, 16).apply { setMargins(0, 2, 0, 0) })

        dinoView = DinoDisplayView(this, state, compact = false, homeMode = true)
        content.addView(dinoView, LinearLayout.LayoutParams(-1, 400).apply { setMargins(0, 0, 0, 2) })

        val statsGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statsGrid.addView(statRow(
            statCard("🍖", "Hunger", state.hunger, Color.rgb(79, 208, 75)),
            statCard("❤", "Happiness", state.happiness, Color.rgb(239, 77, 76))
        ))
        statsGrid.addView(statRow(
            statCard("⚡", "Energy", state.energy, Color.rgb(246, 205, 53)),
            statCard("🫧", "Cleanliness", state.cleanliness, Color.rgb(76, 166, 229))
        ))
        statsGrid.addView(statRow(
            statCard("🔗", "Bond", state.bond, Color.rgb(185, 106, 219)),
            statCard("🪙", "Coins", state.coins.toFloat(), gold, 0f, 999f)
        ))
        content.addView(statsGrid, LinearLayout.LayoutParams(-1, 218).apply { setMargins(0, 8, 0, 4) })

        val age = state.evolutionHours()
        val evolution = TextView(this).apply {
            text = if (state.stage >= 3) "Fully evolved!" else "Evolution: ${state.evolutionProgress()}%\nAge: ${String.format("%.1f", age)}h / ${state.requiredHours().toInt()}h"
            textSize = 20f
            setTextColor(cream)
            gravity = Gravity.CENTER
            setShadowLayer(3f, 0f, 2f, Color.BLACK)
            setPadding(0, 6, 0, 4)
        }
        content.addView(evolution, LinearLayout.LayoutParams(-1, 72))

        val reminder = TextView(this).apply {
            text = if (state.stage >= 3) "${state.name} has reached their ultimate form." else "Keep caring for ${state.name}. The clock keeps running even when the app is closed."
            textSize = 15f
            setTextColor(Color.rgb(255, 244, 202))
            gravity = Gravity.CENTER
            setShadowLayer(2f, 0f, 1f, Color.BLACK)
            setPadding(8, 0, 8, 8)
        }
        content.addView(reminder, LinearLayout.LayoutParams(-1, 54))

        content.addView(bigHomeButton("FOOD & CARE", Color.rgb(142, 62, 211)) { showCare() })
        content.addView(bigHomeButton("CHOOSE DINOSAUR", Color.rgb(111, 194, 70)) { showSpeciesPicker() })
        content.addView(bigHomeButton("OVERLAY SETTINGS", Color.rgb(142, 62, 211)) { showMore() })
        content.addView(bigHomeButton("SHOP", Color.rgb(111, 194, 70)) { showShop() })

        val footer = TextView(this).apply {
            text = "Overlay ✓   |   Usage ✓   |   🪙 Coins ${state.coins}"
            textSize = 16f
            setTextColor(cream)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
            setShadowLayer(2f, 0f, 1f, Color.BLACK)
        }
        content.addView(footer, LinearLayout.LayoutParams(-1, 54))

        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        outer.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(outer)
    }

    private fun statRow(left: View, right: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(left, LinearLayout.LayoutParams(0, 68, 1f).apply { setMargins(2, 3, 4, 3) })
        addView(right, LinearLayout.LayoutParams(0, 68, 1f).apply { setMargins(4, 3, 2, 3) })
    }

    private fun statCard(icon: String, label: String, value: Float, barColor: Int, minValue: Float = 0f, maxValue: Float = 100f): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(10, 6, 10, 6)
        background = rounded(Color.argb(215, 89, 57, 34), 18f)

        addView(TextView(this@MainActivity).apply {
            text = icon
            textSize = 23f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(34, -1))

        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "$label: ${if (label == "Coins") value.toInt() else value.toInt().coerceIn(0,100)}${if (label == "Coins") "" else "%"}"
                textSize = 14f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            }, LinearLayout.LayoutParams(-1, 25))
            if (label != "Coins") {
                addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100
                    progress = value.toInt().coerceIn(0, 100)
                    progressDrawable = progressDrawable(barColor)
                }, LinearLayout.LayoutParams(-1, 12))
            }
        }, LinearLayout.LayoutParams(0, -1, 1f))
    }

    private fun progressDrawable(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = 8f
        setColor(color)
    }

    private fun progressBar(percent: Int): View = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100
        progress = percent
        progressDrawable = progressDrawable(Color.rgb(94, 190, 77))
        background = rounded(Color.argb(180, 55, 50, 43), 8f)
    }

    private fun bigHomeButton(text: String, color: Int, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = rounded(color, 32f)
        elevation = 7f
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, 64).apply { setMargins(48, 5, 48, 5) }
    }

    private fun showCare() {
        AlertDialog.Builder(this)
            .setTitle("Care for ${state.name}")
            .setMessage("Hunger ${state.hunger.toInt()}%\nHappiness ${state.happiness.toInt()}%\nEnergy ${state.energy.toInt()}%\nCleanliness ${state.cleanliness.toInt()}%\nBond ${state.bond.toInt()}%")
            .setPositiveButton("FEED") { _, _ -> state.feed(); showHome() }
            .setNeutralButton("PLAY") { _, _ -> state.play(); showHome() }
            .setNegativeButton("CLOSE", null).show()
    }

    private fun showSpeciesPicker() {
        val species = arrayOf("T-Rex", "Triceratops", "Pterodactyl", "Stegosaurus")
        AlertDialog.Builder(this).setTitle("Choose your dinosaur")
            .setItems(species) { _, which ->
                state.species = species[which]
                state.stage = 0
                state.birthTime = System.currentTimeMillis()
                state.freeEvolutionUsed = false
                state.name = defaultNameForSpecies(state.species)
                state.currentAction = ""
                showNamePicker()
            }.show()
    }

    private fun showNamePicker() {
        val input = EditText(this).apply { setSingleLine(true); setText(state.name); selectAll() }
        AlertDialog.Builder(this).setTitle("Name your dinosaur")
            .setMessage("Their name will appear in bold gold above them.")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                input.text.toString().trim().take(18).takeIf { it.isNotBlank() }?.let { state.name = it }
                showHome()
            }.setNegativeButton("CANCEL", null).show()
    }

    private fun showShop() {
        AlertDialog.Builder(this).setTitle("Dino Shop")
            .setMessage("Coins: ${state.coins}\n\nEvolution Food will speed up growth. Premium evolutions can be added here later.")
            .setPositiveButton("OK", null).show()
    }

    private fun showMore() {
        AlertDialog.Builder(this).setTitle("More")
            .setItems(arrayOf("Rename ${state.name}", "Choose dinosaur", "Evolution progress", "About")) { _, which ->
                when (which) {
                    0 -> showNamePicker()
                    1 -> showSpeciesPicker()
                    2 -> showEvolution()
                    else -> AlertDialog.Builder(this).setTitle("Dino Companion").setMessage("Raise • Care • Evolve • Together").setPositiveButton("OK", null).show()
                }
            }.show()
    }

    private fun showEvolution() {
        val p = state.evolutionProgress()
        AlertDialog.Builder(this).setTitle("${state.name} • Stage ${state.stage + 1}/4")
            .setMessage(if (state.stage >= 3) "Fully evolved. This is the ultimate form." else "$p% toward the next evolution. Keep caring for ${state.name}.")
            .setPositiveButton("OK", null).show()
    }

    private fun defaultNameForSpecies(s: String) = when (s) { "Triceratops" -> "Trixie"; "Pterodactyl" -> "Sky"; "Stegosaurus" -> "Steggy"; else -> "Rex" }

    private fun base() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); background = gradientBg() }
    private fun gradientBg() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(6,20,16), Color.rgb(15,55,40), Color.rgb(5,27,21)))
    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun space(h: Int) = Space(this).apply { minimumHeight = h }
    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply { this.text=text; textSize=13f; setTextColor(Color.WHITE); background=rounded(Color.rgb(37,103,66),22f); setOnClickListener{action()}; setPadding(4,2,4,2); layoutParams=LinearLayout.LayoutParams(0,58,1f).apply{setMargins(4,4,4,4)} }
    private fun navButton(text: String, action: () -> Unit) = TextView(this).apply { this.text=text; textSize=12f; typeface=Typeface.DEFAULT_BOLD; setTextColor(gold); gravity=Gravity.CENTER; background=rounded(panel,18f); setPadding(10,12,10,12); setOnClickListener{action()}; layoutParams=LinearLayout.LayoutParams(0,48,1f).apply{setMargins(3,3,3,3)} }
    private fun hasUsageAccess(): Boolean {
        val appOps=getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)==AppOpsManager.MODE_ALLOWED
    }
}
