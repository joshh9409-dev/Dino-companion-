package com.example.dinocompanion

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var state: DinoState
    private lateinit var root: LinearLayout
    private var dinoView: DinoDisplayView? = null
    private var permissionStep = 0
    private var launchedPermission = false

    private val bg = Color.rgb(7, 24, 19)
    private val panel = Color.rgb(16, 48, 37)
    private val gold = Color.rgb(244, 185, 62)
    private val cream = Color.rgb(248, 242, 220)
    private val green = Color.rgb(91, 180, 91)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        if (!allRequiredPermissionsGranted()) showPermissionWelcome() else {
            startCompanionService()
            showHome()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!::state.isInitialized) return
        if (launchedPermission) {
            launchedPermission = false
            if (!allRequiredPermissionsGranted()) {
                handlerPostPermissionAdvance()
            } else {
                getSharedPreferences("dino_setup", MODE_PRIVATE).edit().putBoolean("done", true).apply()
                showHome()
            }
        }
        state.applyTimeDecay()
        dinoView?.refresh()
    }

    private fun allRequiredPermissionsGranted(): Boolean =
        Settings.canDrawOverlays(this) && hasUsageAccess()

    private fun handlerPostPermissionAdvance() {
        window.decorView.postDelayed({ advancePermissions() }, 250)
    }

    private fun showPermissionWelcome() {
        val box = base()
        val logo = TextView(this).apply {
            text = "🦖\nDINO COMPANION"
            textSize = 34f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 3f, Color.BLACK)
            setPadding(0, 36, 0, 8)
        }
        box.addView(logo)
        box.addView(TextView(this).apply {
            text = "A REAL FRIEND. A WILDER WORLD."
            textSize = 15f
            setTextColor(cream)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 30)
        })
        val card = TextView(this).apply {
            text = "Your dinosaur can live on your screen, react to what you do, and keep growing while you're away.\n\nWe'll ask for the two permissions it needs now. You won't need permission controls cluttering the game later."
            textSize = 16f
            setTextColor(cream)
            setPadding(24, 24, 24, 24)
            background = rounded(panel, 24f)
        }
        box.addView(card)
        box.addView(space(18))
        box.addView(actionButton("GET STARTED", ::advancePermissions))
        box.addView(TextView(this).apply {
            text = "Overlay access lets your companion appear over other apps. Usage access lets it recognise apps such as YouTube, TikTok and games."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(12, 20, 12, 8)
        })
        setContentView(box)
    }

    private fun advancePermissions() {
        if (!Settings.canDrawOverlays(this)) {
            launchedPermission = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!hasUsageAccess()) {
            launchedPermission = true
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        getSharedPreferences("dino_setup", MODE_PRIVATE).edit().putBoolean("done", true).apply()
        startCompanionService()
        showHome()
    }

    private fun startCompanionService() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, DinoOverlayService::class.java))
        } catch (_: Exception) { }
    }

    private fun showHome() {
        val r = base()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "DINO\nCOMPANION"
            textSize = 23f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(5f, 0f, 2f, Color.BLACK)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "🪙 ${state.coins}"
            textSize = 17f
            setTextColor(gold)
            gravity = Gravity.CENTER
            background = rounded(panel, 30f)
            setPadding(18, 10, 18, 10)
        })
        r.addView(header)

        r.addView(TextView(this).apply {
            text = "Your companion"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(4, 12, 4, 0)
        })

        dinoView = DinoDisplayView(this, state, compact = false)
        r.addView(dinoView, LinearLayout.LayoutParams(-1, 0, 1f))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(actionButton("🍖\nFEED") { state.feed(); dinoView?.showAction("Eating") })
        actions.addView(actionButton("🎾\nPLAY") { state.play(); dinoView?.showAction("Playing") })
        actions.addView(actionButton("❤️\nPET") { state.pet(); dinoView?.showAction("Being petted") })
        actions.addView(actionButton("😴\nSLEEP") { state.energy = minOf(100f, state.energy + 30f); dinoView?.showAction("Sleeping") })
        r.addView(actions)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        nav.addView(navButton("DINOS") { showSpeciesPicker() })
        nav.addView(navButton("CARE") { showCare() })
        nav.addView(navButton("SHOP") { showShop() })
        nav.addView(navButton("MORE") { showMore() })
        r.addView(nav)
        setContentView(r)
    }

    private fun showCare() {
        AlertDialog.Builder(this)
            .setTitle("Care for ${state.name}")
            .setMessage("Hunger ${state.hunger.toInt()}%\nHappiness ${state.happiness.toInt()}%\nEnergy ${state.energy.toInt()}%\nCleanliness ${state.cleanliness.toInt()}%\nBond ${state.bond.toInt()}%")
            .setPositiveButton("FEED") { _, _ -> state.feed(); showHome() }
            .setNeutralButton("PLAY") { _, _ -> state.play(); showHome() }
            .setNegativeButton("CLOSE", null).show()
    }

    private fun showSpeciesPicker() {
        val species = arrayOf("T-Rex", "Triceratops", "Pterodactyl", "Stegosaurus")
        AlertDialog.Builder(this).setTitle("Choose your dinosaur")
            .setItems(species) { _, which ->
                state.species = species[which]
                state.stage = 0
                state.birthTime = System.currentTimeMillis()
                state.freeEvolutionUsed = false
                state.name = defaultNameForSpecies(state.species)
                state.currentAction = ""
                showNamePicker()
            }.show()
    }

    private fun showNamePicker() {
        val input = EditText(this).apply { setSingleLine(true); setText(state.name); selectAll() }
        AlertDialog.Builder(this).setTitle("Name your dinosaur")
            .setMessage("Their name will appear in bold gold above them.")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                input.text.toString().trim().take(18).takeIf { it.isNotBlank() }?.let { state.name = it }
                showHome()
            }.setNegativeButton("CANCEL", null).show()
    }

    private fun showShop() {
        AlertDialog.Builder(this).setTitle("Dino Shop")
            .setMessage("Coins: ${state.coins}\n\nEvolution Food will speed up growth. Premium evolutions can be added here later.")
            .setPositiveButton("OK", null).show()
    }

    private fun showMore() {
        AlertDialog.Builder(this).setTitle("More")
            .setItems(arrayOf("Rename ${state.name}", "Choose dinosaur", "Evolution progress", "About")) { _, which ->
                when (which) {
                    0 -> showNamePicker()
                    1 -> showSpeciesPicker()
                    2 -> showEvolution()
                    else -> AlertDialog.Builder(this).setTitle("Dino Companion").setMessage("Raise • Care • Evolve • Together").setPositiveButton("OK", null).show()
                }
            }.show()
    }

    private fun showEvolution() {
        val p = state.evolutionProgress()
        AlertDialog.Builder(this).setTitle("${state.name} • Stage ${state.stage + 1}/4")
            .setMessage(if (state.stage >= 3) "Fully evolved. This is the ultimate form." else "$p% toward the next evolution. Keep caring for ${state.name}.")
            .setPositiveButton("OK", null).show()
    }

    private fun defaultNameForSpecies(s: String) = when (s) { "Triceratops" -> "Trixie"; "Pterodactyl" -> "Sky"; "Stegosaurus" -> "Steggy"; else -> "Rex" }

    private fun base() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); background = gradientBg() }
    private fun gradientBg() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(6,20,16), Color.rgb(15,55,40), Color.rgb(5,27,21)))
    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun space(h: Int) = Space(this).apply { minimumHeight = h }
    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply { this.text=text; textSize=13f; setTextColor(Color.WHITE); background=rounded(Color.rgb(37,103,66),22f); setOnClickListener{action()}; setPadding(4,2,4,2); layoutParams=LinearLayout.LayoutParams(0,58,1f).apply{setMargins(4,4,4,4)} }
    private fun navButton(text: String, action: () -> Unit) = TextView(this).apply { this.text=text; textSize=12f; typeface=Typeface.DEFAULT_BOLD; setTextColor(gold); gravity=Gravity.CENTER; background=rounded(panel,18f); setPadding(10,12,10,12); setOnClickListener{action()}; layoutParams=LinearLayout.LayoutParams(0,48,1f).apply{setMargins(3,3,3,3)} }
    private fun hasUsageAccess(): Boolean {
        val appOps=getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)==AppOpsManager.MODE_ALLOWED
    }
}
