package com.example.dinocompanion

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var state: DinoState
    private lateinit var content: LinearLayout
    private var hero: ImageView? = null
    private var goldName: TextView? = null
    private var actionText: TextView? = null

    private val cream = Color.rgb(18, 45, 35)
    private val dark = Color.rgb(238, 245, 224)
    private val gold = Color.rgb(235, 176, 52)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        showHome()
    }

    override fun onResume() {
        super.onResume()
        if (::state.isInitialized) {
            state.applyTimeDecay()
            if (::content.isInitialized) refreshHome()
        }
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(cream)
        setPadding(18, 18, 18, 18)
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 28f
        setTextColor(dark)
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 8, 0, 10)
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 14f
        setOnClickListener { action() }
        setPadding(8, 5, 8, 5)
    }

    private fun statRow(label: String, value: Float): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val t = TextView(this@MainActivity).apply {
            text = "$label  ${value.roundToInt()}%"
            textSize = 16f
            setTextColor(dark)
        }
        addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val b = Button(this@MainActivity).apply {
            text = if (value >= 70) "GOOD" else if (value >= 40) "OK" else "LOW"
            isAllCaps = true
            textSize = 10f
            isEnabled = false
        }
        addView(b)
    }

    private fun showHome() {
        val root = baseLayout()
        root.addView(title("Dino Companion"))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshHome()
    }

    private fun refreshHome() {
        content.removeAllViews()

        val name = TextView(this).apply {
            text = state.name
            textSize = 31f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(5f, 0f, 2f, Color.BLACK)
            setPadding(4, 4, 4, 2)
        }
        goldName = name
        content.addView(name)

        val action = TextView(this).apply {
            text = currentActionLabel()
            textSize = 17f
            setTextColor(dark)
            gravity = Gravity.CENTER
            setPadding(4, 0, 4, 8)
        }
        actionText = action
        content.addView(action)

        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            adjustViewBounds = true
            setImageResource(currentVisual())
            contentDescription = "${state.name}, ${state.species}, stage ${state.stage + 1}"
        }
        hero = image
        content.addView(image, LinearLayout.LayoutParams(-1, 430))

        val stage = TextView(this).apply {
            text = "${state.species} • Stage ${state.stage + 1}/4"
            textSize = 18f
            setTextColor(dark)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(4, 8, 4, 10)
        }
        content.addView(stage)

        content.addView(statRow("Hunger", state.hunger))
        content.addView(statRow("Happiness", state.happiness))
        content.addView(statRow("Energy", state.energy))
        content.addView(statRow("Cleanliness", state.cleanliness))
        content.addView(statRow("Bond", state.bond))

        val hours = state.evolutionHours()
        val required = state.requiredHours()
        content.addView(TextView(this).apply {
            text = if (state.stage >= 3) "ADULT • FULLY EVOLVED" else "Evolution: ${state.evolutionProgress()}%\nAge: ${"%.1f".format(hours)}h / ${"%.0f".format(required)}h"
            textSize = 17f
            setTextColor(gold)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(8, 14, 8, 12)
        })

        if (state.canEvolve()) content.addView(button("EVOLVE NOW", ::evolveDino))

        content.addView(button("FOOD & CARE", ::showCare))
        content.addView(button("RENAME ${state.name}", ::showRenamePicker))
        content.addView(button("CHOOSE DINOSAUR", ::showSpeciesPicker))
        content.addView(button("OVERLAY SETTINGS", ::showOverlaySettings))
        content.addView(button("SHOP", ::showShop))

        content.addView(TextView(this).apply {
            text = "Overlay ${if (Settings.canDrawOverlays(this@MainActivity)) "✓" else "•"}   Usage ${if (hasUsageAccess()) "✓" else "•"}   Coins ${state.coins}"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(dark)
            setPadding(8, 18, 8, 4)
        })
    }

    private fun currentActionLabel(): String {
        val action = state.currentAction
        return if (action.isBlank()) "Idle" else action
    }

    private fun currentVisual(): Int {
        val action = state.currentAction.lowercase()
        return when {
            action.contains("pet") -> R.drawable.char_petting
            action.contains("eat") -> R.drawable.char_eating
            action.contains("play") -> R.drawable.char_playing
            action.contains("youtube") -> R.drawable.char_youtube
            action.contains("tiktok") -> R.drawable.char_tiktok
            action.contains("instagram") -> R.drawable.char_instagram
            action.contains("sleep") -> R.drawable.char_sleeping
            state.species == "T-Rex" && state.stage == 0 -> R.drawable.char_stage1
            state.species == "T-Rex" && state.stage == 1 -> R.drawable.char_stage2
            state.species == "T-Rex" && state.stage == 2 -> R.drawable.char_stage3
            state.species == "T-Rex" && state.stage == 3 -> R.drawable.char_stage4
            state.species == "Triceratops" -> R.drawable.visual_choose
            state.species == "Pterodactyl" -> R.drawable.visual_choose
            state.species == "Stegosaurus" -> R.drawable.visual_choose
            else -> R.drawable.char_idle
        }
    }

    private fun updateVisual() {
        hero?.setImageResource(currentVisual())
        goldName?.text = state.name
        actionText?.text = currentActionLabel()
    }

    private fun showCare() {
        val root = baseLayout()
        root.addView(title("Food & Care"))
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(currentVisual())
        }
        root.addView(image, LinearLayout.LayoutParams(-1, 330))
        root.addView(statRow("Hunger", state.hunger))
        root.addView(statRow("Happiness", state.happiness))
        root.addView(statRow("Energy", state.energy))
        root.addView(statRow("Cleanliness", state.cleanliness))
        root.addView(button("FEED 🍖", { state.feed(20f); state.currentAction = "Eating"; showHome() }))
        root.addView(button("PET ❤️", { state.pet(); state.currentAction = "Being petted"; showHome() }))
        root.addView(button("PLAY 🎾", { state.play(); state.currentAction = "Playing"; showHome() }))
        root.addView(button("CLEAN 🧽", { state.clean(); state.currentAction = "Getting cleaned"; showHome() }))
        root.addView(button("SLEEP 😴", { state.energy = minOf(100f, state.energy + 30f); state.currentAction = "Sleeping"; showHome() }))
        root.addView(button("BACK", ::showHome))
        setContentView(root)
    }

    private fun showRenamePicker() {
        val input = EditText(this).apply {
            hint = "Enter a name"
            setSingleLine(true)
            setText(state.name)
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Rename your dinosaur")
            .setMessage("The chosen name appears in bold gold above your dinosaur.")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                val chosen = input.text.toString().trim().take(18)
                if (chosen.isNotBlank()) state.name = chosen
                state.currentAction = ""
                refreshHome()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showSpeciesPicker() {
        val species = arrayOf("T-Rex", "Triceratops", "Pterodactyl", "Stegosaurus")
        AlertDialog.Builder(this)
            .setTitle("Choose Your Dinosaur")
            .setItems(species) { _, which ->
                state.species = species[which]
                state.stage = 0
                state.birthTime = System.currentTimeMillis()
                state.freeEvolutionUsed = false
                state.name = defaultNameForSpecies(state.species)
                showNamePicker()
            }
            .show()
    }

    private fun showNamePicker() {
        val input = EditText(this).apply {
            hint = "Enter a name"
            setSingleLine(true)
            setText(state.name)
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("What will you call your dinosaur?")
            .setMessage("This becomes the bold gold name above your companion.")
            .setView(input)
            .setPositiveButton("CONTINUE") { _, _ ->
                val chosen = input.text.toString().trim().take(18)
                if (chosen.isNotBlank()) state.name = chosen
                state.currentAction = ""
                refreshHome()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun defaultNameForSpecies(species: String): String = when (species) {
        "Triceratops" -> "Tricky"
        "Pterodactyl" -> "Sky"
        "Stegosaurus" -> "Steggy"
        else -> "Rex"
    }

    private fun evolveDino() {
        if (state.stage >= 3) return
        val next = when (state.stage + 1) { 1 -> "Juvenile"; 2 -> "Young"; else -> "Adult" }
        val costMessage = if (state.stage == 0) "Your first evolution is FREE." else "This evolution is a premium unlock in the release version."
        AlertDialog.Builder(this)
            .setTitle("Evolution ready!")
            .setMessage("${state.name} is ready for the $next stage.\n\n$costMessage")
            .setPositiveButton(if (state.stage == 0) "EVOLVE" else "KEEP IN PROTOTYPE") { _, _ ->
                if (state.stage == 0) { state.evolve(); state.currentAction = "" }
                refreshHome()
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun showShop() {
        AlertDialog.Builder(this)
            .setTitle("Dino Shop")
            .setMessage("Coins: ${state.coins}\n\nEvolution Food will speed up evolution in the release version.\n\nThe second and third evolutions can become paid unlocks.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showOverlaySettings() {
        val root = baseLayout()
        root.addView(title("Dino Overlay"))
        root.addView(TextView(this).apply {
            text = "Your companion can stay above other apps and react to what you are doing.\n\nOverlay: ${if (Settings.canDrawOverlays(this@MainActivity)) "✓ ready" else "needs permission"}\nUsage access: ${if (hasUsageAccess()) "✓ ready" else "needs permission"}"
            textSize = 16f
            setTextColor(dark)
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 20)
        })
        root.addView(button("ALLOW OVERLAY", { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }))
        root.addView(button("ALLOW USAGE ACCESS", { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }))
        root.addView(button("START DINO", ::startCompanion))
        root.addView(button("STOP DINO", { stopService(Intent(this, DinoOverlayService::class.java)) }))
        root.addView(button("BACK", ::showHome))
        setContentView(root)
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun startCompanion() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!hasUsageAccess()) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        ContextCompat.startForegroundService(this, Intent(this, DinoOverlayService::class.java))
    }
}
