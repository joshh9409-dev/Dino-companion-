package com.example.dinocompanion

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var state: DinoState
    private lateinit var status: TextView
    private lateinit var content: LinearLayout

    private val cream = Color.rgb(255, 248, 231)
    private val green = Color.rgb(119, 168, 91)
    private val dark = Color.rgb(48, 71, 42)
    private val orange = Color.rgb(235, 145, 65)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        showHome()
    }

    override fun onResume() {
        super.onResume()
        if (::state.isInitialized) {
            state.applyTimeDecay()
            if (::content.isInitialized) refreshHome()
        }
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(cream)
        setPadding(28, 24, 28, 24)
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 30f
        setTextColor(dark)
        gravity = Gravity.CENTER
        setPadding(0, 12, 0, 12)
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 15f
        setOnClickListener { action() }
        setPadding(8, 6, 8, 6)
    }

    private fun statRow(label: String, value: Float): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val t = TextView(this@MainActivity).apply {
            text = "$label  ${value.roundToInt()}%"
            textSize = 16f
            setTextColor(dark)
        }
        addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val b = Button(this@MainActivity).apply {
            text = if (value >= 70) "GOOD" else if (value >= 40) "OK" else "LOW"
            isAllCaps = true
            textSize = 11f
            isEnabled = false
        }
        addView(b)
    }

    private fun showHome() {
        val root = baseLayout()
        root.addView(title("Dino Companion"))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshHome()
    }

    private fun refreshHome() {
        content.removeAllViews()
        val header = TextView(this).apply {
            text = "${state.name}\n${state.species} • Stage ${state.stage + 1}/4"
            textSize = 21f
            setTextColor(Color.rgb(212, 154, 42))
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 18)
        }
        content.addView(header)

        content.addView(statRow("Hunger", state.hunger))
        content.addView(statRow("Happiness", state.happiness))
        content.addView(statRow("Energy", state.energy))
        content.addView(statRow("Cleanliness", state.cleanliness))
        content.addView(statRow("Bond", state.bond))

        val progress = TextView(this).apply {
            val hours = state.evolutionHours()
            val required = state.requiredHours()
            text = if (state.stage >= 3) {
                "ADULT • fully evolved"
            } else {
                "Evolution: ${state.evolutionProgress()}%\nAge: ${"%.1f".format(hours)}h / ${"%.0f".format(required)}h"
            }
            textSize = 17f
            setTextColor(dark)
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 12)
        }
        content.addView(progress)

        if (state.canEvolve()) {
            content.addView(button("EVOLVE NOW", ::evolveDino))
        } else if (state.stage < 3) {
            content.addView(TextView(this).apply {
                text = "Keep caring for ${state.name}. The clock keeps running even when the app is closed."
                textSize = 14f
                setTextColor(dark)
                gravity = Gravity.CENTER
                setPadding(8, 4, 8, 12)
            })
        }

        content.addView(button("FOOD & CARE", ::showCare))
        content.addView(button("RENAME ${state.name}", ::showRenamePicker))
        content.addView(button("CHOOSE DINOSAUR", ::showSpeciesPicker))
        content.addView(button("OVERLAY SETTINGS", ::showOverlaySettings))
        content.addView(button("SHOP", ::showShop))

        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(dark)
            setPadding(8, 18, 8, 4)
        }
        content.addView(status)
        updateStatus()
    }

    private fun showCare() {
        val root = baseLayout()
        root.addView(title("Care for ${state.name}"))
        root.addView(statRow("Hunger", state.hunger))
        root.addView(statRow("Happiness", state.happiness))
        root.addView(statRow("Energy", state.energy))
        root.addView(statRow("Cleanliness", state.cleanliness))
        root.addView(button("FEED +20", { state.feed(20f); state.currentAction = "Eating"; showCare() }))
        root.addView(button("PET +7", { state.pet(); state.currentAction = "Being petted"; showCare() }))
        root.addView(button("PLAY +15", { state.play(); state.currentAction = "Playing"; showCare() }))
        root.addView(button("CLEAN", { state.clean(); state.currentAction = "Getting cleaned"; showCare() }))
        root.addView(button("BACK", ::showHome))
        setContentView(root)
    }

    private fun showRenamePicker() {
        val input = EditText(this).apply {
            hint = "Enter a name"
            setSingleLine(true)
            setText(state.name)
            selectAll()
            setPadding(32, 8, 32, 8)
        }
        AlertDialog.Builder(this)
            .setTitle("Rename your dinosaur")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                val chosen = input.text.toString().trim().take(18)
                if (chosen.isNotBlank()) state.name = chosen
                state.currentAction = ""
                refreshHome()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showSpeciesPicker() {
        val species = arrayOf("T-Rex", "Triceratops", "Pterodactyl", "Stegosaurus")
        AlertDialog.Builder(this)
            .setTitle("Choose your dinosaur")
            .setItems(species) { _, which ->
                state.species = species[which]
                state.stage = 0
                state.birthTime = System.currentTimeMillis()
                state.freeEvolutionUsed = false
                showNamePicker()
            }
            .show()
    }

    private fun showNamePicker() {
        val input = EditText(this).apply {
            hint = "Enter a name"
            setSingleLine(true)
            setText(state.name)
            selectAll()
            setPadding(32, 8, 32, 8)
        }
        AlertDialog.Builder(this)
            .setTitle("Name your ${state.species}")
            .setMessage("This name will appear above your dinosaur.")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                val chosen = input.text.toString().trim().take(18)
                state.name = if (chosen.isBlank()) defaultNameForSpecies(state.species) else chosen
                state.currentAction = ""
                refreshHome()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun defaultNameForSpecies(species: String): String = when (species) {
        "Triceratops" -> "Tricky"
        "Pterodactyl" -> "Sky"
        "Stegosaurus" -> "Steggy"
        else -> "Rex"
    }

    private fun evolveDino() {
        if (state.stage >= 3) return
        val next = when (state.stage + 1) {
            1 -> "Juvenile"
            2 -> "Young"
            else -> "Adult"
        }
        val costMessage = if (state.stage == 0) {
            "Your first evolution is FREE."
        } else {
            "This evolution is a premium unlock in the release version."
        }
        AlertDialog.Builder(this)
            .setTitle("Evolution ready!")
            .setMessage("${state.name} is ready for the $next stage.\n\n$costMessage")
            .setPositiveButton(if (state.stage == 0) "EVOLVE" else "KEEP IN PROTOTYPE") { _, _ ->
                if (state.stage == 0) state.evolve()
                refreshHome()
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun showShop() {
        AlertDialog.Builder(this)
            .setTitle("Dino Shop")
            .setMessage("Coins: ${state.coins}\n\nEvolution Food\nPremium food will reduce the real-world evolution wait in the release build.\n\nSecond and third evolutions will be paid unlocks using Google Play Billing.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showOverlaySettings() {
        val overlayOk = Settings.canDrawOverlays(this)
        val usageOk = hasUsageAccess()
        val root = baseLayout()
        root.addView(title("Dino Overlay"))
        root.addView(TextView(this).apply {
            text = "Let your dinosaur stay on top of YouTube, TikTok, Instagram and games.\n\nOverlay: ${if (overlayOk) "✓ ready" else "needs permission"}\nUsage access: ${if (usageOk) "✓ ready" else "needs permission"}"
            textSize = 16f
            setTextColor(dark)
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 20)
        })
        root.addView(button("ALLOW OVERLAY", {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }))
        root.addView(button("ALLOW USAGE ACCESS", {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }))
        root.addView(button("START DINO", ::startCompanion))
        root.addView(button("STOP DINO", { stopService(Intent(this, DinoOverlayService::class.java)) }))
        root.addView(button("BACK", ::showHome))
        setContentView(root)
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        val overlayOk = Settings.canDrawOverlays(this)
        val usageOk = hasUsageAccess()
        status.text = "Overlay ${if (overlayOk) "✓" else "•"}   Usage ${if (usageOk) "✓" else "•"}   Coins ${state.coins}"
    }

    private fun startCompanion() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!hasUsageAccess()) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        ContextCompat.startForegroundService(this, Intent(this, DinoOverlayService::class.java))
    }
}
