package com.example.dinocompanion

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.os.*
import android.view.*
import androidx.core.app.NotificationCompat
import java.time.LocalTime
import kotlin.math.max
import kotlin.math.min

class DinoOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var dinoView: DinoView? = null
    private lateinit var state: DinoState
    private val handler = Handler(Looper.getMainLooper())
    private var lastPackage = ""
    private var battery = 100
    private lateinit var layoutParams: WindowManager.LayoutParams

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            battery = intent.getIntExtra("level", battery)
            dinoView?.setBattery(battery)
        }
    }

    override fun onCreate() {
        super.onCreate()
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        createChannel()
        val notification = NotificationCompat.Builder(this, "dino")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Dino Companion is awake")
            .setContentText("Your dinosaur is living on your screen.")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        layoutParams = WindowManager.LayoutParams(
            210, 255,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = state.overlayX
            y = state.overlayY
        }

        dinoView = DinoView(this, state) { x, y ->
            layoutParams.x = x
            layoutParams.y = y
            state.overlayX = x
            state.overlayY = y
            try { windowManager.updateViewLayout(dinoView, layoutParams) } catch (_: Exception) { }
        }
        windowManager.addView(dinoView, layoutParams)

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        handler.post(checkUsage)
    }

    private val checkUsage = object : Runnable {
        override fun run() {
            try {
                state.applyTimeDecay()
                val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
                val now = System.currentTimeMillis()
                val events = usm.queryEvents(now - 3000, now)
                val e = UsageEvents.Event()
                var newest = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) newest = e.packageName
                }
                if (newest.isNotEmpty() && newest != packageName && newest != lastPackage) {
                    lastPackage = newest
                    dinoView?.reactToApp(newest)
                }
                val hour = LocalTime.now().hour
                dinoView?.setLateNight(hour >= 0 && hour < 5)
                dinoView?.refreshStats()
            } catch (_: Exception) { }
            handler.postDelayed(this, 5000)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("dino", "Dino Companion", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(checkUsage)
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) { }
        dinoView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        dinoView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

class DinoView(
    context: Context,
    private val state: DinoState,
    private val onDrag: (Int, Int) -> Unit
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var battery = 100
    private var lateNight = false
    private var message = "Hi! Tap me"
    private var mood = "happy"
    private var bounce = 0f
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    fun setBattery(value: Int) {
        battery = value.coerceIn(0, 100)
        if (battery <= 15) {
            mood = "panic"
            message = "CHARGE ME!"
        }
        invalidate()
    }

    fun setLateNight(value: Boolean) {
        lateNight = value
        if (value && state.energy < 45 && battery > 15) {
            mood = "sleepy"
            message = "Sleepy..."
        }
        invalidate()
    }

    fun refreshStats() {
        state.applyTimeDecay()
        invalidate()
    }

    fun reactToApp(pkg: String) {
        when {
            pkg == "com.google.android.youtube" -> message = "Popcorn time!"
            pkg == "com.instagram.android" -> message = "Still scrolling?"
            pkg == "com.zhiliaoapp.musically" -> message = "TikTok again!"
            pkg.contains("game", ignoreCase = true) -> message = "LET'S PLAY!"
            else -> message = "Where are we going?"
        }
        mood = "happy"
        state.happiness = min(100f, state.happiness + 3f)
        bounce = 1f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        val cx = width / 2f
        val baseY = height * .72f + bounce * -18f

        paint.setShadowLayer(8f, 0f, 5f, 0x55000000)
        paint.color = Color.WHITE
        canvas.drawRoundRect(8f, 8f, width - 8f, 66f, 24f, 24f, paint)
        paint.clearShadowLayer()
        paint.color = Color.rgb(48, 71, 42)
        paint.textSize = 15f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(message, cx, 43f, paint)

        val body = when (state.species) {
            "Triceratops" -> Color.rgb(196, 132, 94)
            "Pterodactyl" -> Color.rgb(115, 146, 184)
            "Stegosaurus" -> Color.rgb(214, 154, 82)
            else -> Color.rgb(119, 168, 91)
        }
        paint.color = body
        canvas.drawOval(cx - 50f, baseY - 62f, cx + 52f, baseY + 34f, paint)
        canvas.drawOval(cx + 24f, baseY - 100f, cx + 82f, baseY - 40f, paint)

        if (state.species == "Pterodactyl") {
            paint.color = body
            canvas.drawPath(Path().apply {
                moveTo(cx - 38f, baseY - 25f); lineTo(cx - 82f, baseY - 60f); lineTo(cx - 50f, baseY - 8f); close()
            }, paint)
            canvas.drawPath(Path().apply {
                moveTo(cx + 35f, baseY - 28f); lineTo(cx + 82f, baseY - 62f); lineTo(cx + 53f, baseY - 4f); close()
            }, paint)
        }

        paint.color = Color.WHITE
        canvas.drawCircle(cx + 54f, baseY - 76f, 13f, paint)
        paint.color = Color.DKGRAY
        canvas.drawCircle(cx + 57f, baseY - 76f, 5.5f, paint)

        paint.color = Color.rgb(244, 196, 84)
        canvas.drawOval(cx + 66f, baseY - 67f, cx + 91f, baseY - 54f, paint)

        paint.color = Color.rgb(92, 139, 70)
        if (state.species == "Stegosaurus") {
            for (i in 0..5) {
                val sx = cx - 30f + i * 16f
                val sy = baseY - 60f - (i % 2) * 4f
                canvas.drawPath(Path().apply {
                    moveTo(sx, sy); lineTo(sx + 8f, sy - 20f); lineTo(sx + 16f, sy); close()
                }, paint)
            }
        } else if (state.species == "Triceratops") {
            paint.color = Color.rgb(232, 220, 190)
            canvas.drawCircle(cx + 24f, baseY - 93f, 8f, paint)
            canvas.drawCircle(cx + 42f, baseY - 98f, 8f, paint)
            canvas.drawPath(Path().apply {
                moveTo(cx + 34f, baseY - 82f); lineTo(cx + 48f, baseY - 70f); lineTo(cx + 32f, baseY - 72f); close()
            }, paint)
        }

        paint.color = when (mood) {
            "panic" -> Color.rgb(220, 70, 70)
            "sleepy" -> Color.rgb(105, 105, 150)
            else -> body
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        canvas.drawCircle(cx, baseY - 30f, 70f, paint)
        paint.style = Paint.Style.FILL

        paint.color = Color.WHITE
        paint.textSize = 11f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("S${state.stage + 1}", cx, height - 10f, paint)

        bounce *= .86f
        if (bounce > .02f) postInvalidateDelayed(16)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                startX = state.overlayX
                startY = state.overlayY
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragging && (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12)) dragging = true
                if (dragging) onDrag(startX + dx.toInt(), startY + dy.toInt())
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) return true
                val now = System.currentTimeMillis()
                if (now - lastTap < 420) {
                    state.feed(20f)
                    message = "Yum!"
                    mood = "happy"
                } else {
                    state.pet()
                    state.energy = max(0f, state.energy - 1.5f)
                    message = "That tickles!"
                    mood = "happy"
                }
                lastTap = now
                bounce = 1f
                invalidate()
                return true
            }
        }
        return true
    }
}
