package com.example.dinocompanion

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import androidx.core.app.NotificationCompat
import java.time.LocalTime
import kotlin.math.max
import kotlin.math.min

class DinoOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var dinoView: DinoView? = null
    private lateinit var state: DinoState
    private val handler = Handler(Looper.getMainLooper())
    private var lastPackage = ""
    private var battery = 100
    private lateinit var layoutParams: WindowManager.LayoutParams

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            battery = intent.getIntExtra("level", battery)
            dinoView?.setBattery(battery)
        }
    }

    override fun onCreate() {
        super.onCreate()
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        createChannel()
        val notification = NotificationCompat.Builder(this, "dino")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Dino Companion is awake")
            .setContentText("Your dinosaur is living on your screen.")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        layoutParams = WindowManager.LayoutParams(
            210, 255,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = state.overlayX
            y = state.overlayY
        }

        dinoView = DinoView(this, state) { x, y ->
            layoutParams.x = x
            layoutParams.y = y
            state.overlayX = x
            state.overlayY = y
            try { windowManager.updateViewLayout(dinoView, layoutParams) } catch (_: Exception) { }
        }
        windowManager.addView(dinoView, layoutParams)

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        handler.post(checkUsage)
    }

    private val checkUsage = object : Runnable {
        override fun run() {
            try {
                state.applyTimeDecay()
                val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
                val now = System.currentTimeMillis()
                val events = usm.queryEvents(now - 3000, now)
                val e = UsageEvents.Event()
                var newest = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) newest = e.packageName
                }
                if (newest.isNotEmpty() && newest != packageName && newest != lastPackage) {
                    lastPackage = newest
                    dinoView?.reactToApp(newest)
                }
                val hour = LocalTime.now().hour
                dinoView?.setLateNight(hour >= 0 && hour < 5)
                dinoView?.refreshStats()
            } catch (_: Exception) { }
            handler.postDelayed(this, 5000)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("dino", "Dino Companion", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(checkUsage)
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) { }
        dinoView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        dinoView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

class DinoView(
    context: Context,
    private val state: DinoState,
    private val onDrag: (Int, Int) -> Unit
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bitmap: Bitmap? = null
    private var battery = 100
    private var lateNight = false
    private var message = ""
    private var actionUntil = 0L
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        message = state.name
        loadVisual()
    }

    private fun visualRes(): Int {
        val action = state.currentAction.lowercase()
        return when {
            action.contains("pet") -> R.drawable.char_petting
            action.contains("eat") -> R.drawable.char_eating
            action.contains("play") -> R.drawable.char_playing
            action.contains("youtube") -> R.drawable.char_youtube
            action.contains("tiktok") -> R.drawable.char_tiktok
            action.contains("instagram") -> R.drawable.char_instagram
            action.contains("sleep") -> R.drawable.char_sleeping
            state.species == "T-Rex" && state.stage == 0 -> R.drawable.char_stage1
            state.species == "T-Rex" && state.stage == 1 -> R.drawable.char_stage2
            state.species == "T-Rex" && state.stage == 2 -> R.drawable.char_stage3
            state.species == "T-Rex" && state.stage == 3 -> R.drawable.char_stage4
            state.species == "Triceratops" -> R.drawable.visual_choose
            state.species == "Pterodactyl" -> R.drawable.visual_choose
            state.species == "Stegosaurus" -> R.drawable.visual_choose
            else -> R.drawable.char_idle
        }
    }

    private fun loadVisual() {
        bitmap = BitmapFactory.decodeResource(resources, visualRes())
        invalidate()
    }

    fun setBattery(value: Int) {
        battery = value.coerceIn(0, 100)
        if (battery <= 15) {
            message = "Charge me!"
            actionUntil = Long.MAX_VALUE
        } else if (actionUntil == Long.MAX_VALUE) {
            message = state.name
            actionUntil = 0L
        }
        invalidate()
    }

    fun setLateNight(value: Boolean) {
        lateNight = value
        if (value && state.energy < 45 && battery > 15) {
            message = "Sleeping"
            actionUntil = Long.MAX_VALUE
        } else if (!value && actionUntil == Long.MAX_VALUE && battery > 15) {
            message = state.name
            actionUntil = 0L
        }
        invalidate()
    }

    fun refreshStats() {
        state.applyTimeDecay()
        if (state.currentAction.isNotBlank() && System.currentTimeMillis() < actionUntil) {
            message = state.currentAction
        } else if (actionUntil != Long.MAX_VALUE) {
            message = state.name
        }
        loadVisual()
    }

    fun reactToApp(pkg: String) {
        message = when {
            pkg == "com.google.android.youtube" -> "Watching YouTube"
            pkg == "com.instagram.android" -> "Scrolling Instagram"
            pkg == "com.zhiliaoapp.musically" -> "Watching TikTok"
            pkg.contains("game", ignoreCase = true) -> "Playing a game"
            else -> "Exploring"
        }
        state.currentAction = message
        actionUntil = System.currentTimeMillis() + 2200L
        state.happiness = min(100f, state.happiness + 3f)
        loadVisual()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        val bg = paint.apply { color = Color.argb(225, 16, 49, 37) }
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 22f, 22f, bg)

        bitmap?.let { b ->
            val dst = RectF(8f, 34f, width - 8f, height - 8f)
            canvas.drawBitmap(b, null, dst, paint)
        }

        paint.color = Color.rgb(235, 176, 52)
        paint.textSize = 18f
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(if (message.isBlank()) state.name else message, width / 2f, 25f, paint)
        paint.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX; downY = event.rawY
                startX = state.overlayX; startY = state.overlayY
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX; val dy = event.rawY - downY
                if (!dragging && (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12)) dragging = true
                if (dragging) {
                    onDrag(startX + dx.toInt(), startY + dy.toInt())
                    message = "Moving me"
                    state.currentAction = message
                    actionUntil = System.currentTimeMillis() + 900L
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) return true
                val now = System.currentTimeMillis()
                if (now - lastTap < 420) {
                    state.feed(20f); message = "Eating"; state.currentAction = message
                } else {
                    state.pet(); message = "Being petted"; state.currentAction = message
                }
                actionUntil = now + 2200L
                lastTap = now
                loadVisual()
                return true
            }
        }
        return true
    }
}
