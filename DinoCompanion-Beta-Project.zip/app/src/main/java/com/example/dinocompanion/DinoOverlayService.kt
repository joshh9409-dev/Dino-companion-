package com.example.dinocompanion

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.time.LocalTime
import kotlin.math.max
import kotlin.math.min

class DinoOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var dinoView: DinoView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastPackage = ""
    private var battery = 100

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            battery = intent.getIntExtra("level", battery)
            dinoView?.setBattery(battery)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = NotificationCompat.Builder(this, "dino")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Dino Companion is awake")
            .setContentText("Your dinosaur is living on your screen.")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        dinoView = DinoView(this).also { view ->
            val params = WindowManager.LayoutParams(
                180, 230,
                if (Build.VERSION.SDK_INT >= 26)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.END
            params.x = 8
            params.y = 170
            windowManager.addView(view, params)
        }

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        handler.post(checkUsage)
    }

    private val checkUsage = object : Runnable {
        override fun run() {
            try {
                val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
                val now = System.currentTimeMillis()
                val events = usm.queryEvents(now - 3000, now)
                val e = UsageEvents.Event()
                var newest = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) newest = e.packageName
                }
                if (newest.isNotEmpty() && newest != packageName && newest != lastPackage) {
                    lastPackage = newest
                    dinoView?.reactToApp(newest)
                }
                val hour = LocalTime.now().hour
                dinoView?.setLateNight(hour >= 0 && hour < 5)
            } catch (_: Exception) { }
            handler.postDelayed(this, 1000)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("dino", "Dino Companion",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(checkUsage)
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        dinoView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        dinoView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

class DinoView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var battery = 100
    private var lateNight = false
    private var message = "Hi! Tap me 🦖"
    private var mood = "happy"
    private var hunger = 78f
    private var energy = 82f
    private var happiness = 85f
    private var taps = 0
    private var bounce = 0f
    private var lastTap = 0L

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    fun setBattery(value: Int) {
        battery = value.coerceIn(0, 100)
        if (battery <= 15) {
            mood = "panic"
            message = "CHARGE ME! 😱"
        }
        invalidate()
    }

    fun setLateNight(value: Boolean) {
        lateNight = value
        if (value && energy < 45) {
            mood = "sleepy"
            message = "It's late... go to bed 😴"
        }
        invalidate()
    }

    fun reactToApp(pkg: String) {
        when {
            pkg == "com.google.android.youtube" -> message = "Popcorn time! 🍿"
            pkg == "com.instagram.android" -> message = "Still scrolling? 👀"
            pkg == "com.zhiliaoapp.musically" -> message = "TikTok again?! 😂"
            pkg.contains("game", ignoreCase = true) -> message = "LET'S PLAY! 🎮"
            else -> message = "Where are we going?"
        }
        happiness = min(100f, happiness + 3)
        bounce = 1f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        val cx = width / 2f
        val baseY = height * .72f + bounce * -18f

        paint.setShadowLayer(8f, 0f, 5f, 0x55000000)
        paint.color = Color.WHITE
        canvas.drawRoundRect(8f, 8f, width - 8f, 63f, 22f, 22f, paint)
        paint.clearShadowLayer()

        paint.color = Color.rgb(48, 71, 42)
        paint.textSize = 15f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(message, cx, 41f, paint)

        // Cute illustrated dinosaur, deliberately original but guided by the user's reference proportions.
        paint.color = Color.rgb(119, 168, 91)
        canvas.drawOval(cx - 45f, baseY - 62f, cx + 48f, baseY + 30f, paint)
        canvas.drawOval(cx + 27f, baseY - 92f, cx + 79f, baseY - 42f, paint)

        paint.color = Color.rgb(85, 126, 65)
        val legY = baseY + 25f
        canvas.drawRoundRect(cx - 34f, legY - 4f, cx - 13f, legY + 38f, 10f, 10f, paint)
        canvas.drawRoundRect(cx + 10f, legY - 4f, cx + 31f, legY + 38f, 10f, 10f, paint)

        paint.color = Color.WHITE
        canvas.drawCircle(cx + 53f, baseY - 69f, 12f, paint)
        paint.color = Color.DKGRAY
        canvas.drawCircle(cx + 56f, baseY - 69f, 5f, paint)

        paint.color = Color.rgb(244, 196, 84)
        canvas.drawOval(cx + 65f, baseY - 61f, cx + 88f, baseY - 51f, paint)

        paint.color = Color.rgb(92, 139, 70)
        for (i in 0..3) {
            val sx = cx - 18f + i * 15f
            val sy = baseY - 50f - i * 5f
            canvas.drawPath(Path().apply {
                moveTo(sx, sy); lineTo(sx + 7f, sy - 18f); lineTo(sx + 14f, sy); close()
            }, paint)
        }

        // State-specific visual cue.
        paint.color = when (mood) {
            "panic" -> Color.rgb(220, 70, 70)
            "sleepy" -> Color.rgb(105, 105, 150)
            else -> Color.rgb(119, 168, 91)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        canvas.drawCircle(cx, baseY - 30f, 66f, paint)
        paint.style = Paint.Style.FILL

        bounce *= .86f
        if (bounce > .02f) postInvalidateDelayed(16)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val now = System.currentTimeMillis()
        if (now - lastTap < 420) {
            hunger = min(100f, hunger + 24f)
            happiness = min(100f, happiness + 8f)
            message = "Yum! 🍎"
            mood = "happy"
        } else {
            happiness = min(100f, happiness + 10f)
            energy = max(0f, energy - 2f)
            message = "Hehe, that tickles!"
        }
        lastTap = now
        bounce = 1f
        invalidate()
        return true
    }
}
