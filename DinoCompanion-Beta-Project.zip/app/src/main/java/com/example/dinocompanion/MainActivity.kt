package com.example.dinocompanion

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
        }

        val title = TextView(this).apply {
            text = "🦖 Dino Companion"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "\nYour dinosaur lives over your other apps.\n\nGive it overlay + usage access, then start it."
            textSize = 17f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
        }

        val overlay = Button(this).apply {
            text = "1. Allow overlay"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }

        val usage = Button(this).apply {
            text = "2. Allow app usage access"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }

        val start = Button(this).apply {
            text = "3. Start Dino"
            setOnClickListener { startCompanion() }
        }

        val stop = Button(this).apply {
            text = "Stop Dino"
            setOnClickListener { stopService(Intent(this@MainActivity, DinoOverlayService::class.java)) }
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(status)
        layout.addView(overlay)
        layout.addView(usage)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun updateStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val usageOk = hasUsageAccess()
        status.text = "Overlay: ${if (overlayOk) "✓" else "not allowed"}   •   App usage: ${if (usageOk) "✓" else "not allowed"}"
    }

    private fun startCompanion() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        if (!hasUsageAccess()) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        ContextCompat.startForegroundService(this, Intent(this, DinoOverlayService::class.java))
    }
}
