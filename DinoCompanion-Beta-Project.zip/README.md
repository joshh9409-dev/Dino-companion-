# Dino Companion Beta

Android prototype for a Tamagotchi-style dinosaur that floats over other apps.

## Current MVP
- Floating Android overlay companion
- Tap to pet
- Double-tap to feed
- Hunger, energy and happiness state
- Real battery level reaction
- Late-night reaction
- Foreground-app reaction using Android Usage Access
- Persistent foreground service notification
- Original canvas-drawn dinosaur placeholder designed around the supplied dinosaur reference

## Build
Open the project in Android Studio with Android SDK 35 installed. Let Android Studio sync Gradle, then run the `app` configuration on an Android device.

## First-run permissions
1. Allow "Display over other apps".
2. Allow "Usage access".
3. Start Dino.

## Next development targets
- Replace the placeholder drawing with a sprite/animation system.
- Add infant → juvenile → youngster → adolescent → adult growth.
- Add save/load pet state.
- Add food inventory, coins and unlockable species.
- Add species-specific personalities and app reactions.
- Add a proper interaction bubble/menu for feed, play, sleep and treats.


## Free phone-only build

The repository includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
After uploading the project to GitHub, the workflow builds a debug APK and stores it as an Actions artifact.

This project expects a Gradle wrapper (`gradlew` plus the `gradle/wrapper` directory). If Android Studio is not available to generate it, use the Gradle wrapper files from a normal Gradle-generated Android project, or generate them once with a free browser/Android build environment before running the workflow.
