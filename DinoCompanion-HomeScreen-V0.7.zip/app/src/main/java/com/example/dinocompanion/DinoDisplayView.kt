package com.example.dinocompanion

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class DinoDisplayView(
    context: Context,
    private val state: DinoState,
    private val compact: Boolean = false,
    private val homeMode: Boolean = false,
    private val onAction: ((String) -> Unit)? = null,
    private val onDragPosition: ((Float, Float) -> Unit)? = null
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var statsUntil = 0L
    private var reactionUntil = 0L
    private var reaction = ""
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var lastTap = 0L
    private var emotion = "Happy"

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isClickable = true
    }

    fun showAction(action: String, showStats: Boolean = true) {
        reaction = action
        reactionUntil = System.currentTimeMillis() + 2200L
        if (showStats) statsUntil = System.currentTimeMillis() + 2000L
        state.currentAction = action
        emotion = emotionFor(action)
        invalidate()
        postDelayed({
            if (System.currentTimeMillis() >= reactionUntil) {
                reaction = ""
                state.currentAction = ""
                emotion = emotionFor("")
                invalidate()
            }
        }, 2250L)
    }

    fun refresh() { invalidate() }

    private fun emotionFor(action: String): String = when {
        action.contains("Pet", true) -> "Blissful"
        action.contains("Eat", true) -> "Excited"
        action.contains("Play", true) -> "Playful"
        action.contains("Sleep", true) -> "Sleepy"
        action.contains("YouTube", true) -> "Curious"
        action.contains("TikTok", true) -> "Amused"
        action.contains("Instagram", true) -> "Interested"
        action.contains("Move", true) -> "Adventurous"
        action.contains("Charge", true) -> "Worried"
        else -> when {
            state.happiness >= 80 -> "Happy"
            state.energy < 30 -> "Tired"
            state.hunger < 25 -> "Hungry"
            state.cleanliness < 30 -> "Grubby"
            else -> "Curious"
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        phase += 0.075f
        val now = System.currentTimeMillis()
        val bob = sin(phase) * if (compact) 3.5f else 6f
        val sway = sin(phase * 0.63f) * 3.0f
        val reacting = now < reactionUntil
        val pulse = if (reacting) 1f + sin(phase * 2.2f) * 0.035f else 1f

        val cx = width / 2f + sway
        val cy = if (compact) height * 0.64f + bob else height * 0.55f + bob
        val scale = min(width / 220f, height / 250f).coerceAtLeast(0.45f) * pulse

        canvas.save()
        canvas.translate(cx, cy)
        canvas.scale(scale, scale)
        if (homeMode) drawEgg(canvas, state.stage)
        if (reacting && reaction.contains("pett", true)) canvas.rotate(sin(phase * 3f) * 4f)
        drawDino(canvas, state.species, state.stage)
        canvas.restore()

        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = if (compact) 16f else 30f
        paint.color = Color.rgb(240, 185, 62)
        paint.setShadowLayer(5f, 0f, 2f, Color.BLACK)
        canvas.drawText(state.name, width / 2f, if (compact) 23f else 43f, paint)
        paint.clearShadowLayer()

        paint.typeface = Typeface.DEFAULT
        paint.textSize = if (compact) 12f else 16f
        paint.color = Color.WHITE
        canvas.drawText(emotion, width / 2f, if (compact) 40f else 66f, paint)

        if (now < statsUntil) drawStats(canvas)
        if (now < reactionUntil && reaction.isNotBlank()) {
            paint.textSize = if (compact) 11f else 15f
            paint.color = Color.rgb(255, 244, 190)
            canvas.drawText(reaction, width / 2f, height - if (compact) 8f else 18f, paint)
        }

        postInvalidateDelayed(16L)
    }

    private fun drawStats(canvas: Canvas) {
        val left = if (compact) 8f else 22f
        val right = width.toFloat() - if (compact) 8f else 22f
        val top = if (compact) height - 72f else height - 140f
        val row = if (compact) 13f else 24f
        val values = listOf(state.hunger, state.happiness, state.energy, state.cleanliness, state.bond)
        val labels = listOf("Hunger", "Happy", "Energy", "Clean", "Bond")
        for (i in values.indices) {
            val y = top + i * row
            paint.color = 0xCC101C18.toInt()
            canvas.drawRoundRect(left, y - 8f, right, y + 9f, 8f, 8f, paint)
            paint.color = when (i) { 0 -> Color.rgb(242,92,82); 1 -> Color.rgb(246,190,54); 2 -> Color.rgb(54,166,226); 3 -> Color.rgb(79,194,101); else -> Color.rgb(178,77,220) }
            val barLeft = left + if (compact) 42f else 58f
            val barRight = barLeft + (right - barLeft - if (compact) 25f else 38f) * values[i] / 100f
            canvas.drawRoundRect(barLeft, y - 5f, barRight, y + 5f, 5f, 5f, paint)
            paint.color = Color.WHITE
            paint.textAlign = Paint.Align.LEFT
            paint.textSize = if (compact) 8f else 11f
            canvas.drawText(labels[i], left + 5f, y + 3f, paint)
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("${values[i].roundToInt()}%", right - 5f, y + 3f, paint)
        }
        paint.textAlign = Paint.Align.CENTER
    }

    private fun drawEgg(c: Canvas, stage: Int) {
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(238, 225, 190)
        val egg = Path().apply {
            moveTo(-92f, 72f)
            cubicTo(-122f, 24f, -110f, -72f, -58f, -116f)
            cubicTo(-18f, -150f, 34f, -146f, 72f, -100f)
            cubicTo(116f, -47f, 112f, 40f, 74f, 82f)
            cubicTo(35f, 116f, -55f, 112f, -92f, 72f)
            close()
        }
        c.drawPath(egg, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        paint.color = Color.rgb(207, 189, 147)
        c.drawPath(egg, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(157, 104, 207)
        val spots = listOf(
            -62f to -72f, 22f to -102f, 66f to -43f,
            -78f to 4f, 72f to 25f, -38f to 65f, 20f to 58f
        )
        for ((x, y) in spots) c.drawOval(x - 12f, y - 8f, x + 12f, y + 8f, paint)
        if (stage >= 1) {
            paint.color = Color.rgb(184, 118, 61)
            c.drawCircle(-48f, -22f, 7f, paint)
            c.drawCircle(43f, 10f, 6f, paint)
        }
    }

    private fun drawDino(c: Canvas, species: String, stage: Int) {
        when (species) {
            "Triceratops" -> drawTriceratops(c, stage)
            "Pterodactyl" -> drawPtero(c, stage)
            "Stegosaurus" -> drawStego(c, stage)
            else -> drawTRex(c, stage)
        }
    }

    private fun drawTRex(c: Canvas, s: Int) {
        val k = 1f + s * .18f
        val body = when (s) { 0 -> Color.rgb(231,92,61); 1 -> Color.rgb(221,75,48); 2 -> Color.rgb(190,61,42); else -> Color.rgb(119,38,34) }
        val belly = Color.rgb(249,207,151)
        paint.style = Paint.Style.FILL
        paint.color = body
        c.drawOval(-70f*k, -20f*k, 48f*k, 60f*k, paint)
        c.drawOval(10f*k, -110f*k, 82f*k, -36f*k, paint)
        c.drawOval(-74f*k, 38f*k, -36f*k, 98f*k, paint)
        c.drawOval(10f*k, 38f*k, 48f*k, 98f*k, paint)
        paint.color = belly
        c.drawOval(-38f*k, -4f*k, 20f*k, 58f*k, paint)
        c.drawOval(24f*k, -91f*k, 68f*k, -48f*k, paint)
        paint.color = body
        c.drawOval(-18f*k, 0f, 12f*k, 34f*k, paint)
        paint.color = Color.WHITE
        c.drawCircle(55f*k, -75f*k, 14f*k, paint)
        paint.color = Color.rgb(38,25,20)
        c.drawCircle(59f*k, -76f*k, 6f*k, paint)
        paint.color = Color.rgb(244,185,51)
        c.drawOval(73f*k, -69f*k, 94f*k, -59f*k, paint)
        paint.color = Color.rgb(245,238,213)
        for (i in 0..5) {
            val x = 34f*k + i*8f*k
            val path = Path(); path.moveTo(x, -48f*k); path.lineTo(x+4f*k, -38f*k); path.lineTo(x+8f*k, -48f*k); path.close(); c.drawPath(path, paint)
        }
        paint.color = Color.rgb(38,25,20)
        for (x in listOf(-64f,-28f,24f)) c.drawOval(x*k, 84f*k, (x+11f)*k, 99f*k, paint)
        if (s >= 2) {
            paint.color = Color.rgb(85,24,28)
            for (i in 0..5) { val x=-42f+i*14f; val p=Path(); p.moveTo(x*k,-28f*k);p.lineTo((x+7)*k,-47f*k);p.lineTo((x+14)*k,-28f*k);p.close();c.drawPath(p,paint) }
        }
        if (s == 3) {
            paint.color = Color.rgb(238,151,54)
            for (i in 0..3) { val x=-45f+i*24f; c.drawCircle(x*k,-12f*k,5f*k,paint) }
        }
    }

    private fun drawTriceratops(c: Canvas, s: Int) {
        val k=1f+s*.16f; val green=Color.rgb(106,160,92); val dark=Color.rgb(57,105,66); val horn=Color.rgb(235,202,126)
        paint.color=green; c.drawOval(-78*k,-25*k,62*k,62*k,paint); c.drawOval(22*k,-78*k,92*k,-18*k,paint)
        paint.color=Color.rgb(199,218,144); c.drawOval(36*k,-65*k,84*k,-26*k,paint)
        paint.color=horn; c.drawPath(Path().apply{moveTo(48*k,-55*k);lineTo(26*k,-102*k);lineTo(58*k,-60*k);close()},paint); c.drawPath(Path().apply{moveTo(72*k,-54*k);lineTo(96*k,-98*k);lineTo(82*k,-50*k);close()},paint)
        paint.color=Color.WHITE;c.drawCircle(66*k,-48*k,10*k,paint);paint.color=Color.DKGRAY;c.drawCircle(69*k,-48*k,4*k,paint)
        paint.color=dark; for(x in listOf(-55f,-15f,28f)) c.drawRoundRect(x*k,45*k,(x+18)*k,92*k,8*k,8*k,paint)
        if(s>=1){paint.color=Color.rgb(73,119,76); for(i in 0..4){val x=-55+i*22;val p=Path();p.moveTo(x*k,-25*k);p.lineTo((x+10)*k,-50*k);p.lineTo((x+20)*k,-25*k);p.close();c.drawPath(p,paint)}}
        if(s==3){paint.color=Color.rgb(61,86,79);c.drawOval(-72*k,-18*k,5*k,42*k,paint)}
    }

    private fun drawPtero(c: Canvas, s: Int) {
        val k=1f+s*.18f; val body=Color.rgb(67,103,145); val wing=Color.rgb(220,134,76)
        paint.color=body; c.drawOval(-18*k,-15*k,42*k,56*k,paint); c.drawOval(25*k,-88*k,74*k,-35*k,paint)
        paint.color=Color.rgb(238,200,151); c.drawOval(42*k,-76*k,67*k,-45*k,paint)
        paint.color=Color.rgb(233,184,75); c.drawPath(Path().apply{moveTo(62*k,-61*k);lineTo(110*k,-55*k);lineTo(63*k,-51*k);close()},paint)
        paint.color=wing
        val left=Path(); left.moveTo(12*k,-28*k);left.cubicTo(-65*k,-90*k,-105*k,-55*k,-118*k,-5*k);left.cubicTo(-66*k,-22*k,-36*k,-5*k,5*k,18*k);left.close();c.drawPath(left,paint)
        val right=Path();right.moveTo(30*k,-28*k);right.cubicTo(92*k,-98*k,128*k,-62*k,137*k,-8*k);right.cubicTo(91*k,-22*k,65*k,-2*k,36*k,18*k);right.close();c.drawPath(right,paint)
        paint.color=body;c.drawOval(-2*k,45*k,16*k,83*k,paint);c.drawOval(28*k,45*k,46*k,83*k,paint)
        if(s>=2){paint.color=Color.rgb(48,72,104);c.drawPath(Path().apply{moveTo(26*k,-86*k);lineTo(44*k,-116*k);lineTo(55*k,-86*k);close()},paint)}
        if(s==3){paint.color=Color.rgb(245,177,68);for(x in listOf(-72f,-25f,74f,113f))c.drawCircle(x*k,-15*k,4*k,paint)}
    }

    private fun drawStego(c: Canvas, s: Int) {
        val k=1f+s*.16f; val body=Color.rgb(111,153,91); val plate=if(s==3)Color.rgb(74,145,171) else Color.rgb(208,75,74)
        paint.color=body;c.drawOval(-85*k,-25*k,66*k,65*k,paint);c.drawOval(48*k,-58*k,92*k,-10*k,paint)
        paint.color=Color.rgb(204,221,151);c.drawOval(55*k,-48*k,86*k,-20*k,paint)
        paint.color=plate
        for(i in 0..7){val x=-62+i*18;val h=if(s==3)30f else 20f;val p=Path();p.moveTo((x-7)*k,-15*k);p.lineTo(x*k,(-15-h)*k);p.lineTo((x+8)*k,-15*k);p.close();c.drawPath(p,paint)}
        paint.color=body; for(x in listOf(-62f,-20f,24f))c.drawRoundRect(x*k,45*k,(x+18)*k,92*k,8*k,8*k,paint)
        paint.color=Color.rgb(39,49,43);c.drawCircle(78*k,-36*k,5*k,paint)
        if(s==3){paint.color=Color.rgb(62,95,120);for(x in listOf(-70f,-35f,0f,35f,70f)){c.drawCircle(x*k,58*k,6*k,paint)}}
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when(event.actionMasked){
            MotionEvent.ACTION_DOWN->{downX=event.rawX;downY=event.rawY;dragging=false;return true}
            MotionEvent.ACTION_MOVE->{
                val dx=event.rawX-downX;val dy=event.rawY-downY
                if(!dragging && hypot(dx.toDouble(),dy.toDouble())>14) dragging=true
                if(dragging){onDragPosition?.invoke(dx,dy);showAction("Moving me",false)}
                return true
            }
            MotionEvent.ACTION_UP->{
                if(dragging)return true
                val now=System.currentTimeMillis()
                if(now-lastTap<420){state.feed(20f);showAction("Eating",true)}else{state.pet();showAction("Being petted",true)}
                lastTap=now;onAction?.invoke(reaction);return true
            }
        }
        return true
    }
}
