package com.example.dinocompanion

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private lateinit var state: DinoState
    private var permissionStep = 0
    private var launchedPermission = false

    private val gold = Color.rgb(226, 158, 40)
    private val cream = Color.rgb(92, 70, 37)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        if (!allRequiredPermissionsGranted()) showPermissionWelcome() else {
            startCompanionService()
            showHome()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!::state.isInitialized) return
        if (launchedPermission) {
            launchedPermission = false
            if (!allRequiredPermissionsGranted()) {
                window.decorView.postDelayed({ advancePermissions() }, 250)
            } else {
                getSharedPreferences("dino_setup", MODE_PRIVATE).edit().putBoolean("done", true).apply()
                startCompanionService()
                showHome()
            }
        }
        state.applyTimeDecay()
    }

    private fun allRequiredPermissionsGranted(): Boolean =
        Settings.canDrawOverlays(this) && hasUsageAccess()

    private fun showPermissionWelcome() {
        val root = FrameLayout(this).apply { background = permissionBackground() }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(18, 18, 18, 110)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        box.addView(TextView(this).apply {
            text = "🦖\nDINO COMPANION"
            textSize = 34f
            setTextColor(Color.rgb(255, 191, 48))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 3f, Color.rgb(80, 45, 10))
            setPadding(0, 28, 0, 8)
        }, LinearLayout.LayoutParams(-1, -2))
        box.addView(TextView(this).apply {
            text = "A REAL FRIEND. A WILDER WORLD."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }, LinearLayout.LayoutParams(-1, -2))
        box.addView(TextView(this).apply {
            text = "Your dinosaur can live on your screen, react to what you do, and keep growing while you're away.\n\nWe'll set up the access it needs now. You won't need permission controls cluttering the game later."
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(24, 24, 24, 24)
            background = rounded(Color.argb(150, 30, 85, 60), 26f)
        }, LinearLayout.LayoutParams(-1, -2))
        box.addView(TextView(this).apply {
            text = "TWO QUICK STEPS\n\n1. Allow the dinosaur to appear over other apps.\n2. Allow usage access so it can recognise apps such as YouTube, TikTok and games."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(18, 24, 18, 20)
        }, LinearLayout.LayoutParams(-1, -2))
        scroll.addView(box)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        root.addView(Button(this).apply {
            text = "GET STARTED"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(83, 176, 82), 34f)
            elevation = 8f
            setOnClickListener { advancePermissions() }
            layoutParams = FrameLayout.LayoutParams(-1, dp(58)).apply {
                gravity = Gravity.BOTTOM
                setMargins(dp(16), dp(8), dp(16), dp(18))
            }
        })
        setContentView(root)
    }

    private fun advancePermissions() {
        if (!Settings.canDrawOverlays(this)) {
            launchedPermission = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!hasUsageAccess()) {
            launchedPermission = true
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        getSharedPreferences("dino_setup", MODE_PRIVATE).edit().putBoolean("done", true).apply()
        startCompanionService()
        showHome()
    }

    private fun startCompanionService() {
        try { ContextCompat.startForegroundService(this, Intent(this, DinoOverlayService::class.java)) } catch (_: Exception) {}
    }

    private fun showHome() {
        state.applyTimeDecay()
        val home = HomeArtworkView(
            this,
            onFoodCare = { showCare() },
            onRename = { showNamePicker() },
            onChoose = { showSpeciesPicker() },
            onOverlaySettings = { showOverlaySettings() },
            onShop = { showShop() }
        )
        setContentView(home)
    }

    private fun showCare() {
        AlertDialog.Builder(this)
            .setTitle("Care for ${state.name}")
            .setMessage("Hunger ${state.hunger.toInt()}%\nHappiness ${state.happiness.toInt()}%\nEnergy ${state.energy.toInt()}%\nCleanliness ${state.cleanliness.toInt()}%\nBond ${state.bond.toInt()}%")
            .setPositiveButton("FEED") { _, _ -> state.feed(); showHome() }
            .setNeutralButton("PLAY") { _, _ -> state.play(); showHome() }
            .setNegativeButton("PET") { _, _ -> state.pet(); showHome() }
            .show()
    }

    private fun showSpeciesPicker() {
        val species = arrayOf("T-Rex", "Triceratops", "Pterodactyl", "Stegosaurus")
        AlertDialog.Builder(this).setTitle("Choose your dinosaur")
            .setItems(species) { _, which ->
                state.species = species[which]
                state.stage = 0
                state.birthTime = System.currentTimeMillis()
                state.freeEvolutionUsed = false
                state.name = defaultNameForSpecies(state.species)
                state.currentAction = ""
                showNamePicker()
            }.show()
    }

    private fun showNamePicker() {
        val input = EditText(this).apply { setSingleLine(true); setText(state.name); selectAll() }
        AlertDialog.Builder(this).setTitle("Name your dinosaur")
            .setMessage("Their name will appear in bold gold above them.")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                input.text.toString().trim().take(18).takeIf { it.isNotBlank() }?.let { state.name = it }
                showHome()
            }.setNegativeButton("CANCEL", null).show()
    }

    private fun showOverlaySettings() {
        AlertDialog.Builder(this)
            .setTitle("Overlay Settings")
            .setItems(arrayOf("Reset Dino position", "Show evolution progress", "Close")) { _, which ->
                when (which) {
                    0 -> { state.overlayX = 8; state.overlayY = 170; Toast.makeText(this, "Dino position reset", Toast.LENGTH_SHORT).show() }
                    1 -> showEvolution()
                }
            }.show()
    }

    private fun showShop() {
        AlertDialog.Builder(this).setTitle("Dino Shop")
            .setMessage("Coins: ${state.coins}\n\nEvolution Food can speed up growth. Premium evolution purchases can be connected to Google Play Billing later.")
            .setPositiveButton("OK", null).show()
    }

    private fun showEvolution() {
        val p = state.evolutionProgress()
        AlertDialog.Builder(this).setTitle("${state.name} • Stage ${state.stage + 1}/4")
            .setMessage(if (state.stage >= 3) "Fully evolved. This is the ultimate form." else "$p% toward the next evolution. Keep caring for ${state.name}.")
            .setPositiveButton("OK", null).show()
    }

    private fun defaultNameForSpecies(s: String) = when (s) {
        "Triceratops" -> "Trixie"
        "Pterodactyl" -> "Sky"
        "Stegosaurus" -> "Steggy"
        else -> "Rex"
    }

    private fun permissionBackground() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(8, 53, 38), Color.rgb(20, 98, 67), Color.rgb(5, 37, 28)))
    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
}
