package com.example.dinocompanion

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

class HomeArtworkView(
    context: Context,
    private val onFoodCare: () -> Unit,
    private val onRename: () -> Unit,
    private val onChoose: () -> Unit,
    private val onOverlaySettings: () -> Unit,
    private val onShop: () -> Unit
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.home_reference)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val dst = RectF(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawBitmap(bitmap, null, dst, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_UP || width <= 0 || height <= 0) return true

        // Hit targets are based on the supplied 1024 x 1536 home artwork.
        val x = event.x / width.toFloat() * 1024f
        val y = event.y / height.toFloat() * 1536f

        fun hit(cx: Float, cy: Float, r: Float): Boolean = hypot(x - cx, y - cy) <= r

        when {
            hit(205f, 1058f, 145f) -> onFoodCare()
            hit(512f, 1058f, 145f) -> onRename()
            hit(817f, 1058f, 145f) -> onChoose()
            hit(360f, 1282f, 145f) -> onOverlaySettings()
            hit(666f, 1282f, 145f) -> onShop()
        }
        return true
    }
}
