package com.example.dinocompanion

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.sin

class JungleBackgroundView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()

        val sky = LinearGradient(0f, 0f, 0f, h * .62f,
            intArrayOf(Color.rgb(190, 224, 207), Color.rgb(116, 177, 128), Color.rgb(54, 104, 64)),
            null, Shader.TileMode.CLAMP)
        p.shader = sky
        c.drawRect(0f, 0f, w, h * .68f, p)
        p.shader = null

        p.color = Color.argb(55, 255, 248, 210)
        c.drawCircle(w * .53f, h * .22f, w * .28f, p)

        drawPalm(c, w * .03f, h * .10f, 1.05f, false)
        drawPalm(c, w * .92f, h * .12f, 1.12f, true)
        drawPalm(c, w * .13f, h * .44f, .62f, false)
        drawPalm(c, w * .86f, h * .45f, .58f, true)

        p.color = Color.rgb(61, 94, 53)
        c.drawOval(-w*.10f, h*.48f, w*.38f, h*.83f, p)
        c.drawOval(w*.67f, h*.50f, w*1.10f, h*.84f, p)
        p.color = Color.rgb(36, 70, 42)
        c.drawOval(-w*.15f, h*.67f, w*.45f, h*1.05f, p)
        c.drawOval(w*.55f, h*.67f, w*1.15f, h*1.05f, p)

        p.color = Color.rgb(93, 81, 57)
        c.drawOval(w*.00f, h*.50f, w*.25f, h*.67f, p)
        c.drawOval(w*.75f, h*.50f, w*1.02f, h*.68f, p)

        p.color = Color.rgb(18, 51, 31)
        c.drawRect(0f, h*.73f, w, h, p)
        p.color = Color.rgb(26, 69, 38)
        for (i in 0..14) {
            val x = (i * w / 14f) + sin(t + i) * 7f
            val y = h * (.74f + (i % 4) * .045f)
            c.drawOval(x - 28f, y - 12f, x + 28f, y + 24f, p)
        }

        p.color = Color.argb(130, 143, 191, 113)
        for (i in 0..11) {
            val x = (i * w / 11f) + 18f
            c.drawOval(x - 14f, h*.80f, x + 20f, h*.96f, p)
        }

        t += .015f
        postInvalidateDelayed(32L)
    }

    private fun drawPalm(c: Canvas, x: Float, y: Float, s: Float, flip: Boolean) {
        p.color = Color.rgb(79, 73, 48)
        p.strokeWidth = 10f * s
        p.style = Paint.Style.STROKE
        val dx = if (flip) -38f else 38f
        c.drawLine(x, y + 230f*s, x + dx*s, y, p)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(28, 88, 42)
        for (i in 0..6) {
            val a = (-1.15f + i * .38f) * if (flip) -1f else 1f
            val ex = x + dx*s + kotlin.math.cos(a.toDouble()).toFloat() * 95f*s
            val ey = y + kotlin.math.sin(a.toDouble()).toFloat() * 70f*s
            val leaf = Path().apply {
                moveTo(x + dx*s, y)
                quadTo(ex, ey - 12f*s, ex + (if (flip) -30f else 30f)*s, ey + 5f*s)
                quadTo(ex, ey + 25f*s, x + dx*s, y + 8f*s)
                close()
            }
            c.drawPath(leaf, p)
        }
    }
}
