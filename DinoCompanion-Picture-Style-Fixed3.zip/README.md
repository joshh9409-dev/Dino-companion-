# Dino Companion Beta v0.2

A virtual dinosaur companion that can live above other Android apps.

## v0.2 features
- Four dinosaur families: T-Rex, Triceratops, Pterodactyl, Stegosaurus
- Four-stage growth model: Baby, Juvenile, Young, Adult
- Real-world elapsed-time evolution clock
- First evolution is free in this prototype
- Persistent hunger, happiness, energy, cleanliness, bond and coins
- Feed, pet, play and clean actions
- Drag the overlay around the screen and remember its position
- YouTube, Instagram, TikTok and game reactions
- Low-battery and late-night reactions
- Shop screen prepared for premium Evolution Food and paid evolutions
- Android overlay + usage-access permissions

This is a prototype build. Google Play Billing product IDs and store-ready artwork/privacy materials still need to be connected before publishing.


## V0.3 interaction/name update
- Players can choose a custom dinosaur name when selecting a species and rename it later.
- The dinosaur name is shown in bold gold above the overlay character.
- The text changes briefly to the current interaction, such as Being petted, Eating, Moving me, Watching YouTube, Watching TikTok, Scrolling Instagram, or Playing a game, then returns to the chosen name.
- Overlay position remains draggable and is saved.
