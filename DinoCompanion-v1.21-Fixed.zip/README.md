# Dino Companion v1.20

This build implements the overlay/foldable, hardware-interaction, glossy overlay UI, and evolution-behaviour overhaul.

## 1. Overlay and foldable handling
- `DinoOverlayService.reconcileDisplayBounds()` reads `WindowManager.currentWindowMetrics.bounds` on API 30+ and display metrics on older Android.
- The persisted X/Y anchor is clamped to the current window dimensions.
- `ComponentCallbacks.onConfigurationChanged()` handles fold/unfold and rotation without inventing a new position.
- A boundary change uses a 180 ms eased window-position correction. If the old anchor still fits, X/Y are unchanged.
- Dragging remains the only normal way to move the companion.

## 2. Hardware interactions
- Battery receiver puts the dino into `HardwareState.SLEEPING` below 15% while not charging and returns to normal above 15% or when charging.
- Accelerometer shake detection uses magnitude delta > 11.5 m/s^2 with a 1.4 s cooldown and triggers `HardwareState.DIZZY`.
- MainActivity forwards IME bottom insets to the service. The service also checks `WindowMetrics` IME insets where Android exposes them.
- When the keyboard opens, the overlay is eased to 8 dp above the keyboard top and its previous Y is restored when the keyboard closes.

## 3. Unified overlay UI
- `res/drawable/overlay_bubble_button.xml` provides the shared glossy gradient, rounded corners, white highlight stroke and pressed state.
- Overlay buttons are compact and live beside the sprite.
- Android does not use CSS for native views; XML drawables plus Kotlin view setup are the native equivalent.

## 4. Evolution behaviour
`DinoBehavior` maps Stage 1-4 to frame cadence, breathing duration, breathing amplitude, tap reaction scale, double-tap reaction scale and idle personality. `DinoDisplayView` reads the active stage whenever animation or tap behaviour is refreshed, so evolution changes behaviour as well as art.


## v1.20 overlay hardening
- The floating window uses an isolated `res/layout/overlay_dino.xml` containing only the dinosaur ImageView and compact MENU/HIDE/INFO menu.
- Window X/Y are clamped against the actual WindowManager width/height with a small safety margin, including fold/unfold configuration changes.
- `DinoPreferences` is the shared source of truth for active dinosaur ID, name, and stage, with migration from the legacy `dino_state` preferences.
- The overlay service listens for `ACTIVE_DINO_CHANGED` so switching to Trixie, Sky, Steggy, or another active companion refreshes the sprite immediately without recreating the overlay.
- Taps outside the compact menu dismiss it; the overlay never inflates the main dashboard into the floating window.
