# Dino Companion Beta v1.7

This release is a functional UI and interaction repair pass on the working Dino Companion project.

## v1.7 fixes
- Dialog navigation now properly dismisses the current screen before opening another screen.
- Android Back now closes the active Dino Companion interface instead of leaving a stale modal over the home screen.
- Food & Care now has an explicit CLOSE button.
- Choose Dinosaur cards are clickable and open the selected dinosaur's evolution gallery.
- Rename, Overlay Settings, Shop, Care and Evolution Gallery all return cleanly to the home screen.
- Modal content remains scrollable on smaller displays.
- Buttons use glossy gradient, highlight, border and elevation treatment to better match the 3D home-screen style.
- Species and evolution cards use raised, gradient panels instead of flat white rectangles.
- Evolution carousel navigation remains circular-feeling and locked stages remain inaccessible.
- Floating companion keeps the larger transparent canvas, tap response and MENU/HIDE/INFO controls.
- HIDE removes the companion without closing Dino Companion.

## Important artwork note
The baby artwork is full-body and used for the four species choices. Some supplied later-stage animation frames are close-up source artwork, so the v1.7 code avoids pretending those source images are different assets. The next artwork pass should replace any later-stage source frames that were originally generated cropped at the source-image level.

## Build
GitHub Actions uses Java 17 and Gradle 8.11 and produces `DinoCompanion-v1.7-debug`.

## v1.17 critical overlay/UI patch
- Floating overlay contains only the dinosaur and compact side menu.
- No autonomous repositioning; drag is the only movement.
- Slow 2% breathing and slow frame cadence replace twitchy reactions.
- Contact shadow is anchored below the feet.
- Transparent sprite filtering and matte-edge cleanup are enabled.
- Dashboard name/species/stage and rename label read from persistent DinoState.
- Keep Caring For [Dino] opens Food & Care.
