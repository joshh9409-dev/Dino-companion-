package com.example.dinocompanion

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import androidx.core.app.NotificationCompat
import java.time.LocalTime

class DinoOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var dinoView: DinoDisplayView? = null
    private lateinit var state: DinoState
    private lateinit var layoutParams: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var lastPackage = ""
    private var downOverlayX = 0
    private var downOverlayY = 0

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val level = intent.getIntExtra("level", 100)
            if (level <= 15) dinoView?.showAction("Charge me!", false)
        }
    }

    override fun onCreate() {
        super.onCreate()
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        state.overlayVisible = true
        createChannel()

        val notification = NotificationCompat.Builder(this, "dino")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Dino Companion is awake")
            .setContentText("Your dinosaur is living on your screen.")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // Compact transparent window. It contains only the dinosaur and its tiny side menu.
        // There is no title/name/action text in the overlay window.
        layoutParams = WindowManager.LayoutParams(
            dp(202), dp(150),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = clampX(state.overlayX)
            y = clampY(state.overlayY)
        }

        dinoView = DinoDisplayView(
            this,
            state,
            compact = true,
            onDragPosition = { dx, dy ->
                val nx = clampX(downOverlayX + dx.toInt())
                val ny = clampY(downOverlayY + dy.toInt())
                layoutParams.x = nx
                layoutParams.y = ny
                state.overlayX = nx
                state.overlayY = ny
                try { windowManager.updateViewLayout(dinoView, layoutParams) } catch (_: Exception) {}
            },
            onOpenMenu = {
                try {
                    val intent = Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    startActivity(intent)
                } catch (_: Exception) {}
            },
            onHide = {
                state.overlayVisible = false
                stopSelf()
            }
        )

        dinoView?.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                downOverlayX = state.overlayX
                downOverlayY = state.overlayY
            }
            false
        }

        windowManager.addView(dinoView, layoutParams)
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        handler.post(checkUsage)
    }

    private val checkUsage = object : Runnable {
        override fun run() {
            try {
                state.applyTimeDecay()
                val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
                val now = System.currentTimeMillis()
                val events = usm.queryEvents(now - 4000, now)
                val e = UsageEvents.Event()
                var newest = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) newest = e.packageName
                }

                if (newest.isNotEmpty() && newest != packageName && newest != lastPackage) {
                    lastPackage = newest
                    val action = when {
                        newest == "com.google.android.youtube" -> "Watching YouTube"
                        newest == "com.instagram.android" -> "Scrolling Instagram"
                        newest == "com.zhiliaoapp.musically" -> "Watching TikTok"
                        newest.contains("game", true) -> "Playing a game"
                        else -> "Exploring"
                    }
                    dinoView?.showAction(action, false)
                    state.happiness = (state.happiness + 3f).coerceAtMost(100f)
                }

                val hour = LocalTime.now().hour
                if (hour in 0..4 && state.energy < 35f) dinoView?.showAction("Sleepy", false)
                dinoView?.refresh()
            } catch (_: Exception) {}

            handler.postDelayed(this, 3000L)
        }
    }


    private fun clampX(value: Int): Int {
        val max = (resources.displayMetrics.widthPixels - dp(202)).coerceAtLeast(0)
        return value.coerceIn(0, max)
    }

    private fun clampY(value: Int): Int {
        val max = (resources.displayMetrics.heightPixels - dp(150)).coerceAtLeast(0)
        return value.coerceIn(0, max)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "dino",
                "Dino Companion",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(checkUsage)
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        dinoView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        dinoView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
