package com.example.dinocompanion

import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var speech: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DinoState(this).apply { ensureStarted(); applyTimeDecay() }
        setContentView(R.layout.activity_main)
        speech = findViewById(R.id.speech)

        findViewById<View>(R.id.raptorTouch).setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; return true }
                    MotionEvent.ACTION_UP -> {
                        if (kotlin.math.abs(e.rawX - downX) < 24 && kotlin.math.abs(e.rawY - downY) < 24) reactToTap()
                        return true
                    }
                }
                return true
            }
        })
        findViewById<View>(R.id.petTouch).setOnClickListener { react("That feels amazing! ❤️") }
        findViewById<View>(R.id.feedTouch).setOnClickListener { react("Yum! I was hungry! 🍎") }
        findViewById<View>(R.id.playTouch).setOnClickListener { react("Let's play! 🦖") }
        findViewById<View>(R.id.settingsTouch).setOnClickListener {
            Toast.makeText(this, "Settings comes after the Raptor foundation.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun reactToTap() {
        val messages = listOf("Hi! 💙", "Raptor loves it!", "Hehe!", "That tickles!", "I'm happy! ❤️")
        react(messages[(System.currentTimeMillis() / 1000L % messages.size).toInt()])
    }

    private fun react(message: String) {
        speech.text = message
        speech.visibility = View.VISIBLE
        speech.alpha = 0f
        speech.animate().alpha(1f).setDuration(160).withEndAction {
            speech.postDelayed({ speech.animate().alpha(0f).setDuration(250).withEndAction { speech.visibility = View.GONE }.start() }, 1800)
        }.start()
    }
}
