package com.example.dinocompanion

import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var speech: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemBars()
        DinoState(this).apply { ensureStarted(); applyTimeDecay() }
        setContentView(R.layout.activity_main)
        speech = findViewById(R.id.speech)

        findViewById<View>(R.id.raptorTouch).setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (abs(e.rawX - downX) < 28 && abs(e.rawY - downY) < 28) reactToTap()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return true
            }
        })

        findViewById<View>(R.id.petTouch).setOnClickListener { react("That feels amazing!") }
        findViewById<View>(R.id.feedTouch).setOnClickListener { react("Yum! I was hungry!") }
        findViewById<View>(R.id.playTouch).setOnClickListener { react("Let's play!") }
        findViewById<View>(R.id.settingsTouch).setOnClickListener {
            Toast.makeText(this, "Settings will be added after the main Raptor screen is finished.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun reactToTap() {
        val messages = listOf("Hi!", "Raptor loves it!", "Hehe!", "That tickles!", "I'm happy!")
        react(messages[(System.currentTimeMillis() / 1000L % messages.size).toInt()])
    }

    private fun react(message: String) {
        speech.text = message
        speech.visibility = View.VISIBLE
        speech.alpha = 0f
        speech.animate().alpha(1f).setDuration(160).withEndAction {
            speech.postDelayed({
                speech.animate().alpha(0f).setDuration(250).withEndAction {
                    speech.visibility = View.GONE
                }.start()
            }, 1800)
        }.start()
    }

    private fun hideSystemBars() {
        val window: Window = window
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
        }
    }
}
