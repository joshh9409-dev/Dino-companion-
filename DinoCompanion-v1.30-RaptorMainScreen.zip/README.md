# Dino Companion v1.30

Raptor-only foundation build.

The main screen now uses the supplied 685x1536 Raptor screenshot as its visual blueprint. The goal of v1.30 is to lock down the look before adding deeper behaviour.

Included:
- One blue Baby Raptor
- Jungle/waterfall main screen
- RAPTOR / Baby Raptor header
- Six visible stats
- PET / FOOD / PLAY controls
- Settings touch target
- Tap reaction speech bubble
- Full-screen presentation

Not yet implemented:
- True Raptor animation
- Drag-to-move
- Persistent floating overlay
- Full settings
- Food/play screens
- Evolution
