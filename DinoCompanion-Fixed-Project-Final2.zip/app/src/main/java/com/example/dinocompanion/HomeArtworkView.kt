package com.example.dinocompanion

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class HomeArtworkView(
    context: Context,
    private val onFoodCare: () -> Unit,
    private val onRename: () -> Unit,
    private val onChoose: () -> Unit,
    private val onOverlaySettings: () -> Unit,
    private val onShop: () -> Unit
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.home_reference)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(125, 205, 244))
        val dst = RectF(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawBitmap(bitmap, null, dst, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_UP || width <= 0 || height <= 0) return true
        val nx = event.x / width.toFloat()
        val ny = event.y / height.toFloat()

        // Coordinates are normalized to the supplied 1024x1461 home artwork.
        when {
            nx in 0.07f..0.35f && ny in 0.60f..0.82f -> onFoodCare()
            nx in 0.34f..0.66f && ny in 0.60f..0.82f -> onRename()
            nx in 0.65f..0.94f && ny in 0.60f..0.82f -> onChoose()
            nx in 0.17f..0.51f && ny in 0.77f..0.98f -> onOverlaySettings()
            nx in 0.50f..0.82f && ny in 0.77f..0.98f -> onShop()
        }
        return true
    }
}
