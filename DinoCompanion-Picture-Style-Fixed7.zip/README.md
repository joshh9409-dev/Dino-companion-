# Dino Companion Beta v1.6

A virtual dinosaur companion that can live above other Android apps.

## v1.6 polish + interaction update
- Four dinosaur families: T-Rex, Triceratops, Pterodactyl, Stegosaurus.
- Four-stage growth model: Baby, Juvenile, Young, Adult.
- Real-world elapsed-time evolution clock and persistent care stats.
- Floating companion uses a larger transparent canvas so animation frames have room to move.
- Detached image artifacts are removed from animation frames to prevent square/box-shaped clipping.
- Tap the floating dinosaur for a visible response and quick action bubbles.
- MENU opens the main Dino Companion screen without requiring the companion to be manually closed.
- HIDE removes the floating companion without closing the app.
- INFO shows quick status information.
- Choose Dinosaur shows the correct baby artwork for every species.
- Each species has a circular-feeling evolution carousel showing all four stages.
- Future evolution stages are dimmed and padlocked until the dinosaur reaches them.
- Rename, Food & Care, Shop and Overlay Settings use the same rounded, colourful Dino Companion interface language.
- Version bumped to 1.6.

The project is built by GitHub Actions with Java 17 and Gradle 8.11.

## v1.6 fixes
- Enlarged the transparent companion canvas and artwork viewport to prevent edge clipping.
- Added gentle idle bobbing and safer tap hit-area handling.
- Hiding the overlay now persists until the user explicitly shows it again.
- All modal screens are vertically scrollable on smaller phones.
- Locked evolution cards now explain how to unlock them when tapped.
