package com.example.dinocompanion

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import android.graphics.drawable.GradientDrawable
import android.animation.ObjectAnimator
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

/**
 * Full-body floating companion.
 *
 * The overlay intentionally has a generous transparent canvas so animation
 * frames are never chopped into a square sticker. Tapping the dino opens
 * quick-action bubbles, while dragging still moves the companion.
 */
class DinoDisplayView(
    context: Context,
    private val state: DinoState,
    private val compact: Boolean = false,
    private val homeMode: Boolean = false,
    private val onAction: ((String) -> Unit)? = null,
    private val onDragPosition: ((Float, Float) -> Unit)? = null,
    private val onOpenMenu: (() -> Unit)? = null,
    private val onHide: (() -> Unit)? = null
) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * density).toInt()

    private val nameText = TextView(context).apply {
        textSize = 16f
        setTextColor(Color.rgb(239, 177, 43))
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setShadowLayer(5f, 0f, 2f, Color.rgb(80, 45, 10))
        maxLines = 1
    }

    private val actionText = TextView(context).apply {
        textSize = 11f
        setTextColor(Color.WHITE)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        maxLines = 1
    }

    private val imageView = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        adjustViewBounds = false
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = false
        isFocusable = false
        pivotX = 0.5f
        pivotY = 1f
    }

    private val controls = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(dp(2f), 0, dp(2f), 0)
        alpha = 0f
        visibility = GONE
    }

    private var animation: AnimationDrawable? = null
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var actionReset: Runnable? = null
    private var idleBob: ObjectAnimator? = null

    init {
        setWillNotDraw(true)
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
        isFocusable = true
        clipChildren = false
        clipToPadding = false

        addView(nameText, LayoutParams(-1, dp(25f)).apply {
            gravity = Gravity.TOP
        })
        addView(actionText, LayoutParams(-1, dp(22f)).apply {
            gravity = Gravity.TOP
            topMargin = dp(24f)
        })
        addView(imageView, LayoutParams(dp(228f), dp(210f)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = dp(42f)
        })

        addView(controls, LayoutParams(dp(222f), dp(47f)).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(1f)
        })

        controls.addView(bubble("MENU", Color.rgb(71, 161, 91)) {
            onOpenMenu?.invoke()
        }, LinearLayout.LayoutParams(dp(68f), dp(44f)).apply {
            marginEnd = dp(5f)
        })
        controls.addView(bubble("HIDE", Color.rgb(225, 77, 61)) {
            onHide?.invoke()
        }, LinearLayout.LayoutParams(dp(68f), dp(44f)).apply {
            marginEnd = dp(5f)
        })
        controls.addView(bubble("INFO", Color.rgb(118, 77, 197)) {
            showStatus()
        }, LinearLayout.LayoutParams(dp(68f), dp(44f)))

        setDinoAnimation()
        refreshLabels()
        startIdleBob()
    }

    private fun bubble(label: String, color: Int, click: () -> Unit) =
        TextView(context).apply {
            text = label
            textSize = 10f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(dp(2f), Color.argb(220, 255, 255, 255))
            }
            elevation = dp(5f).toFloat()
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }

    private fun startIdleBob() {
        idleBob?.cancel()
        idleBob = ObjectAnimator.ofFloat(imageView, View.TRANSLATION_Y, 0f, -dp(5f).toFloat()).apply {
            duration = 900L
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun stageNumber(): Int = (state.stage + 1).coerceIn(1, 4)

    private fun currentDinoType(): String =
        context.getSharedPreferences("dino_state", Context.MODE_PRIVATE)
            .getString("species", "T-Rex") ?: "T-Rex"

    private fun frameIds(species: String, stage: Int): IntArray {
        val s = stage.coerceIn(1, 4)
        return when (species.lowercase()) {
            "t-rex", "trex" -> when (s) {
                1 -> intArrayOf(R.drawable.trex_stage1_f1, R.drawable.trex_stage1_f2, R.drawable.trex_stage1_f3)
                2 -> intArrayOf(R.drawable.trex_stage2_f1, R.drawable.trex_stage2_f2, R.drawable.trex_stage2_f3)
                3 -> intArrayOf(R.drawable.trex_stage3_f1, R.drawable.trex_stage3_f2, R.drawable.trex_stage3_f3)
                else -> intArrayOf(R.drawable.trex_stage4_f1, R.drawable.trex_stage4_f2, R.drawable.trex_stage4_f3)
            }
            "triceratops" -> when (s) {
                1 -> intArrayOf(R.drawable.triceratops_stage1_f1, R.drawable.triceratops_stage1_f2, R.drawable.triceratops_stage1_f3)
                2 -> intArrayOf(R.drawable.triceratops_stage2_f1, R.drawable.triceratops_stage2_f2, R.drawable.triceratops_stage2_f3)
                3 -> intArrayOf(R.drawable.triceratops_stage3_f1, R.drawable.triceratops_stage3_f2, R.drawable.triceratops_stage3_f3)
                else -> intArrayOf(R.drawable.triceratops_stage4_f1, R.drawable.triceratops_stage4_f2, R.drawable.triceratops_stage4_f3)
            }
            "pterodactyl" -> when (s) {
                1 -> intArrayOf(R.drawable.pterodactyl_stage1_f1, R.drawable.pterodactyl_stage1_f2, R.drawable.pterodactyl_stage1_f3)
                2 -> intArrayOf(R.drawable.pterodactyl_stage2_f1, R.drawable.pterodactyl_stage2_f2, R.drawable.pterodactyl_stage2_f3)
                3 -> intArrayOf(R.drawable.pterodactyl_stage3_f1, R.drawable.pterodactyl_stage3_f2, R.drawable.pterodactyl_stage3_f3)
                else -> intArrayOf(R.drawable.pterodactyl_stage4_f1, R.drawable.pterodactyl_stage4_f2, R.drawable.pterodactyl_stage4_f3)
            }
            "stegosaurus" -> when (s) {
                1 -> intArrayOf(R.drawable.stegosaurus_stage1_f1, R.drawable.stegosaurus_stage1_f2, R.drawable.stegosaurus_stage1_f3)
                2 -> intArrayOf(R.drawable.stegosaurus_stage2_f1, R.drawable.stegosaurus_stage2_f2, R.drawable.stegosaurus_stage2_f3)
                3 -> intArrayOf(R.drawable.stegosaurus_stage3_f1, R.drawable.stegosaurus_stage3_f2, R.drawable.stegosaurus_stage3_f3)
                else -> intArrayOf(R.drawable.stegosaurus_stage4_f1, R.drawable.stegosaurus_stage4_f2, R.drawable.stegosaurus_stage4_f3)
            }
            else -> intArrayOf(R.drawable.trex_stage1_f1, R.drawable.trex_stage1_f2, R.drawable.trex_stage1_f3)
        }
    }

    private fun setDinoAnimation() {
        animation?.stop()
        val next = AnimationDrawable().apply {
            isOneShot = false
            frameIds(currentDinoType(), stageNumber()).forEach { id ->
                addFrame(resources.getDrawable(id, null), 190)
            }
        }
        animation = next
        imageView.setImageDrawable(next)
        imageView.animate().cancel()
        imageView.scaleX = 1f
        imageView.scaleY = 1f
        next.start()
        if (idleBob?.isRunning != true) startIdleBob()
    }

    fun refresh() {
        val currentTag = "${currentDinoType()}:${stageNumber()}"
        if (imageView.tag != currentTag) {
            imageView.tag = currentTag
            setDinoAnimation()
        }
        animation?.let { if (!it.isRunning) it.start() }
        refreshLabels()
    }

    private fun refreshLabels() {
        nameText.text = state.name
        actionText.text = if (state.currentAction.isBlank()) "" else state.currentAction
    }

    fun showStatus() {
        val status = "Hunger ${state.hunger.toInt()}% • Happy ${state.happiness.toInt()}% • Energy ${state.energy.toInt()}%"
        showAction(status, false)
    }

    fun showAction(action: String, showStats: Boolean = true) {
        state.currentAction = action
        refreshLabels()

        idleBob?.cancel()
        imageView.animate().cancel()
        imageView.translationY = 0f
        when {
            action.contains("Pet", true) || action.contains("petted", true) -> {
                imageView.animate().rotation(-3f).translationY(-dp(5f).toFloat()).setDuration(120).withEndAction {
                    imageView.animate().rotation(0f).translationY(0f).setDuration(220).start()
                }.start()
            }
            action.contains("Eat", true) || action.contains("Eating", true) -> {
                imageView.animate().scaleX(1.06f).scaleY(1.06f).setDuration(120).withEndAction {
                    imageView.animate().scaleX(1f).scaleY(1f).setDuration(220).start()
                }.start()
            }
            action.contains("Play", true) || action.contains("Moving", true) -> {
                imageView.animate().rotation(3f).translationY(-dp(2f).toFloat()).setDuration(110).withEndAction {
                    imageView.animate().rotation(0f).translationY(0f).setDuration(180).start()
                }.start()
            }
        }

        actionReset?.let { removeCallbacks(it) }
        actionReset = Runnable {
            state.currentAction = ""
            refreshLabels()
            startIdleBob()
        }
        postDelayed(actionReset!!, 1800L)
        onAction?.invoke(action)
    }

    private fun revealControls() {
        controls.visibility = VISIBLE
        controls.animate().cancel()
        controls.animate().alpha(1f).setDuration(140).start()
    }

    override fun onDetachedFromWindow() {
        idleBob?.cancel()
        idleBob = null
        actionReset?.let { removeCallbacks(it) }
        animation?.stop()
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragging && hypot(dx.toDouble(), dy.toDouble()) > dp(7f)) dragging = true
                if (dragging) {
                    onDragPosition?.invoke(dx, dy)
                    showAction("Moving me", false)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (dragging) return true

                val inDinoArea = event.x >= imageView.left - dp(12f) &&
                    event.x <= imageView.right + dp(12f) &&
                    event.y >= imageView.top - dp(12f) &&
                    event.y <= imageView.bottom + dp(12f)
                if (!inDinoArea) return true

                val now = System.currentTimeMillis()
                revealControls()
                idleBob?.cancel()
                imageView.animate().cancel()
                imageView.animate().scaleX(1.04f).scaleY(1.04f).setDuration(90).withEndAction {
                    imageView.animate().scaleX(1f).scaleY(1f).setDuration(150).withEndAction { startIdleBob() }.start()
                }.start()

                if (now - lastTap < 420L) {
                    state.feed(20f)
                    showAction("Eating", false)
                } else {
                    state.pet()
                    showAction("Being petted", false)
                }
                lastTap = now
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }
}
