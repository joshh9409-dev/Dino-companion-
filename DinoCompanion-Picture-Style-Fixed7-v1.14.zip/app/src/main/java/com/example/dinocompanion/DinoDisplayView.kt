package com.example.dinocompanion

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.AnimationDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

/** Compact, anchored floating companion. Position is controlled by the window; the body animates in place. */
class DinoDisplayView(
    context: Context,
    private val state: DinoState,
    private val compact: Boolean = false,
    private val homeMode: Boolean = false,
    private val onAction: ((String) -> Unit)? = null,
    private val onDragPosition: ((Float, Float) -> Unit)? = null,
    private val onOpenMenu: (() -> Unit)? = null,
    private val onHide: (() -> Unit)? = null
) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * density).toInt()

    private val shadowView = View(context).apply {
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(75, 35, 25, 15), Color.argb(0, 0, 0, 0))
        ).apply { shape = GradientDrawable.OVAL }
        alpha = .72f
        elevation = dp(2f).toFloat()
        isClickable = false
    }

    private val nameText = TextView(context).apply {
        textSize = 15f
        setTextColor(Color.rgb(239, 177, 43))
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setShadowLayer(5f, 0f, 2f, Color.rgb(80, 45, 10))
        maxLines = 1
    }

    // The state balloon is anchored below the dinosaur, never above it.
    private val actionText = TextView(context).apply {
        textSize = 9.5f
        setTextColor(Color.rgb(86, 61, 34))
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        maxLines = 2
        setPadding(dp(7f), dp(2f), dp(7f), dp(2f))
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.WHITE, Color.rgb(255, 250, 231), Color.rgb(239, 228, 195))
        ).apply {
            cornerRadius = dp(11f).toFloat()
            setStroke(dp(1f), Color.argb(220, 255, 255, 255))
        }
        elevation = dp(3f).toFloat()
        visibility = GONE
    }

    private val imageView = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        adjustViewBounds = true
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = false
        isFocusable = false
        clipToOutline = false
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    private val controls = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(dp(2f), 0, dp(2f), 0)
        alpha = 0f
        visibility = GONE
    }

    private var animation: AnimationDrawable? = null
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var actionReset: Runnable? = null
    private var controlHide: Runnable? = null
    private var idleBob: ObjectAnimator? = null
    private var blinkReset: Runnable? = null

    init {
        setWillNotDraw(true)
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
        isFocusable = true
        clipChildren = false
        clipToPadding = false

        // 172x196 window: all content stays compact and contained.
        addView(nameText, LayoutParams(dp(150f), dp(22f)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        })
        addView(shadowView, LayoutParams(dp(76f), dp(20f)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = dp(106f)
        })
        addView(imageView, LayoutParams(dp(112f), dp(108f)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = dp(22f)
        })
        addView(actionText, LayoutParams(dp(132f), dp(28f)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = dp(130f)
        })
        addView(controls, LayoutParams(dp(152f), dp(34f)).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(2f)
        })

        controls.addView(bubble("MENU", Color.rgb(71, 161, 91)) { onOpenMenu?.invoke() },
            LinearLayout.LayoutParams(dp(36f), dp(32f)).apply { marginEnd = dp(2f) })
        controls.addView(bubble("HIDE", Color.rgb(225, 77, 61)) { onHide?.invoke() },
            LinearLayout.LayoutParams(dp(36f), dp(32f)).apply { marginEnd = dp(2f) })
        controls.addView(bubble("INFO", Color.rgb(118, 77, 197)) { showStatus() },
            LinearLayout.LayoutParams(dp(36f), dp(32f)).apply { marginEnd = dp(2f) })
        controls.addView(bubble("×", Color.rgb(86, 61, 34)) { hideControls() },
            LinearLayout.LayoutParams(dp(36f), dp(32f)))

        setDinoAnimation()
        refreshLabels()
        startIdleBob()
    }

    private fun bubble(label: String, color: Int, click: () -> Unit) = TextView(context).apply {
        text = label
        textSize = 8f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(lighten(color, .28f), color, darken(color, .20f))
        ).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(1.5f), Color.argb(230, 255, 255, 255))
        }
        elevation = dp(5f).toFloat()
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
    }

    private fun lighten(color: Int, amount: Float): Int = Color.rgb(
        (Color.red(color) + (255 - Color.red(color)) * amount).toInt(),
        (Color.green(color) + (255 - Color.green(color)) * amount).toInt(),
        (Color.blue(color) + (255 - Color.blue(color)) * amount).toInt()
    )

    private fun darken(color: Int, amount: Float): Int = Color.rgb(
        (Color.red(color) * (1f - amount)).toInt(),
        (Color.green(color) * (1f - amount)).toInt(),
        (Color.blue(color) * (1f - amount)).toInt()
    )

    private fun startIdleBob() {
        idleBob?.cancel()
        idleBob = ObjectAnimator.ofFloat(imageView, View.TRANSLATION_Y, 0f, -dp(2f).toFloat()).apply {
            duration = 1800L
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun stageNumber(): Int = (state.stage + 1).coerceIn(1, 4)

    private fun currentDinoType(): String = state.dinoType

    private fun frameIds(species: String, stage: Int): IntArray {
        val s = stage.coerceIn(1, 4)
        return when (species.lowercase()) {
            "t-rex", "trex" -> when (s) {
                1 -> intArrayOf(R.drawable.trex_stage1_f1, R.drawable.trex_stage1_f2, R.drawable.trex_stage1_f3)
                2 -> intArrayOf(R.drawable.trex_stage2_f1, R.drawable.trex_stage2_f2, R.drawable.trex_stage2_f3)
                3 -> intArrayOf(R.drawable.trex_stage3_f1, R.drawable.trex_stage3_f2, R.drawable.trex_stage3_f3)
                else -> intArrayOf(R.drawable.trex_stage4_f1, R.drawable.trex_stage4_f2, R.drawable.trex_stage4_f3)
            }
            "triceratops" -> when (s) {
                1 -> intArrayOf(R.drawable.triceratops_stage1_f1, R.drawable.triceratops_stage1_f2, R.drawable.triceratops_stage1_f3)
                2 -> intArrayOf(R.drawable.triceratops_stage2_f1, R.drawable.triceratops_stage2_f2, R.drawable.triceratops_stage2_f3)
                3 -> intArrayOf(R.drawable.triceratops_stage3_f1, R.drawable.triceratops_stage3_f2, R.drawable.triceratops_stage3_f3)
                else -> intArrayOf(R.drawable.triceratops_stage4_f1, R.drawable.triceratops_stage4_f2, R.drawable.triceratops_stage4_f3)
            }
            "pterodactyl" -> when (s) {
                1 -> intArrayOf(R.drawable.pterodactyl_stage1_f1, R.drawable.pterodactyl_stage1_f2, R.drawable.pterodactyl_stage1_f3)
                2 -> intArrayOf(R.drawable.pterodactyl_stage2_f1, R.drawable.pterodactyl_stage2_f2, R.drawable.pterodactyl_stage2_f3)
                3 -> intArrayOf(R.drawable.pterodactyl_stage3_f1, R.drawable.pterodactyl_stage3_f2, R.drawable.pterodactyl_stage3_f3)
                else -> intArrayOf(R.drawable.pterodactyl_stage4_f1, R.drawable.pterodactyl_stage4_f2, R.drawable.pterodactyl_stage4_f3)
            }
            "stegosaurus" -> when (s) {
                1 -> intArrayOf(R.drawable.stegosaurus_stage1_f1, R.drawable.stegosaurus_stage1_f2, R.drawable.stegosaurus_stage1_f3)
                2 -> intArrayOf(R.drawable.stegosaurus_stage2_f1, R.drawable.stegosaurus_stage2_f2, R.drawable.stegosaurus_stage2_f3)
                3 -> intArrayOf(R.drawable.stegosaurus_stage3_f1, R.drawable.stegosaurus_stage3_f2, R.drawable.stegosaurus_stage3_f3)
                else -> intArrayOf(R.drawable.stegosaurus_stage4_f1, R.drawable.stegosaurus_stage4_f2, R.drawable.stegosaurus_stage4_f3)
            }
            else -> intArrayOf(R.drawable.trex_stage1_f1, R.drawable.trex_stage1_f2, R.drawable.trex_stage1_f3)
        }
    }

    private fun setDinoAnimation() {
        animation?.stop()
        val stage = stageNumber()
        val next = AnimationDrawable().apply {
            isOneShot = false
            frameIds(currentDinoType(), stage).forEachIndexed { index, id ->
                val drawable = resources.getDrawable(id, null)
                if (drawable is BitmapDrawable) {
                    drawable.isAntiAlias = true
                    drawable.isFilterBitmap = true
                    drawable.gravity = Gravity.CENTER
                }
                // Slow, calm body micro-animation rather than frantic twitching.
                addFrame(drawable, if (index == 1) 1100 else 900)
            }
        }
        animation = next
        imageView.setImageDrawable(next)
        imageView.animate().cancel()
        imageView.translationX = 0f
        imageView.translationY = 0f
        imageView.rotation = 0f
        val baseScale = when (stage) {
            1 -> 0.58f
            2 -> 0.68f
            3 -> 0.78f
            else -> 0.88f
        }
        imageView.scaleX = baseScale
        imageView.scaleY = baseScale
        imageView.pivotX = imageView.width / 2f
        imageView.pivotY = imageView.height.toFloat() * .86f
        next.start()
        if (idleBob?.isRunning != true) startIdleBob()
    }

    fun refresh() {
        val currentTag = "${currentDinoType()}:${stageNumber()}"
        if (imageView.tag != currentTag) {
            imageView.tag = currentTag
            setDinoAnimation()
        }
        animation?.let { if (!it.isRunning) it.start() }
        refreshLabels()
    }

    private fun refreshLabels() {
        nameText.text = state.name
        actionText.text = if (state.currentAction.isBlank()) "" else state.currentAction
        actionText.visibility = if (state.currentAction.isBlank()) GONE else VISIBLE
    }

    fun showStatus() {
        val status = "${state.name}\nHunger ${state.hunger.toInt()}% • Happy ${state.happiness.toInt()}% • Energy ${state.energy.toInt()}%"
        showAction(status, false)
    }

    fun showAction(action: String, showStats: Boolean = true) {
        state.currentAction = action
        refreshLabels()
        // Never move the window or drift the anchor when reacting.
        idleBob?.cancel()
        imageView.animate().cancel()
        val baseScale = when (stageNumber()) { 1 -> .58f; 2 -> .68f; 3 -> .78f; else -> .88f }
        when {
            action.contains("Pet", true) || action.contains("petted", true) ->
                imageView.animate().scaleX(baseScale * 1.018f).scaleY(baseScale * 1.018f)
                    .setDuration(180).withEndAction { imageView.animate().scaleX(baseScale).scaleY(baseScale).setDuration(260).start() }.start()
            action.contains("Eat", true) || action.contains("Eating", true) ->
                imageView.animate().scaleX(baseScale * 1.025f).scaleY(baseScale * .985f)
                    .setDuration(220).withEndAction { imageView.animate().scaleX(baseScale).scaleY(baseScale).setDuration(300).start() }.start()
            action.contains("Play", true) ->
                imageView.animate().rotation(2f).setDuration(220).withEndAction { imageView.animate().rotation(0f).setDuration(350).start() }.start()
        }
        actionReset?.let { removeCallbacks(it) }
        actionReset = Runnable {
            state.currentAction = ""
            refreshLabels()
            startIdleBob()
        }
        postDelayed(actionReset!!, if (showStats) 2200L else 2600L)
        onAction?.invoke(action)
    }

    private fun hideControls() {
        controlHide?.let { removeCallbacks(it) }
        controls.animate().cancel()
        controls.animate().alpha(0f).setDuration(100).withEndAction { controls.visibility = GONE }.start()
    }

    private fun revealControls() {
        controls.visibility = VISIBLE
        controls.animate().cancel()
        controls.animate().alpha(1f).setDuration(140).start()
        controlHide?.let { removeCallbacks(it) }
        controlHide = Runnable { hideControls() }
        postDelayed(controlHide!!, 2800L)
    }

    override fun onDetachedFromWindow() {
        idleBob?.cancel()
        idleBob = null
        actionReset?.let { removeCallbacks(it) }
        controlHide?.let { removeCallbacks(it) }
        blinkReset?.let { removeCallbacks(it) }
        animation?.stop()
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragging && hypot(dx.toDouble(), dy.toDouble()) > dp(7f)) dragging = true
                if (dragging) {
                    onDragPosition?.invoke(dx, dy)
                    // Do not show a balloon while dragging, so it cannot cover the app.
                    actionText.visibility = GONE
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (dragging) return true
                val inDinoArea = event.x >= imageView.left - dp(10f) &&
                    event.x <= imageView.right + dp(10f) &&
                    event.y >= imageView.top - dp(10f) &&
                    event.y <= imageView.bottom + dp(10f)
                if (!inDinoArea) {
                    hideControls()
                    actionText.visibility = GONE
                    return true
                }
                revealControls()
                val now = System.currentTimeMillis()
                if (now - lastTap < 520L) {
                    state.feed(20f)
                    showAction("Eating", false)
                } else {
                    state.pet()
                    showAction("Being petted", false)
                }
                lastTap = now
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }
}
