package com.example.dinocompanion

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var state: DinoState
    private lateinit var home: HomeArtworkView
    private val prefs by lazy { DinoPreferences(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemBars()
        state = DinoState(this).also { it.ensureStarted(); it.applyTimeDecay() }
        buildHome()
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        if (::state.isInitialized) {
            state.applyTimeDecay()
            home.invalidate()
        }
    }

    private fun buildHome() {
        home = HomeArtworkView(
            this,
            state,
            onFoodCare = { showCare() },
            onRename = { renameDino() },
            onChoose = { chooseDino() },
            onOverlaySettings = { overlaySettings() },
            onShop = { shop() }
        )
        setContentView(home)
    }

    private fun showCare() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        addStat(box, "Hunger", state.hunger)
        addStat(box, "Thirst", state.thirst)
        addStat(box, "Happiness", state.happiness)
        addStat(box, "Energy", state.energy)
        addStat(box, "Health", state.health)
        addStat(box, "Cleanliness", state.cleanliness)
        addStat(box, "Bond", state.bond)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun action(label: String, click: () -> Unit) {
            actions.addView(Button(this).apply {
                text = label
                setOnClickListener { click(); buildHome(); showCare() }
            }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(4, 8, 4, 0) })
        }
        action("Feed") { state.feed() }
        action("Pet") { state.pet() }
        action("Clean") { state.clean() }
        action("Play") { state.play() }
        box.addView(actions)

        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = state.evolutionProgress()
        }
        box.addView(TextView(this).apply {
            text = "Evolution: ${state.evolutionProgress()}%  •  Level ${state.level}  •  ${state.coins} coins"
            setTextColor(Color.DKGRAY); textSize = 15f; setPadding(0, dp(10), 0, dp(4))
        })
        box.addView(progress)

        AlertDialog.Builder(this)
            .setTitle("Food & Care • ${state.name}")
            .setView(box)
            .setPositiveButton(if (state.canEvolve()) "EVOLVE" else "Done") { _, _ -> if (state.canEvolve()) evolve() }
            .setNeutralButton("Mini-game") { _, _ -> miniGame() }
            .show()
    }

    private fun addStat(parent: LinearLayout, label: String, value: Float) {
        parent.addView(TextView(this).apply {
            text = "$label  ${value.roundToInt()}%"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(3), 0, 0)
        })
        parent.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = value.roundToInt().coerceIn(0, 100)
        }, LinearLayout.LayoutParams(-1, dp(8)))
    }

    private fun renameDino() {
        val input = EditText(this).apply {
            setText(state.name)
            selectAll()
            hint = "Dino name"
            maxLines = 1
        }
        AlertDialog.Builder(this)
            .setTitle("Rename ${state.dinoType}")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotBlank()) state.name = value
                buildHome()
            }.show()
    }

    private fun chooseDino() {
        val dinos = arrayOf("T-Rex", "Triceratops", "Pterodactyl", "Stegosaurus")
        val selected = dinos.indexOf(state.dinoType).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Choose your dinosaur")
            .setSingleChoiceItems(dinos, selected) { dialog, which ->
                prefs.setActiveDino(dinos[which], 0)
                state.ensureStarted()
                dialog.dismiss()
                buildHome()
                toast("${dinos[which]} selected")
            }
            .setNeutralButton("Inventory") { _, _ -> inventory() }
            .show()
    }

    private fun inventory() {
        AlertDialog.Builder(this)
            .setTitle("Dino Inventory")
            .setMessage("Evolution food: ${state.evolutionFood}\nCoins: ${state.coins}\nActive dino: ${state.name}\nStage: ${state.stage + 1}/4")
            .setPositiveButton("Done", null)
            .show()
    }

    private fun shop() {
        val items = arrayOf(
            "Evolution food ×1   •   10 coins",
            "Big meal   •   5 coins",
            "Play token   •   8 coins"
        )
        AlertDialog.Builder(this)
            .setTitle("Dino Shop • ${state.coins} coins")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> if (state.coins >= 10) { state.coins -= 10; state.evolutionFood += 1; toast("Evolution food added") } else toast("Not enough coins")
                    1 -> if (state.coins >= 5) { state.coins -= 5; state.feed(35f); toast("Big meal delivered") } else toast("Not enough coins")
                    2 -> if (state.coins >= 8) { state.coins -= 8; toast("Play token added") } else toast("Not enough coins")
                }
            }
            .setNeutralButton("Inventory") { _, _ -> inventory() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun miniGame() {
        AlertDialog.Builder(this)
            .setTitle("Dino Dash")
            .setMessage("A quick practice run earns coins and bond. Ready to send ${state.name} running?")
            .setNegativeButton("Not now", null)
            .setPositiveButton("RUN!") { _, _ -> state.play(); state.coins += 10; toast("Great run! +10 bonus coins") }
            .show()
    }

    private fun evolve() {
        if (state.evolve()) {
            toast("${state.name} evolved to Stage ${state.stage + 1}!")
            buildHome()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Not ready yet")
                .setMessage("Your dino needs enough age, level, happiness and bond before evolving.")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun overlaySettings() {
        val hasPermission = Settings.canDrawOverlays(this)
        val message = if (hasPermission) {
            "Overlay permission is enabled.\n\nThe companion can stay above other apps, react to battery, keyboard and shakes, and remember its position."
        } else {
            "Overlay permission is required before the floating dinosaur can appear above other apps."
        }
        AlertDialog.Builder(this)
            .setTitle("Overlay Settings")
            .setMessage(message)
            .setPositiveButton(if (hasPermission) "Show Dino" else "Grant Permission") { _, _ ->
                if (!hasPermission) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startOverlay()
                }
            }
            .setNeutralButton("Hide Dino") { _, _ -> stopOverlay() }
            .setNegativeButton("Settings", null)
            .show()
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Please grant overlay permission first")
            return
        }
        state.overlayVisible = true
        val intent = Intent(this, DinoOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        toast("Dino overlay is on")
    }

    private fun stopOverlay() {
        state.overlayVisible = false
        stopService(Intent(this, DinoOverlayService::class.java))
        toast("Dino overlay hidden")
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun hideSystemBars() {
        val window: Window = window
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
        }
    }
}
