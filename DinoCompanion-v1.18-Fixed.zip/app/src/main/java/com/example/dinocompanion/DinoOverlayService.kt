package com.example.dinocompanion

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowInsets
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.time.LocalTime
import kotlin.math.sqrt

class DinoOverlayService : Service(), SensorEventListener {
    companion object {
        const val ACTION_IME_INSETS = "com.example.dinocompanion.ACTION_IME_INSETS"
        const val EXTRA_IME_BOTTOM = "ime_bottom"
    }

    private lateinit var windowManager: WindowManager
    private var dinoView: DinoDisplayView? = null
    private lateinit var state: DinoState
    private lateinit var layoutParams: WindowManager.LayoutParams
    private lateinit var sensorManager: SensorManager
    private val handler = Handler(Looper.getMainLooper())
    private var lastPackage = ""
    private var downOverlayX = 0
    private var downOverlayY = 0
    private var keyboardVisible = false
    private var keyboardYBeforeOpen = 0
    private var lastShakeAt = 0L
    private var lastAccelMagnitude = SensorManager.GRAVITY_EARTH
    private var batterySleeping = false
    private var screenWidth = 0
    private var screenHeight = 0

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val level = intent.getIntExtra("level", 100)
            val status = intent.getIntExtra("status", -1)
            val charging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
                status == android.os.BatteryManager.BATTERY_STATUS_FULL
            batterySleeping = level <= 15 && !charging
            if (batterySleeping) {
                dinoView?.setHardwareState(DinoDisplayView.HardwareState.SLEEPING)
            } else {
                dinoView?.setHardwareState(DinoDisplayView.HardwareState.NORMAL)
            }
        }
    }

    private val imeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_IME_INSETS) return
            val bottom = intent.getIntExtra(EXTRA_IME_BOTTOM, 0)
            applyKeyboardInset(bottom)
        }
    }

    private val componentCallbacks = object : ComponentCallbacks {
        override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
            // Fold/unfold and rotation can change the logical display bounds without
            // recreating this foreground service. Recalculate only the legal bounds.
            handler.post { reconcileDisplayBounds(animate = true) }
        }
        override fun onLowMemory() = Unit
    }

    override fun onCreate() {
        super.onCreate()
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        state.overlayVisible = true
        createChannel()

        val notification = NotificationCompat.Builder(this, "dino")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Dino Companion is awake")
            .setContentText("Your dinosaur is living on your screen.")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        registerComponentCallbacks(componentCallbacks)

        layoutParams = WindowManager.LayoutParams(
            dp(202), dp(150),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        reconcileDisplayBounds(animate = false)

        dinoView = DinoDisplayView(
            this,
            state,
            compact = true,
            onDragPosition = { dx, dy ->
                val nx = clampX(downOverlayX + dx.toInt())
                val ny = clampY(downOverlayY + dy.toInt())
                layoutParams.x = nx
                layoutParams.y = ny
                state.overlayX = nx
                state.overlayY = ny
                try { windowManager.updateViewLayout(dinoView, layoutParams) } catch (_: Exception) {}
            },
            onOpenMenu = {
                try {
                    val intent = Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    startActivity(intent)
                } catch (_: Exception) {}
            },
            onHide = {
                state.overlayVisible = false
                stopSelf()
            }
        )

        dinoView?.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                downOverlayX = layoutParams.x
                downOverlayY = layoutParams.y
            }
            false
        }

        windowManager.addView(dinoView, layoutParams)

        registerReceiverCompat(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), exported = true)
        registerReceiverCompat(imeReceiver, IntentFilter(ACTION_IME_INSETS), exported = false)

        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }

        handler.post(checkUsage)
    }

    private val checkUsage = object : Runnable {
        override fun run() {
            try {
                state.applyTimeDecay()
                reconcileDisplayBounds(animate = false)
                updateKeyboardFromWindowInsets()

                val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
                val now = System.currentTimeMillis()
                val events = usm.queryEvents(now - 4000, now)
                val e = UsageEvents.Event()
                var newest = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) newest = e.packageName
                }

                if (newest.isNotEmpty() && newest != packageName && newest != lastPackage) {
                    lastPackage = newest
                    val action = when {
                        newest == "com.google.android.youtube" -> "Watching YouTube"
                        newest == "com.instagram.android" -> "Scrolling Instagram"
                        newest == "com.zhiliaoapp.musically" -> "Watching TikTok"
                        newest.contains("game", true) -> "Playing a game"
                        else -> "Exploring"
                    }
                    dinoView?.showAction(action, false)
                    state.happiness = (state.happiness + 3f).coerceAtMost(100f)
                }

                val hour = LocalTime.now().hour
                if (hour in 0..4 && state.energy < 35f) dinoView?.showAction("Sleepy", false)
                dinoView?.refresh()
            } catch (_: Exception) {}
            handler.postDelayed(this, 1500L)
        }
    }

    private fun reconcileDisplayBounds(animate: Boolean) {
        val bounds = if (Build.VERSION.SDK_INT >= 30) {
            windowManager.currentWindowMetrics.bounds
        } else {
            android.graphics.Rect(0, 0, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
        }
        val newWidth = bounds.width().coerceAtLeast(1)
        val newHeight = bounds.height().coerceAtLeast(1)
        val changed = newWidth != screenWidth || newHeight != screenHeight
        screenWidth = newWidth
        screenHeight = newHeight
        val nx = clampX(state.overlayX)
        val ny = clampY(state.overlayY)
        if (nx != state.overlayX || ny != state.overlayY) {
            state.overlayX = nx
            state.overlayY = ny
        }
        layoutParams.x = nx
        layoutParams.y = ny
        if (dinoView != null) {
            try {
                if (animate && changed) {
                    animateWindowPosition(nx, ny, 180L)
                } else {
                    windowManager.updateViewLayout(dinoView, layoutParams)
                }
            } catch (_: Exception) {}
        }
    }

    private fun clampX(value: Int): Int {
        val max = (screenWidth - dp(202)).coerceAtLeast(0)
        return value.coerceIn(0, max)
    }

    private fun clampY(value: Int): Int {
        val max = (screenHeight - dp(150)).coerceAtLeast(0)
        return value.coerceIn(0, max)
    }

    private fun animateWindowPosition(targetX: Int, targetY: Int, duration: Long) {
        val startX = layoutParams.x
        val startY = layoutParams.y
        val start = SystemClock.uptimeMillis()
        val frame = object : Runnable {
            override fun run() {
                val t = ((SystemClock.uptimeMillis() - start).toFloat() / duration).coerceIn(0f, 1f)
                val eased = t * t * (3f - 2f * t)
                layoutParams.x = (startX + (targetX - startX) * eased).toInt()
                layoutParams.y = (startY + (targetY - startY) * eased).toInt()
                try { windowManager.updateViewLayout(dinoView, layoutParams) } catch (_: Exception) { return }
                if (t < 1f) handler.postDelayed(this, 16L)
            }
        }
        handler.post(frame)
    }

    private fun applyKeyboardInset(bottomInset: Int) {
        val visible = bottomInset > dp(120)
        if (visible && !keyboardVisible) keyboardYBeforeOpen = layoutParams.y
        if (!visible && keyboardVisible) {
            keyboardVisible = false
            val restore = clampY(keyboardYBeforeOpen)
            animateWindowPosition(layoutParams.x, restore, 180L)
            state.overlayY = restore
            return
        }
        if (visible) {
            keyboardVisible = true
            val target = (screenHeight - bottomInset - dp(150) - dp(8)).coerceIn(0, clampY(Int.MAX_VALUE))
            animateWindowPosition(layoutParams.x, target, 180L)
            state.overlayY = target
        }
    }

    private fun updateKeyboardFromWindowInsets() {
        if (Build.VERSION.SDK_INT < 30) return
        try {
            val insets = windowManager.currentWindowMetrics.windowInsets
            val bottom = insets.getInsets(WindowInsets.Type.ime()).bottom
            applyKeyboardInset(bottom)
        } catch (_: Exception) {}
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val magnitude = sqrt(
            event.values[0] * event.values[0] +
                event.values[1] * event.values[1] +
                event.values[2] * event.values[2]
        )
        val delta = kotlin.math.abs(magnitude - lastAccelMagnitude)
        lastAccelMagnitude = magnitude
        val now = SystemClock.elapsedRealtime()
        if (batterySleeping) return
        if (delta > 11.5f && now - lastShakeAt > 1400L) {
            lastShakeAt = now
            dinoView?.setHardwareState(DinoDisplayView.HardwareState.DIZZY)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun registerReceiverCompat(receiver: BroadcastReceiver, filter: IntentFilter, exported: Boolean) {
        if (Build.VERSION.SDK_INT >= 33) {
            val flags = if (exported) RECEIVER_EXPORTED else RECEIVER_NOT_EXPORTED
            registerReceiver(receiver, filter, flags)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("dino", "Dino Companion", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(checkUsage)
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(imeReceiver) } catch (_: Exception) {}
        try { unregisterComponentCallbacks(componentCallbacks) } catch (_: Exception) {}
        try { sensorManager.unregisterListener(this) } catch (_: Exception) {}
        dinoView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        dinoView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
