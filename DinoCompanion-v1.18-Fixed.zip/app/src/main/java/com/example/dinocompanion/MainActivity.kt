package com.example.dinocompanion

import android.Manifest
import android.app.AppOpsManager
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowInsets
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    private lateinit var state: DinoState
    private var launchedPermission = false
    private var activeDialog: Dialog? = null

    private val green = Color.rgb(80, 190, 78)
    private val darkGreen = Color.rgb(33, 105, 67)
    private val gold = Color.rgb(236, 170, 47)
    private val cream = Color.rgb(255, 250, 231)
    private val brown = Color.rgb(86, 61, 34)
    private val purple = Color.rgb(126, 76, 211)
    private val roundedTypeface = Typeface.create("sans-serif-rounded", Typeface.NORMAL)
    private val roundedBoldTypeface = Typeface.create("sans-serif-rounded", Typeface.BOLD)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (activeDialog != null) closeActiveDialog() else finish()
            }
        })
        // Forward IME visibility to the overlay service. This works while Dino
        // Companion is the visible activity; the service also polls WindowMetrics
        // as a best-effort fallback for IME visibility on supported Android versions.
        window.decorView.setOnApplyWindowInsetsListener { view, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val imeBottom = insets.getInsets(WindowInsets.Type.ime()).bottom
                sendBroadcast(Intent(DinoOverlayService.ACTION_IME_INSETS).apply {
                    setPackage(packageName)
                    putExtra(DinoOverlayService.EXTRA_IME_BOTTOM, imeBottom)
                })
            }
            insets
        }
        window.decorView.post { window.decorView.requestApplyInsets() }
        if (!allRequiredPermissionsGranted()) showPermissionWelcome() else {
            if (state.overlayVisible) startCompanionService()
            showHome()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!::state.isInitialized) return
        if (launchedPermission) {
            launchedPermission = false
            if (!allRequiredPermissionsGranted()) {
                window.decorView.postDelayed({ advancePermissions() }, 250)
            } else {
                getSharedPreferences("dino_setup", MODE_PRIVATE).edit().putBoolean("done", true).apply()
                if (state.overlayVisible) startCompanionService()
                showHome()
            }
        }
        state.applyTimeDecay()
    }

    private fun allRequiredPermissionsGranted(): Boolean =
        Settings.canDrawOverlays(this) && hasUsageAccess()

    private fun showPermissionWelcome() {
        val root = FrameLayout(this).apply { background = permissionBackground() }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(18), dp(18), dp(18), dp(110))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        box.addView(TextView(this).apply {
            text = "DINO COMPANION"
            textSize = 34f
            setTextColor(Color.rgb(255, 191, 48))
            typeface = roundedBoldTypeface
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 3f, Color.rgb(80, 45, 10))
            setPadding(0, dp(28), 0, dp(8))
        }, LinearLayout.LayoutParams(-1, -2))
        box.addView(TextView(this).apply {
            text = "A REAL FRIEND. A WILDER WORLD."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }, LinearLayout.LayoutParams(-1, -2))
        box.addView(panelText(
            "Your dinosaur can live on your screen, react to what you do, and keep growing while you're away.\n\nWe'll set up the access it needs now. You won't need permission controls cluttering the game later."
        ), LinearLayout.LayoutParams(-1, -2))
        box.addView(TextView(this).apply {
            text = "TWO QUICK STEPS\n\n1. Allow the dinosaur to appear over other apps.\n2. Allow usage access so it can recognise apps such as YouTube, TikTok and games."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(18), dp(24), dp(18), dp(20))
        }, LinearLayout.LayoutParams(-1, -2))
        scroll.addView(box)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        root.addView(styledButton("GET STARTED", green, 58) {
            advancePermissions()
        }, FrameLayout.LayoutParams(-1, dp(58)).apply {
            gravity = Gravity.BOTTOM
            setMargins(dp(16), dp(8), dp(16), dp(18))
        })
        setContentView(root)
    }

    private fun advancePermissions() {
        if (!Settings.canDrawOverlays(this)) {
            launchedPermission = true
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!hasUsageAccess()) {
            launchedPermission = true
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        getSharedPreferences("dino_setup", MODE_PRIVATE).edit().putBoolean("done", true).apply()
        startCompanionService()
        showHome()
    }

    private fun startCompanionService() {
        state.overlayVisible = true
        try { ContextCompat.startForegroundService(this, Intent(this, DinoOverlayService::class.java)) } catch (_: Exception) {}
    }

    private fun stopCompanionService() {
        state.overlayVisible = false
        try { stopService(Intent(this, DinoOverlayService::class.java)) } catch (_: Exception) {}
    }

    private fun closeActiveDialog() {
        activeDialog?.dismiss()
        activeDialog = null
    }

    private fun showHome() {
        closeActiveDialog()
        state.applyTimeDecay()
        val home = HomeArtworkView(
            this,
            state,
            onFoodCare = { showCare() },
            onRename = { showNamePicker() },
            onChoose = { showSpeciesPicker() },
            onOverlaySettings = { showOverlaySettings() },
            onShop = { showShop() }
        )
        setContentView(home)
    }

    private fun showCare() {
        val content = verticalContent()
        content.addView(titleText("FOOD & CARE"))
        content.addView(subtitleText("Take care of ${state.name} and keep their needs healthy."))
        addStatRow(content, "Hunger", state.hunger)
        addStatRow(content, "Happiness", state.happiness)
        addStatRow(content, "Energy", state.energy)
        addStatRow(content, "Cleanliness", state.cleanliness)
        addStatRow(content, "Bond", state.bond)
        content.addView(buttonRow(
            styledButton("FEED", Color.rgb(228, 69, 57), 52) { state.feed(); showCare() },
            styledButton("PLAY", Color.rgb(52, 157, 232), 52) { state.play(); showCare() },
            styledButton("PET", green, 52) { state.pet(); showCare() },
            styledButton("CLEAN", purple, 52) { state.clean(); showCare() }
        ))
        content.addView(styledButton("CLOSE", darkGreen, 52) { showHome() }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })
        showThemedDialog("FOOD & CARE", content, cancelable = true)
    }

    private fun showSpeciesPicker() {
        val species = listOf(
            Triple("T-Rex", "trex_stage1_f1", "Rex"),
            Triple("Triceratops", "triceratops_stage1_f1", "Trixie"),
            Triple("Pterodactyl", "pterodactyl_stage1_f1", "Sky"),
            Triple("Stegosaurus", "stegosaurus_stage1_f1", "Steggy")
        )
        val content = verticalContent()
        content.addView(titleText("CHOOSE YOUR DINOSAUR"))
        content.addView(subtitleText("Pick a baby, then spin through the evolution path to see what they can become. Locked stages stay locked until your dinosaur evolves."))

        val cards = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, 0)
        }
        species.forEach { (name, imageName, defaultName) ->
            cards.addView(speciesRow(name, imageName) {
                state.dinoType = name
                state.stage = 0
                state.birthTime = System.currentTimeMillis()
                state.freeEvolutionUsed = false
                // Each species keeps its own name. Selecting a dinosaur should not
                // overwrite the name of another companion.
                if (state.name.isBlank()) state.name = defaultName
                state.currentAction = ""
                showEvolutionCarousel()
            }, LinearLayout.LayoutParams(-1, dp(92)).apply {
                bottomMargin = dp(10)
            })
        }
        content.addView(cards)
        content.addView(styledButton("CLOSE", darkGreen, 52) { showHome() })
        showThemedDialog("CHOOSE DINOSAUR", content, cancelable = true)
    }

    private fun showEvolutionCarousel() {
        val species = state.dinoType
        val content = verticalContent()
        content.addView(titleText("${species.uppercase()} EVOLUTION"))
        content.addView(subtitleText("Stage ${state.stage + 1}/4 • ${state.name}"))

        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val imageNames = stageImageNames(species)

        // Three copies create a true circular-feeling carousel. When the user
        // reaches either end, we silently jump to the matching middle copy.
        val copies = (0 until 3).flatMap { imageNames }
        copies.forEachIndexed { absoluteIndex, resName ->
            val stageIndex = absoluteIndex % 4
            row.addView(
                evolutionCard(stageIndex, resName, stageIndex <= state.stage),
                LinearLayout.LayoutParams(dp(148), dp(235)).apply { marginEnd = dp(10) }
            )
        }
        scroll.addView(row)
        content.addView(scroll, LinearLayout.LayoutParams(-1, dp(255)))

        scroll.post {
            // Start on the middle copy at the currently selected stage.
            val cardWidth = dp(158)
            scroll.scrollTo(cardWidth * (4 + state.stage), 0)
        }

        scroll.setOnScrollChangeListener { _, scrollX, _, _, _ ->
            val cardWidth = dp(158)
            val leftBoundary = cardWidth * 2
            val rightBoundary = cardWidth * 8
            when {
                scrollX < leftBoundary -> scroll.scrollTo(scrollX + cardWidth * 4, 0)
                scrollX > rightBoundary -> scroll.scrollTo(scrollX - cardWidth * 4, 0)
            }
        }

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        nav.addView(styledButton("‹", purple, 52) {
            scroll.smoothScrollBy(-dp(158), 0)
        }, LinearLayout.LayoutParams(dp(64), dp(52)).apply { marginEnd = dp(12) })
        nav.addView(styledButton("›", purple, 52) {
            scroll.smoothScrollBy(dp(158), 0)
        }, LinearLayout.LayoutParams(dp(64), dp(52)).apply { marginEnd = dp(12) })
        nav.addView(styledButton("SPAWN DINO", green, 52) {
            startCompanionService()
            showHome()
        }, LinearLayout.LayoutParams(dp(132), dp(52)))
        content.addView(nav)

        content.addView(styledButton(
            if (state.stage >= 3) "RETURN TO DINO" else "KEEP CARING FOR ${state.name.uppercase()}",
            if (state.stage >= 3) gold else green,
            54
        ) {
            if (state.stage >= 3) showHome() else showCare()
        })

        showThemedDialog("EVOLUTION GALLERY", content, cancelable = true)
    }

    private fun evolutionCard(index: Int, resName: String, unlocked: Boolean): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                if (unlocked) intArrayOf(Color.WHITE, cream, Color.rgb(244, 235, 205))
                else intArrayOf(Color.rgb(245, 245, 241), Color.rgb(224, 223, 217), Color.rgb(205, 204, 198))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(2), Color.argb(160, 255, 255, 255))
            }
            elevation = dp(7).toFloat()
        }
        val image = ImageView(this).apply {
            setImageResource(resources.getIdentifier(resName, "drawable", packageName))
            scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = if (unlocked) 1f else .32f
            // The source files have different pixel dimensions, so normalize them
            // by evolution stage. Stage 1 is deliberately the smallest and each
            // later stage grows slightly, while the entire dinosaur remains visible.
            val growth = when (index) { 0 -> .58f; 1 -> .70f; 2 -> .82f; else -> .94f }
            scaleX = growth
            scaleY = growth
        }
        card.addView(image, LinearLayout.LayoutParams(-1, dp(155)))
        card.addView(TextView(this).apply {
            text = "STAGE ${index + 1}"
            textSize = 15f
            typeface = roundedBoldTypeface
            setTextColor(brown)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(28)))
        card.addView(TextView(this).apply {
            text = if (unlocked) evolutionName(index) else "LOCKED"
            textSize = 13f
            typeface = roundedBoldTypeface
            setTextColor(if (unlocked) darkGreen else Color.DKGRAY)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(24)))
        if (!unlocked) {
            card.addView(TextView(this).apply {
                text = "🔒"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Color.DKGRAY)
            }, LinearLayout.LayoutParams(-1, dp(30)))
            card.setOnClickListener {
                Toast.makeText(this, "Care for ${state.name} to unlock this evolution", Toast.LENGTH_SHORT).show()
            }
        } else {
            card.setOnClickListener {
                Toast.makeText(this, "${evolutionName(index)} unlocked", Toast.LENGTH_SHORT).show()
            }
        }
        return card
    }

    private fun evolutionName(index: Int) = when (index) {
        0 -> "BABY"
        1 -> "JUVENILE"
        2 -> "YOUNG"
        else -> "ADULT"
    }

    private fun stageImageNames(species: String): List<String> {
        val p = when (species.lowercase()) {
            "t-rex", "trex" -> "trex"
            "triceratops" -> "triceratops"
            "pterodactyl" -> "pterodactyl"
            else -> "stegosaurus"
        }
        // Use the transparent animation frames in the gallery. Some of the
        // old *_stageN files are reference/composite images with UI baked in.
        return (1..4).map { "${p}_stage${it}_f1" }
    }

    private fun showNamePicker() {
        val content = verticalContent()
        content.addView(titleText("RENAME ${state.name.uppercase()}"))
        content.addView(subtitleText("Editing: ${state.dinoType} • Stage ${state.stage + 1}/4\nGive this companion a name. It will appear in bold gold above the floating dinosaur."))
        val input = EditText(this).apply {
            setSingleLine(true)
            setText(state.name)
            selectAll()
            textSize = 20f
            setTextColor(brown)
            setHintTextColor(Color.rgb(150, 130, 100))
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = rounded(Color.WHITE, 20f)
        }
        content.addView(input, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(18) })
        content.addView(buttonRow(
            styledButton("SAVE", green, 54) {
                input.text.toString().trim().take(18).takeIf { it.isNotBlank() }?.let { state.name = it }
                showHome()
            },
            styledButton("CANCEL", darkGreen, 54) { showHome() }
        ))
        showThemedDialog("RENAME DINOSAUR", content)
    }

    private fun showOverlaySettings() {
        val content = verticalContent()
        content.addView(titleText("OVERLAY SETTINGS"))
        content.addView(subtitleText("Control your floating companion without closing Dino Companion."))
        content.addView(styledButton("SHOW ${state.name.uppercase()} ON SCREEN", green, 54) {
            startCompanionService()
            showHome()
        })
        content.addView(styledButton("RESET DINO POSITION", purple, 54) {
            state.overlayX = 8
            state.overlayY = 170
            Toast.makeText(this, "Dino position reset", Toast.LENGTH_SHORT).show()
            showHome()
        })
        content.addView(styledButton("HIDE DINO FROM SCREEN", Color.rgb(228, 69, 57), 54) {
            stopCompanionService()
            showHome()
        })
        content.addView(styledButton("EVOLUTION GALLERY", gold, 54) { showEvolutionCarousel() })
        content.addView(styledButton("CLOSE", darkGreen, 52) { showHome() })
        showThemedDialog("OVERLAY SETTINGS", content)
    }

    private fun showShop() {
        val content = verticalContent()
        content.addView(titleText("DINO SHOP"))
        content.addView(subtitleText("Coins: ${state.coins}"))
        content.addView(panelText("Evolution Food can speed up growth. Premium evolution purchases are reserved for a future Google Play Billing connection."))
        content.addView(styledButton("OK", gold, 54) { showHome() })
        showThemedDialog("DINO SHOP", content)
    }

    private fun addStatRow(parent: LinearLayout, label: String, value: Float) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.WHITE, Color.rgb(250, 250, 244), Color.rgb(232, 231, 218))
            ).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(2), Color.argb(170, 255, 255, 255)) }
            elevation = dp(4).toFloat()
        }
        val text = TextView(this).apply {
            this.text = "$label  ${value.toInt()}%"
            textSize = 16f
            typeface = roundedBoldTypeface
            setTextColor(brown)
        }
        row.addView(text, LinearLayout.LayoutParams(0, dp(48), 1f))
        val status = TextView(this).apply {
            this.text = if (value >= 65) "GOOD" else if (value >= 35) "OK" else "LOW"
            textSize = 13f
            typeface = roundedBoldTypeface
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(if (value >= 65) green else if (value >= 35) gold else Color.rgb(232, 137, 36), 18f)
        }
        row.addView(status, LinearLayout.LayoutParams(dp(74), dp(40)))
        parent.addView(row, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(8) })
    }

    private fun speciesRow(name: String, imageName: String, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(12), dp(6))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.WHITE, Color.rgb(251, 255, 247), Color.rgb(232, 246, 229), Color.rgb(204, 229, 200))
            ).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(2), Color.argb(160, 255, 255, 255))
            }
            elevation = dp(10).toFloat()
            setOnClickListener { onClick() }
        }
        val img = ImageView(this).apply {
            setImageResource(resources.getIdentifier(imageName, "drawable", packageName))
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        row.addView(img, LinearLayout.LayoutParams(dp(76), dp(76)))
        row.addView(TextView(this).apply {
            text = "$name\nBABY • TAP TO VIEW EVOLUTION"
            textSize = 15f
            typeface = roundedBoldTypeface
            setTextColor(brown)
            setPadding(dp(8), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, -1, 1f))
        row.addView(TextView(this).apply {
            text = "›"
            textSize = 30f
            typeface = roundedBoldTypeface
            setTextColor(green)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(42), -1))
        return row
    }

    private fun showThemedDialog(title: String, content: View, cancelable: Boolean = true) {
        closeActiveDialog()
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            addView(content, ViewGroup.LayoutParams(-1, -2))
        }
        dialog.setContentView(scroll)
        dialog.setCancelable(cancelable)
        dialog.setCanceledOnTouchOutside(cancelable)
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_UP) {
                dialog.dismiss()
                showHome()
                true
            } else false
        }
        dialog.setOnDismissListener { if (activeDialog === dialog) activeDialog = null }
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setDimAmount(.52f)
            addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            decorView.setPadding(0, 0, 0, 0)
        }
        activeDialog = dialog
        dialog.show()
        val width = (resources.displayMetrics.widthPixels * .94).toInt()
        val maxHeight = (resources.displayMetrics.heightPixels * .84).toInt()
        dialog.window?.setLayout(width, maxHeight)
        dialog.window?.setGravity(Gravity.CENTER)
    }

    private fun verticalContent(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(18))
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.WHITE, Color.rgb(255, 252, 236), Color.rgb(244, 232, 194), Color.rgb(225, 205, 153))
        ).apply {
            cornerRadius = dp(30).toFloat()
            setStroke(dp(3), Color.argb(215, 255, 255, 255))
        }
        elevation = dp(12).toFloat()
    }

    private fun titleText(text: String) = TextView(this).apply {
        this.text = text
        textSize = 25f
        typeface = roundedBoldTypeface
        setTextColor(Color.rgb(53, 112, 67))
        gravity = Gravity.CENTER
        setShadowLayer(3f, 0f, 2f, Color.rgb(220, 185, 110))
        setPadding(0, dp(2), 0, dp(8))
    }

    private fun subtitleText(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(brown)
        gravity = Gravity.CENTER
        setPadding(dp(8), 0, dp(8), dp(14))
    }

    private fun panelText(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        typeface = roundedBoldTypeface
        setTextColor(brown)
        setPadding(dp(18), dp(18), dp(18), dp(18))
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.WHITE, Color.rgb(250, 247, 229), Color.rgb(238, 226, 192))
        ).apply {
            cornerRadius = dp(22).toFloat()
            setStroke(dp(2), Color.argb(180, 255, 255, 255))
        }
        elevation = dp(6).toFloat()
    }

    private fun styledButton(text: String, color: Int, height: Int, action: () -> Unit) =
        Button(this).apply {
            this.text = text
            textSize = if (text.length > 16) 13f else 15f
            typeface = roundedBoldTypeface
            setTextColor(Color.WHITE)
            isAllCaps = false
            stateListAnimator = null
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(lighten(color, 0.22f), color, darken(color, 0.18f))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(2), Color.argb(190, 255, 255, 255))
            }
            elevation = dp(7).toFloat()
            setPadding(dp(8), dp(3), dp(8), dp(3))
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> view.animate().scaleX(.97f).scaleY(.97f).setDuration(70).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                }
                false
            }
            setOnClickListener { action() }
        }

    private fun lighten(color: Int, amount: Float): Int {
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        return Color.rgb(
            (r + (255 - r) * amount).toInt().coerceIn(0,255),
            (g + (255 - g) * amount).toInt().coerceIn(0,255),
            (b + (255 - b) * amount).toInt().coerceIn(0,255)
        )
    }

    private fun darken(color: Int, amount: Float): Int {
        return Color.rgb(
            (Color.red(color) * (1f - amount)).toInt(),
            (Color.green(color) * (1f - amount)).toInt(),
            (Color.blue(color) * (1f - amount)).toInt()
        )
    }

    private fun buttonRow(vararg buttons: Button): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            buttons.forEachIndexed { index, b ->
                addView(b, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
                    if (index < buttons.lastIndex) marginEnd = dp(6)
                })
            }
        }

    private fun permissionBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(8, 53, 38), Color.rgb(20, 98, 67), Color.rgb(5, 37, 28))
    )

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        ) == AppOpsManager.MODE_ALLOWED
    }
}
