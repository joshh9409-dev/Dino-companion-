package com.example.dinocompanion

import android.content.Context
import kotlin.math.max
import kotlin.math.min

class DinoState(context: Context) {
    private val prefs = context.getSharedPreferences("dino_state", Context.MODE_PRIVATE)

    var dinoType: String
        get() = prefs.getString("species", "T-Rex") ?: "T-Rex"
        set(value) = prefs.edit().putString("species", value).apply()


    var stage: Int
        get() = prefs.getInt("stage", 0)
        set(value) = prefs.edit().putInt("stage", value.coerceIn(0, 3)).apply()

    var name: String
        get() = prefs.getString("name", "Rex") ?: "Rex"
        set(value) = prefs.edit().putString("name", value).apply()

    var birthTime: Long
        get() = prefs.getLong("birth_time", 0L)
        set(value) = prefs.edit().putLong("birth_time", value).apply()

    var hunger: Float
        get() = prefs.getFloat("hunger", 78f)
        set(value) = prefs.edit().putFloat("hunger", clamp(value)).apply()

    var happiness: Float
        get() = prefs.getFloat("happiness", 85f)
        set(value) = prefs.edit().putFloat("happiness", clamp(value)).apply()

    var energy: Float
        get() = prefs.getFloat("energy", 82f)
        set(value) = prefs.edit().putFloat("energy", clamp(value)).apply()

    var cleanliness: Float
        get() = prefs.getFloat("cleanliness", 90f)
        set(value) = prefs.edit().putFloat("cleanliness", clamp(value)).apply()

    var bond: Float
        get() = prefs.getFloat("bond", 8f)
        set(value) = prefs.edit().putFloat("bond", clamp(value)).apply()

    var coins: Int
        get() = prefs.getInt("coins", 50)
        set(value) = prefs.edit().putInt("coins", max(0, value)).apply()

    var evolutionFood: Int
        get() = prefs.getInt("evolution_food", 0)
        set(value) = prefs.edit().putInt("evolution_food", max(0, value)).apply()

    var currentAction: String
        get() = prefs.getString("current_action", "") ?: ""
        set(value) = prefs.edit().putString("current_action", value).apply()

    var freeEvolutionUsed: Boolean
        get() = prefs.getBoolean("free_evolution_used", false)
        set(value) = prefs.edit().putBoolean("free_evolution_used", value).apply()

    var overlayX: Int
        get() = prefs.getInt("overlay_x", 8)
        set(value) = prefs.edit().putInt("overlay_x", value).apply()

    var overlayY: Int
        get() = prefs.getInt("overlay_y", 170)
        set(value) = prefs.edit().putInt("overlay_y", value).apply()

    var overlayVisible: Boolean
        get() = prefs.getBoolean("overlay_visible", true)
        set(value) = prefs.edit().putBoolean("overlay_visible", value).apply()

    fun ensureStarted() {
        if (birthTime == 0L) birthTime = System.currentTimeMillis()
    }

    fun evolutionHours(): Double {
        val ageMs = System.currentTimeMillis() - birthTime
        return max(0L, ageMs).toDouble() / 3_600_000.0
    }

    fun requiredHours(): Double = when (stage) {
        0 -> 24.0
        1 -> 72.0
        else -> 168.0
    }

    fun evolutionProgress(): Int {
        val required = requiredHours()
        return min(100, ((evolutionHours() / required) * 100.0).toInt())
    }

    fun canEvolve(): Boolean = stage < 3 && evolutionProgress() >= 100

    fun evolve(): Boolean {
        if (!canEvolve()) return false
        stage += 1
        if (stage == 1) freeEvolutionUsed = true
        hunger = min(hunger, 82f)
        energy = min(energy, 88f)
        happiness = min(100f, happiness + 20f)
        bond = min(100f, bond + 10f)
        return true
    }

    fun feed(amount: Float = 20f) {
        hunger = min(100f, hunger + amount)
        happiness = min(100f, happiness + 5f)
        bond = min(100f, bond + 1.5f)
        coins += 1
    }

    fun pet() {
        happiness = min(100f, happiness + 7f)
        bond = min(100f, bond + 2f)
        coins += 1
    }

    fun play() {
        happiness = min(100f, happiness + 15f)
        energy = max(0f, energy - 10f)
        hunger = max(0f, hunger - 5f)
        bond = min(100f, bond + 3f)
        coins += 5
    }

    fun clean() {
        cleanliness = 100f
        happiness = min(100f, happiness + 3f)
        coins += 2
    }

    fun applyTimeDecay() {
        if (birthTime == 0L) return
        val now = System.currentTimeMillis()
        val last = prefs.getLong("last_tick", now)
        val hours = ((now - last).coerceAtLeast(0L)).toDouble() / 3_600_000.0
        if (hours > 0.02) {
            hunger = hunger - (hours * 5.0).toFloat()
            energy = energy - (hours * 3.0).toFloat()
            cleanliness = cleanliness - (hours * 2.0).toFloat()
            happiness = happiness - (hours * 1.5).toFloat()
            prefs.edit().putLong("last_tick", now).apply()
        }
    }

    private fun clamp(value: Float): Float = value.coerceIn(0f, 100f)
}
