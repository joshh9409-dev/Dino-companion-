package com.example.dinocompanion

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

class HomeArtworkView(
    context: Context,
    private val onFoodCare: () -> Unit,
    private val onRename: () -> Unit,
    private val onChoose: () -> Unit,
    private val onOverlaySettings: () -> Unit,
    private val onShop: () -> Unit
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.home_reference)

    // The artwork is 1024 x 1461. Each target follows the centre of the
    // corresponding circular bubble button in that artwork.
    private val buttons = listOf(
        ButtonTarget(218f, 982f, 137f) { onFoodCare() },
        ButtonTarget(512f, 982f, 137f) { onRename() },
        ButtonTarget(808f, 982f, 137f) { onChoose() },
        ButtonTarget(354f, 1200f, 137f) { onOverlaySettings() },
        ButtonTarget(666f, 1200f, 137f) { onShop() }
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(125, 205, 244))
        canvas.drawBitmap(bitmap, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_UP || width <= 0 || height <= 0) return true
        val scaleX = 1024f / width.toFloat()
        val scaleY = 1461f / height.toFloat()
        val x = event.x * scaleX
        val y = event.y * scaleY
        buttons.firstOrNull {
            val dx = x - it.x
            val dy = y - it.y
            hypot(dx.toDouble(), dy.toDouble()) <= it.radius
        }?.action?.invoke()
        return true
    }

    private data class ButtonTarget(
        val x: Float,
        val y: Float,
        val radius: Float,
        val action: () -> Unit
    )
}
