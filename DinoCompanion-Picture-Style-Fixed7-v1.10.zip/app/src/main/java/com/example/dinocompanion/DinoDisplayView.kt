package com.example.dinocompanion

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

/** Full-body floating companion with a generous transparent canvas. */
class DinoDisplayView(
    context: Context,
    private val state: DinoState,
    private val compact: Boolean = false,
    private val homeMode: Boolean = false,
    private val onAction: ((String) -> Unit)? = null,
    private val onDragPosition: ((Float, Float) -> Unit)? = null,
    private val onOpenMenu: (() -> Unit)? = null,
    private val onHide: (() -> Unit)? = null
) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * density).toInt()

    private val nameText = TextView(context).apply {
        textSize = 17f
        setTextColor(Color.rgb(239, 177, 43))
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setShadowLayer(5f, 0f, 2f, Color.rgb(80, 45, 10))
        maxLines = 1
    }

    private val actionText = TextView(context).apply {
        textSize = 11f
        setTextColor(Color.rgb(86, 61, 34))
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        maxLines = 2
        setPadding(dp(8f), dp(3f), dp(8f), dp(3f))
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.WHITE, Color.rgb(255, 250, 231), Color.rgb(239, 228, 195))
        ).apply {
            cornerRadius = dp(14f).toFloat()
            setStroke(dp(1.5f), Color.argb(210, 255, 255, 255))
        }
        elevation = dp(4f).toFloat()
        visibility = GONE
    }

    /* The actual dino gets a large, transparent, head-to-toe canvas. */
    private val imageView = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        adjustViewBounds = true
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = false
        isFocusable = false
        pivotX = 0.5f
        pivotY = 0.9f
        clipToOutline = false
    }

    private val controls = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(dp(2f), 0, dp(2f), 0)
        alpha = 0f
        visibility = GONE
    }

    private var animation: AnimationDrawable? = null
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var actionReset: Runnable? = null
    private var idleBob: ObjectAnimator? = null

    init {
        setWillNotDraw(true)
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
        isFocusable = true
        clipChildren = false
        clipToPadding = false

        addView(nameText, LayoutParams(-1, dp(27f)).apply { gravity = Gravity.TOP })
        addView(actionText, LayoutParams(dp(255f), dp(48f)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = dp(28f)
        })
        addView(imageView, LayoutParams(dp(132f), dp(190f)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = dp(70f)
        })
        addView(controls, LayoutParams(dp(236f), dp(48f)).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(3f)
        })

        controls.addView(bubble("MENU", Color.rgb(71, 161, 91)) { onOpenMenu?.invoke() },
            LinearLayout.LayoutParams(dp(72f), dp(46f)).apply { marginEnd = dp(5f) })
        controls.addView(bubble("HIDE", Color.rgb(225, 77, 61)) { onHide?.invoke() },
            LinearLayout.LayoutParams(dp(72f), dp(46f)).apply { marginEnd = dp(5f) })
        controls.addView(bubble("INFO", Color.rgb(118, 77, 197)) { showStatus() },
            LinearLayout.LayoutParams(dp(72f), dp(46f)))

        setDinoAnimation()
        refreshLabels()
        startIdleBob()
    }

    private fun bubble(label: String, color: Int, click: () -> Unit) = TextView(context).apply {
        text = label
        textSize = 10f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(lighten(color, .28f), color, darken(color, .20f))
        ).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(2f), Color.argb(230, 255, 255, 255))
        }
        elevation = dp(6f).toFloat()
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
    }

    private fun lighten(color: Int, amount: Float): Int = Color.rgb(
        (Color.red(color) + (255 - Color.red(color)) * amount).toInt(),
        (Color.green(color) + (255 - Color.green(color)) * amount).toInt(),
        (Color.blue(color) + (255 - Color.blue(color)) * amount).toInt()
    )

    private fun darken(color: Int, amount: Float): Int = Color.rgb(
        (Color.red(color) * (1f - amount)).toInt(),
        (Color.green(color) * (1f - amount)).toInt(),
        (Color.blue(color) * (1f - amount)).toInt()
    )

    private fun startIdleBob() {
        idleBob?.cancel()
        idleBob = ObjectAnimator.ofFloat(imageView, View.TRANSLATION_Y, 0f, -dp(4f).toFloat()).apply {
            duration = 950L
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun stageNumber(): Int = (state.stage + 1).coerceIn(1, 4)

    private fun currentDinoType(): String = context.getSharedPreferences("dino_state", Context.MODE_PRIVATE)
        .getString("species", "T-Rex") ?: "T-Rex"

    private fun frameIds(species: String, stage: Int): IntArray {
        val s = stage.coerceIn(1, 4)
        return when (species.lowercase()) {
            "t-rex", "trex" -> when (s) {
                1 -> intArrayOf(R.drawable.trex_overlay_stage1, R.drawable.trex_overlay_stage1, R.drawable.trex_overlay_stage1)
                2 -> intArrayOf(R.drawable.trex_overlay_stage2, R.drawable.trex_overlay_stage2, R.drawable.trex_overlay_stage2)
                3 -> intArrayOf(R.drawable.trex_overlay_stage3, R.drawable.trex_overlay_stage3, R.drawable.trex_overlay_stage3)
                else -> intArrayOf(R.drawable.trex_overlay_stage4, R.drawable.trex_overlay_stage4, R.drawable.trex_overlay_stage4)
            }
            "triceratops" -> when (s) {
                1 -> intArrayOf(R.drawable.triceratops_stage1_f1, R.drawable.triceratops_stage1_f2, R.drawable.triceratops_stage1_f3)
                2 -> intArrayOf(R.drawable.triceratops_stage2_f1, R.drawable.triceratops_stage2_f2, R.drawable.triceratops_stage2_f3)
                3 -> intArrayOf(R.drawable.triceratops_stage3_f1, R.drawable.triceratops_stage3_f2, R.drawable.triceratops_stage3_f3)
                else -> intArrayOf(R.drawable.triceratops_stage4_f1, R.drawable.triceratops_stage4_f2, R.drawable.triceratops_stage4_f3)
            }
            "pterodactyl" -> when (s) {
                1 -> intArrayOf(R.drawable.pterodactyl_stage1_f1, R.drawable.pterodactyl_stage1_f2, R.drawable.pterodactyl_stage1_f3)
                2 -> intArrayOf(R.drawable.pterodactyl_stage2_f1, R.drawable.pterodactyl_stage2_f2, R.drawable.pterodactyl_stage2_f3)
                3 -> intArrayOf(R.drawable.pterodactyl_stage3_f1, R.drawable.pterodactyl_stage3_f2, R.drawable.pterodactyl_stage3_f3)
                else -> intArrayOf(R.drawable.pterodactyl_stage4_f1, R.drawable.pterodactyl_stage4_f2, R.drawable.pterodactyl_stage4_f3)
            }
            "stegosaurus" -> when (s) {
                1 -> intArrayOf(R.drawable.stegosaurus_stage1_f1, R.drawable.stegosaurus_stage1_f2, R.drawable.stegosaurus_stage1_f3)
                2 -> intArrayOf(R.drawable.stegosaurus_stage2_f1, R.drawable.stegosaurus_stage2_f2, R.drawable.stegosaurus_stage2_f3)
                3 -> intArrayOf(R.drawable.stegosaurus_stage3_f1, R.drawable.stegosaurus_stage3_f2, R.drawable.stegosaurus_stage3_f3)
                else -> intArrayOf(R.drawable.stegosaurus_stage4_f1, R.drawable.stegosaurus_stage4_f2, R.drawable.stegosaurus_stage4_f3)
            }
            else -> intArrayOf(R.drawable.trex_overlay_stage1, R.drawable.trex_overlay_stage1, R.drawable.trex_overlay_stage1)
        }
    }

    private fun setDinoAnimation() {
        animation?.stop()
        val stage = stageNumber()
        val next = AnimationDrawable().apply {
            isOneShot = false
            frameIds(currentDinoType(), stage).forEach { id ->
                addFrame(resources.getDrawable(id, null), 220)
            }
        }
        animation = next
        imageView.setImageDrawable(next)
        imageView.animate().cancel()
        imageView.translationX = 0f
        imageView.translationY = 0f
        imageView.rotation = 0f
        imageView.scaleX = when (stage) {
            1 -> 0.68f
            2 -> 0.78f
            3 -> 0.89f
            else -> 1.0f
        }
        imageView.scaleY = imageView.scaleX
        next.start()
        if (idleBob?.isRunning != true) startIdleBob()
    }

    fun refresh() {
        val currentTag = "${currentDinoType()}:${stageNumber()}"
        if (imageView.tag != currentTag) {
            imageView.tag = currentTag
            setDinoAnimation()
        }
        animation?.let { if (!it.isRunning) it.start() }
        refreshLabels()
    }

    private fun refreshLabels() {
        nameText.text = state.name
        actionText.text = if (state.currentAction.isBlank()) "" else state.currentAction
        actionText.visibility = if (state.currentAction.isBlank()) GONE else VISIBLE
    }

    fun showStatus() {
        val status = "${state.name}  •  STATUS\nHunger ${state.hunger.toInt()}%   •   Happy ${state.happiness.toInt()}%   •   Energy ${state.energy.toInt()}%"
        showAction(status, false)
    }

    fun showAction(action: String, showStats: Boolean = true) {
        state.currentAction = action
        refreshLabels()
        idleBob?.cancel()
        imageView.animate().cancel()
        imageView.translationY = 0f
        when {
            action.contains("Pet", true) || action.contains("petted", true) -> imageView.animate()
                .rotation(-3f).translationY(-dp(5f).toFloat()).setDuration(120).withEndAction {
                    imageView.animate().rotation(0f).translationY(0f).setDuration(220).start()
                }.start()
            action.contains("Eat", true) || action.contains("Eating", true) -> imageView.animate()
                run {
                    val baseScale = when (stageNumber()) { 1 -> 0.68f; 2 -> 0.78f; 3 -> 0.89f; else -> 1.0f }
                    imageView.animate().scaleX(baseScale * 1.035f).scaleY(baseScale * 1.035f).setDuration(120).withEndAction {
                        imageView.animate().scaleX(baseScale).scaleY(baseScale).setDuration(220).start()
                    }.start()
                }
            action.contains("Play", true) || action.contains("Moving", true) -> imageView.animate()
                .rotation(3f).translationY(-dp(2f).toFloat()).setDuration(110).withEndAction {
                    imageView.animate().rotation(0f).translationY(0f).setDuration(180).start()
                }.start()
        }
        actionReset?.let { removeCallbacks(it) }
        actionReset = Runnable {
            state.currentAction = ""
            refreshLabels()
            startIdleBob()
        }
        postDelayed(actionReset!!, if (showStats) 2200L else 2600L)
        onAction?.invoke(action)
    }

    private fun revealControls() {
        controls.visibility = VISIBLE
        controls.animate().cancel()
        controls.animate().alpha(1f).setDuration(140).start()
    }

    override fun onDetachedFromWindow() {
        idleBob?.cancel()
        idleBob = null
        actionReset?.let { removeCallbacks(it) }
        animation?.stop()
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragging && hypot(dx.toDouble(), dy.toDouble()) > dp(7f)) dragging = true
                if (dragging) {
                    onDragPosition?.invoke(dx, dy)
                    showAction("Moving me", false)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (dragging) return true
                val inDinoArea = event.x >= imageView.left - dp(16f) &&
                    event.x <= imageView.right + dp(16f) &&
                    event.y >= imageView.top - dp(16f) &&
                    event.y <= imageView.bottom + dp(16f)
                if (!inDinoArea) return true
                revealControls()
                idleBob?.cancel()
                imageView.animate().cancel()
                val baseScale = when (stageNumber()) {
                    1 -> 0.68f
                    2 -> 0.78f
                    3 -> 0.89f
                    else -> 1.0f
                }
                imageView.animate().scaleX(baseScale * 1.025f).scaleY(baseScale * 1.025f).setDuration(90).withEndAction {
                    imageView.animate().scaleX(baseScale).scaleY(baseScale).setDuration(150).withEndAction { startIdleBob() }.start()
                }.start()
                val now = System.currentTimeMillis()
                if (now - lastTap < 420L) {
                    state.feed(20f)
                    showAction("Eating", false)
                } else {
                    state.pet()
                    showAction("Being petted", false)
                }
                lastTap = now
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }
}
