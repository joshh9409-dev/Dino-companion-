package com.example.dinocompanion

import android.Manifest
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var state: DinoState
    private lateinit var ui: DinoGameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = DinoState(this)
        state.ensureStarted()
        state.applyTimeDecay()
        ui = DinoGameView(this, state)
        setContentView(ui)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (ui.page != DinoGameView.Page.HOME) ui.goHome() else finish()
            }
        })
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 401)
        }
    }

    fun renameCompanion() {
        val edit = EditText(this).apply {
            setText(state.name)
            setSelection(text.length)
            hint = "Dino name"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        AlertDialog.Builder(this)
            .setTitle("NAME YOUR DINO")
            .setMessage("Choose a name for your companion.")
            .setView(edit)
            .setPositiveButton("SAVE") { _, _ ->
                val name = edit.text.toString().trim().take(18)
                if (name.isNotBlank()) state.name = name
                ui.invalidate()
                sendActiveChanged()
            }
            .setNegativeButton("CLOSE", null)
            .show()
        edit.post {
            edit.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    fun sendActiveChanged() {
        sendBroadcast(Intent(DinoPreferences.ACTION_ACTIVE_DINO_CHANGED).setPackage(packageName))
    }

    fun spawnDino() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Dino Companion to display over other apps, then tap Spawn again.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
            return
        }
        state.overlayVisible = true
        val intent = Intent(this, DinoOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        ui.invalidate()
    }

    fun hideDino() {
        state.overlayVisible = false
        stopService(Intent(this, DinoOverlayService::class.java))
        ui.invalidate()
    }
}

private class DinoGameView(private val ctx: Context, private val state: DinoState) : android.view.View(ctx) {
    enum class Page { HOME, INVENTORY, CARE, PLAY, EVOLVE, SHOP, SETTINGS, SELECT }
    var page = Page.HOME
    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = (v * density).coerceAtLeast(1f)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bold = Typeface.create("sans-serif-rounded", Typeface.BOLD)
    private val normal = Typeface.create("sans-serif-rounded", Typeface.NORMAL)
    private val dinoBitmaps = mutableMapOf<String, Bitmap>()
    private var selectorIndex = 0
    private var selectorDownX = 0f
    private var selectorDragging = false
    private var selectedLocked = true
    private val species = listOf("T-Rex", "Triceratops", "Pterodactyl", "Stegosaurus")
    private val defaultNames = mapOf("T-Rex" to "Rex", "Triceratops" to "Trixie", "Pterodactyl" to "Sky", "Stegosaurus" to "Steggy")
    private var dialog: Dialog? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        selectorIndex = species.indexOf(state.dinoType).coerceAtLeast(0)
        loadBitmaps()
    }

    private fun loadBitmaps() {
        species.forEach { id ->
            val res = when (id) {
                "T-Rex" -> R.drawable.trex_stage1_f1
                "Triceratops" -> R.drawable.triceratops_stage1_f1
                "Pterodactyl" -> R.drawable.pterodactyl_stage1_f1
                else -> R.drawable.stegosaurus_stage1_f1
            }
            dinoBitmaps[id] = BitmapFactory.decodeResource(resources, res)
        }
        // Preload evolved art for quick page changes.
        species.forEach { id ->
            (1..4).forEach { stage ->
                val res = frameRes(id, stage, 1)
                BitmapFactory.decodeResource(resources, res)
            }
        }
    }

    private fun frameRes(id: String, stage: Int, frame: Int): Int = when (id) {
        "T-Rex" -> when(stage){1->listOf(R.drawable.trex_stage1_f1,R.drawable.trex_stage1_f2,R.drawable.trex_stage1_f3)[frame-1];2->listOf(R.drawable.trex_stage2_f1,R.drawable.trex_stage2_f2,R.drawable.trex_stage2_f3)[frame-1];3->listOf(R.drawable.trex_stage3_f1,R.drawable.trex_stage3_f2,R.drawable.trex_stage3_f3)[frame-1];else->listOf(R.drawable.trex_stage4_f1,R.drawable.trex_stage4_f2,R.drawable.trex_stage4_f3)[frame-1]}
        "Triceratops" -> when(stage){1->listOf(R.drawable.triceratops_stage1_f1,R.drawable.triceratops_stage1_f2,R.drawable.triceratops_stage1_f3)[frame-1];2->listOf(R.drawable.triceratops_stage2_f1,R.drawable.triceratops_stage2_f2,R.drawable.triceratops_stage2_f3)[frame-1];3->listOf(R.drawable.triceratops_stage3_f1,R.drawable.triceratops_stage3_f2,R.drawable.triceratops_stage3_f3)[frame-1];else->listOf(R.drawable.triceratops_stage4_f1,R.drawable.triceratops_stage4_f2,R.drawable.triceratops_stage4_f3)[frame-1]}
        "Pterodactyl" -> when(stage){1->listOf(R.drawable.pterodactyl_stage1_f1,R.drawable.pterodactyl_stage1_f2,R.drawable.pterodactyl_stage1_f3)[frame-1];2->listOf(R.drawable.pterodactyl_stage2_f1,R.drawable.pterodactyl_stage2_f2,R.drawable.pterodactyl_stage2_f3)[frame-1];3->listOf(R.drawable.pterodactyl_stage3_f1,R.drawable.pterodactyl_stage3_f2,R.drawable.pterodactyl_stage3_f3)[frame-1];else->listOf(R.drawable.pterodactyl_stage4_f1,R.drawable.pterodactyl_stage4_f2,R.drawable.pterodactyl_stage4_f3)[frame-1]}
        else -> when(stage){1->listOf(R.drawable.stegosaurus_stage1_f1,R.drawable.stegosaurus_stage1_f2,R.drawable.stegosaurus_stage1_f3)[frame-1];2->listOf(R.drawable.stegosaurus_stage2_f1,R.drawable.stegosaurus_stage2_f2,R.drawable.stegosaurus_stage2_f3)[frame-1];3->listOf(R.drawable.stegosaurus_stage3_f1,R.drawable.stegosaurus_stage3_f2,R.drawable.stegosaurus_stage3_f3)[frame-1];else->listOf(R.drawable.stegosaurus_stage4_f1,R.drawable.stegosaurus_stage4_f2,R.drawable.stegosaurus_stage4_f3)[frame-1]}
    }

    fun goHome() { page = Page.HOME; invalidate() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        drawBackground(c)
        when(page) {
            Page.HOME -> drawHome(c)
            Page.INVENTORY -> drawInventory(c)
            Page.CARE -> drawCare(c)
            Page.PLAY -> drawPlay(c)
            Page.EVOLVE -> drawEvolve(c)
            Page.SHOP -> drawShop(c)
            Page.SETTINGS -> drawSettings(c)
            Page.SELECT -> drawSelector(c)
        }
    }

    private fun drawBackground(c: Canvas) {
        val grad = LinearGradient(0f, 0f, 0f, height.toFloat(), Color.rgb(116,205,238), Color.rgb(197,235,171), Shader.TileMode.CLAMP)
        paint.shader = grad; c.drawRect(0f,0f,width.toFloat(),height.toFloat(),paint); paint.shader=null
        paint.color = Color.argb(90,255,255,255)
        repeat(8){ i -> c.drawCircle((i*97+35)%width.toFloat(), dp(70f)+(i*83)%dp(230f), dp(35f), paint) }
        paint.color = Color.rgb(72,154,79)
        c.drawRect(0f, height-dp(150f), width.toFloat(), height.toFloat(), paint)
        paint.color = Color.rgb(45,120,69)
        for(i in 0..8){ val x=(i*83+20)%width; c.drawCircle(x.toFloat(), (height-dp(115f)+(i%3)*22).toFloat(), dp(48f), paint) }
    }

    private fun top(c: Canvas, title: String, back: Boolean = false) {
        pill(c, dp(14f), dp(14f), dp(122f), dp(42f), Color.argb(220,255,250,231))
        text(c, if(back) "‹  $title" else title, dp(28f), dp(42f), 20f, Color.rgb(67,52,33), true)
        pill(c, width-dp(122f), dp(14f), dp(108f), dp(42f), Color.argb(220,255,250,231))
        text(c, "⚙", width-dp(93f), dp(43f), 21f, Color.rgb(67,52,33), true)
    }

    private fun drawHome(c: Canvas) {
        top(c,"DINO COMPANION")
        // Progress bar
        val bx=dp(28f); val by=dp(72f); val bw=width-dp(150f)
        text(c,"EVOLUTION",bx,by+dp(14f),12f,Color.WHITE,true)
        roundRect(c,bx,by+dp(20f),bw,dp(17f),Color.argb(210,255,250,231),dp(9f))
        roundRect(c,bx,by+dp(20f),bw*(state.evolutionProgress()/100f),dp(17f),Color.rgb(87,188,91),dp(9f))
        text(c,"+",width-dp(116f),by+dp(35f),25f,Color.WHITE,true)
        text(c,"SHOP",width-dp(89f),by+dp(14f),11f,Color.WHITE,true)

        // Side stats
        statPill(c,dp(14f),dp(155f),"HAPPY",state.happiness, false)
        statPill(c,dp(14f),dp(205f),"HUNGER",state.hunger, false)
        statPill(c,dp(14f),dp(255f),"THIRST",state.thirst, false)
        statPill(c,width-dp(142f),dp(155f),"ENERGY",state.energy, true)
        statPill(c,width-dp(142f),dp(205f),"HEALTH",state.health, true)
        statPill(c,width-dp(142f),dp(255f),"BOND",state.bond, true)

        drawEgg(c,width/2f,dp(250f),dp(125f),dp(170f),true)
        text(c,state.dinoType.uppercase(),width/2f,dp(382f),14f,Color.WHITE,true,Paint.Align.CENTER)
        text(c,state.name,width/2f,dp(410f),27f,Color.rgb(255,237,178),true,Paint.Align.CENTER)
        text(c,"✎",width/2f+dp(58f),dp(410f),18f,Color.WHITE,true,Paint.Align.CENTER)

        val y=dp(445f); val gap=dp(9f); val w=(width-dp(32f)-gap*2)/3f
        button(c,dp(16f),y,w,dp(58f),"INVENTORY") { page=Page.INVENTORY; invalidate() }
        button(c,dp(16f)+w+gap,y,w,dp(58f),"FOOD & CARE") { page=Page.CARE; invalidate() }
        button(c,dp(16f)+(w+gap)*2,y,w,dp(58f),"EVOLVE") { page=Page.EVOLVE; invalidate() }
        button(c,dp(16f),y+dp(72f),width-dp(32f),dp(62f),if(state.overlayVisible) "HIDE DINO" else "SPAWN DINO") {
            if(state.overlayVisible) (ctx as MainActivity).hideDino() else (ctx as MainActivity).spawnDino()
        }
        text(c,"Tap the Dino in the egg to choose another companion",width/2f,height-dp(26f),11f,Color.WHITE,false,Paint.Align.CENTER)
    }

    private fun drawInventory(c: Canvas) {
        top(c,"INVENTORY",true)
        headerDino(c, "INVENTORY • ${state.name}")
        val tabs=listOf("ALL","FOOD","TOYS","DECOR","SPECIAL")
        tabs.forEachIndexed{ i,t -> button(c,dp(10f)+i*dp(70f),dp(342f),dp(64f),dp(38f),t,small=true){invalidate()} }
        val names=listOf("Apple","Banana","Berry","Golden Fruit","Ball","Bone","Leaf Crown","Mystic Egg")
        names.forEachIndexed{ i,n ->
            val col=i%2; val row=i/2; val x=dp(16f)+col*dp(151f); val y=dp(392f)+row*dp(72f)
            val rarity=when(i){0,1,2->Color.rgb(63,137,218);3,4->Color.rgb(126,76,211);5,6->Color.LTGRAY;else->Color.rgb(232,181,51)}
            roundRect(c,x,y,dp(140f),dp(60f),rarity,dp(14f)); text(c,n,x+dp(12f),y+dp(25f),14f,Color.WHITE,true); text(c,"×${i+2}",x+dp(12f),y+dp(47f),12f,Color.WHITE)
            text(c,"USE",x+dp(104f),y+dp(36f),11f,Color.WHITE,true,Paint.Align.CENTER)
        }
        text(c,"Tap an item for details and USE / CLOSE",width/2f,height-dp(22f),11f,Color.WHITE,false,Paint.Align.CENTER)
    }

    private fun headerDino(c:Canvas,label:String){
        text(c,label,width/2f,dp(80f),18f,Color.WHITE,true,Paint.Align.CENTER)
        statPill(c,dp(12f),dp(95f),"HAPPY",state.happiness,false);statPill(c,dp(12f),dp(132f),"HUNGER",state.hunger,false);statPill(c,dp(12f),dp(169f),"THIRST",state.thirst,false)
        statPill(c,width-dp(132f),dp(95f),"ENERGY",state.energy,true);statPill(c,width-dp(132f),dp(132f),"HEALTH",state.health,true);statPill(c,width-dp(132f),dp(169f),"BOND",state.bond,true)
        drawDino(c,width/2f,dp(157f),dp(145f),state.dinoType,state.stage+1,1f)
    }

    private fun drawCare(c: Canvas){
        top(c,"FOOD & CARE",true); headerDino(c,"FOOD & CARE")
        val y=dp(300f)
        button(c,dp(16f),y,width-dp(32f),dp(58f),"FEED • OPEN FOOD") { page=Page.INVENTORY; invalidate() }
        button(c,dp(16f),y+dp(70f),width-dp(32f),dp(58f),"PLAY • MINI GAMES") { page=Page.PLAY; invalidate() }
        button(c,dp(16f),y+dp(140f),width-dp(32f),dp(58f),"CARE • WASH / SLEEP / DOCTOR") { careDialog() }
        text(c,"Everything in Care happens automatically when tapped.",width/2f,height-dp(25f),11f,Color.WHITE,false,Paint.Align.CENTER)
    }

    private fun careDialog(){
        AlertDialog.Builder(ctx).setTitle("CARE")
            .setItems(arrayOf("WASH / CLEAN","SLEEP","DOCTOR")){ _,which ->
                when(which){
                    0->{state.cleanliness=100f;state.happiness=(state.happiness+3).coerceAtMost(100f);state.currentAction="Clean";state.coins+=2}
                    1->{state.energy=100f;state.happiness=(state.happiness+2).coerceAtMost(100f);state.currentAction="Sleeping"}
                    2->{state.health=100f;state.currentAction="HEALTH OK"}
                }
                invalidate(); Toast.makeText(ctx, when(which){0->"Washed and clean";1->"Rested and refreshed";else->"🌡️ HEALTH OK"},Toast.LENGTH_SHORT).show()
            }.setNegativeButton("CLOSE",null).show()
    }

    private fun drawPlay(c:Canvas){
        top(c,"PLAY GAMES",true); headerDino(c,"PLAY")
        val games=listOf("BUBBLE POP","CATCH THE FOOD","FRUIT TOSS")
        games.forEachIndexed{ i,g ->
            val y=dp(300f)+i*dp(82f); roundRect(c,dp(16f),y,width-dp(32f),dp(68f),Color.argb(225,72,116,67),dp(18f)); text(c,g,dp(34f),y+dp(29f),17f,Color.WHITE,true); text(c,"PLAY",width-dp(66f),y+dp(29f),12f,Color.rgb(255,237,178),true,Paint.Align.CENTER)
        }
        text(c,"Win mini-games for coins + a chance at an item.",width/2f,height-dp(24f),11f,Color.WHITE,false,Paint.Align.CENTER)
    }

    private fun drawEvolve(c:Canvas){
        top(c,"EVOLVE",true); headerDino(c,"EVOLUTION PATH")
        val stages=listOf("BABY","JUVENILE","YOUNG","ADULT")
        stages.forEachIndexed{ i,s ->
            val x=dp(10f)+i*dp(94f); val unlocked=i<=state.stage; val col=if(unlocked)Color.argb(230,74,150,84) else Color.argb(150,95,95,95)
            roundRect(c,x,dp(292f),dp(84f),dp(92f),col,dp(16f)); text(c,s,x+dp(42f),dp(318f),11f,Color.WHITE,true,Paint.Align.CENTER)
            drawDino(c,x+dp(42f),dp(351f),dp(50f),state.dinoType,i+1,if(unlocked)1f else .22f)
            if(!unlocked) text(c,"🔒",x+dp(68f),dp(310f),13f,Color.WHITE,true,Paint.Align.CENTER)
        }
        text(c,"NEXT STAGE REQUIREMENTS",width/2f,dp(407f),13f,Color.WHITE,true,Paint.Align.CENTER)
        text(c,"Level • Happiness • Bond • Days cared for",width/2f,dp(431f),12f,Color.WHITE,false,Paint.Align.CENTER)
        val can=state.canEvolve()
        button(c,dp(24f),dp(452f),width-dp(48f),dp(60f),if(can)"EVOLVE NOW" else "KEEP CARING • ${state.evolutionProgress()}%",enabled=can){ if(can) evolveNow() }
    }

    private fun evolveNow(){
        val oldName=state.name
        if(!state.evolve()) return
        if(Build.VERSION.SDK_INT >= 26) ctx.getSystemService(android.os.Vibrator::class.java)?.vibrate(android.os.VibrationEffect.createOneShot(420L, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
        val white=View(ctx).apply{setBackgroundColor(Color.WHITE);alpha=0f}
        (ctx as MainActivity).addContentView(white, android.view.ViewGroup.LayoutParams(-1,-1))
        white.animate().alpha(1f).setDuration(170L).withEndAction{
            invalidate()
            white.animate().alpha(0f).setDuration(260L).withEndAction{
                (white.parent as? android.view.ViewGroup)?.removeView(white)
                AlertDialog.Builder(ctx).setTitle("YOUR DINO EVOLVED!").setMessage("Keep the name $oldName?")
                    .setPositiveButton("KEEP NAME",null).setNegativeButton("CHANGE NAME"){_,_->(ctx as MainActivity).renameCompanion()}.show()
            }.start()
        }.start()
        (ctx as MainActivity).sendActiveChanged()
    }

    private fun drawShop(c:Canvas){
        top(c,"SHOP",true); text(c,"COINS  ${state.coins}",dp(18f),dp(88f),16f,Color.WHITE,true); text(c,"PREMIUM",width-dp(18f),dp(88f),16f,Color.rgb(255,237,178),true,Paint.Align.RIGHT)
        val items=listOf("Golden Fruit" to "80 coins","Rare Toy" to "150 coins","Epic Decor" to "300 coins","Legendary Skin" to "£1.99")
        items.forEachIndexed{ i,(name,price)-> val y=dp(115f)+i*dp(86f); roundRect(c,dp(16f),y,width-dp(32f),dp(70f),when(i){0->Color.rgb(63,137,218);1->Color.rgb(126,76,211);2->Color.rgb(232,181,51);else->Color.rgb(170,55,55)},dp(18f));text(c,name,dp(32f),y+dp(29f),16f,Color.WHITE,true);text(c,price,width-dp(32f),y+dp(29f),13f,Color.WHITE,true,Paint.Align.RIGHT);button(c,width-dp(118f),y+dp(38f),dp(86f),dp(26f),"GET",small=true){ if(i<3){state.coins=(state.coins-(80+i*70)).coerceAtLeast(0);invalidate()}else Toast.makeText(ctx,"Premium purchase placeholder",Toast.LENGTH_SHORT).show() }} }
        text(c,"Legendary items are premium-only and cosmetic.",width/2f,height-dp(24f),11f,Color.WHITE,false,Paint.Align.CENTER)
    }

    private fun drawSettings(c:Canvas){
        top(c,"SETTINGS",true)
        val rows=listOf("HUNGER NOTIFICATIONS","THIRST NOTIFICATIONS","SLEEP NOTIFICATIONS","HEALTH NOTIFICATIONS","EVOLUTION NOTIFICATIONS","OVERLAY POSITION","SOUND")
        rows.forEachIndexed{ i,r -> val y=dp(85f)+i*dp(55f); roundRect(c,dp(16f),y,width-dp(32f),dp(44f),Color.argb(210,255,250,231),dp(14f));text(c,r,dp(30f),y+dp(28f),13f,Color.rgb(67,52,33),true);text(c,if(i<5)"ON" else "OPEN",width-dp(30f),y+dp(28f),12f,Color.rgb(50,140,70),true,Paint.Align.RIGHT)}
        text(c,"Overlay stays where you drop it. Fold/unfold preserves position.",width/2f,height-dp(24f),11f,Color.WHITE,false,Paint.Align.CENTER)
    }

    private fun drawSelector(c:Canvas){
        top(c,"CHOOSE DINO",true)
        text(c,"SWIPE LEFT / RIGHT",width/2f,dp(80f),13f,Color.WHITE,true,Paint.Align.CENTER)
        val center=width/2f; val offsets=listOf(-1,0,1)
        offsets.forEach{ off ->
            val idx=(selectorIndex+off+species.size)%species.size; val x=center+off*dp(105f); val scale=if(off==0)1.15f else .78f; val alpha=if(off==0)255 else 120
            drawEgg(c,x,dp(220f),dp(95f)*scale,dp(130f)*scale,false)
            drawDino(c,x,dp(215f),dp(105f)*scale,species[idx],1,alpha/255f)
            text(c,species[idx],x,dp(330f)+abs(off)*dp(12f),13f,Color.WHITE,true,Paint.Align.CENTER)
        }
        text(c,"Tap the front Dino to lock it in",center,dp(382f),12f,Color.WHITE,false,Paint.Align.CENTER)
        if(selectedLocked) button(c,dp(22f),dp(420f),width-dp(44f),dp(56f),"LOCKED IN • ${state.name}"){goHome()}
    }

    private fun drawEgg(c:Canvas,cx:Float,cy:Float,rx:Float,ry:Float,showDino:Boolean){
        paint.color=Color.argb(225,232,185,250);paint.style=Paint.Style.FILL;c.drawOval(cx-rx,cy-ry,cx+rx,cy+ry,paint)
        paint.color=Color.argb(160,255,255,255);c.drawOval(cx-rx*.55f,cy-ry*.78f,cx-rx*.18f,cy-ry*.18f,paint)
        paint.color=Color.argb(180,115,85,135);paint.style=Paint.Style.STROKE;paint.strokeWidth=dp(4f).toFloat();c.drawOval(cx-rx,cy-ry,cx+rx,cy+ry,paint);paint.style=Paint.Style.FILL
        if(showDino) drawDino(c,cx,cy+dp(4f),dp(130f),state.dinoType,1,1f)
    }

    private fun drawDino(c:Canvas,cx:Float,cy:Float,size:Float,id:String,stage:Int,alpha:Float){
        val res=frameRes(id,stage,1); val b=BitmapFactory.decodeResource(resources,res) ?: return
        val maxDim=maxOf(b.width,b.height).toFloat(); val scale=size/maxDim; val dw=b.width*scale; val dh=b.height*scale
        paint.alpha=(255*alpha).roundToInt(); val src=Rect(0,0,b.width,b.height); val dst=RectF(cx-dw/2,cy-dh/2,cx+dw/2,cy+dh/2); c.drawBitmap(b,src,dst,paint);paint.alpha=255
        paint.color=Color.argb((70*alpha).roundToInt(),30,25,15);paint.maskFilter=BlurMaskFilter(dp(4f).toFloat(),BlurMaskFilter.Blur.NORMAL);c.drawOval(cx-size*.32f,cy+size*.38f,cx+size*.32f,cy+size*.43f,paint);paint.maskFilter=null
    }

    private fun statPill(c:Canvas,x:Float,y:Float,label:String,value:Float,right:Boolean){
        val w=dp(120f);roundRect(c,x,y,w,dp(34f),Color.argb(210,255,250,231),dp(14f));text(c,label,x+dp(9f),y+dp(14f),9f,Color.rgb(67,52,33),true);roundRect(c,x+dp(8f),y+dp(20f),w-dp(16f),dp(7f),Color.LTGRAY,dp(4f));roundRect(c,x+dp(8f),y+dp(20f),(w-dp(16f))*(value/100f),dp(7f),if(value<25)Color.rgb(210,80,60) else Color.rgb(83,181,89),dp(4f))
    }

    private fun pill(c:Canvas,x:Float,y:Float,w:Float,h:Float,color:Int){roundRect(c,x,y,w,h,color,dp(18f))}
    private fun roundRect(c:Canvas,x:Float,y:Float,w:Float,h:Float,color:Int,r:Float){paint.color=color;paint.style=Paint.Style.FILL;c.drawRoundRect(x,y,x+w,y+h,r,r,paint)}
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,b:Boolean,align:Paint.Align=Paint.Align.LEFT){paint.typeface=if(b)bold else normal;paint.textSize=dp(size).toFloat();paint.color=color;paint.textAlign=align;paint.style=Paint.Style.FILL;c.drawText(s,x,y,paint)}
    private fun button(c:Canvas,x:Float,y:Float,w:Float,h:Float,label:String,small:Boolean=false,enabled:Boolean=true,onClick:()->Unit){roundRect(c,x,y,w,h,if(enabled)Color.rgb(67,145,77) else Color.rgb(105,105,105),dp(if(small)10f else 18f));text(c,label,x+w/2f,y+h/2f+dp(if(small)4f else 6f),if(small)10f else 14f,Color.WHITE,true,Paint.Align.CENTER)}

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selectorDownX = e.x
                selectorDragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (page == Page.SELECT && abs(e.x - selectorDownX) > dp(24f)) {
                    selectorDragging = true
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val x = e.x
                val y = e.y

                if (page == Page.SELECT && selectorDragging) {
                    if (x > selectorDownX) {
                        selectorIndex = (selectorIndex - 1 + species.size) % species.size
                    } else {
                        selectorIndex = (selectorIndex + 1) % species.size
                    }
                    invalidate()
                    return true
                }

                if (y < dp(60f) && x > width - dp(130f)) {
                    page = Page.SETTINGS
                    invalidate()
                    return true
                }

                when (page) {
                    Page.HOME -> {
                        when {
                            y >= dp(70f) && y <= dp(125f) && x > width - dp(140f) -> {
                                page = Page.SHOP
                            }
                            y >= dp(150f) && y <= dp(345f) && x >= dp(90f) && x <= width - dp(90f) -> {
                                page = Page.SELECT
                                selectedLocked = false
                            }
                            y >= dp(380f) && y <= dp(430f) -> {
                                (ctx as MainActivity).renameCompanion()
                            }
                            y >= dp(440f) && y <= dp(515f) && x < width / 3f -> {
                                page = Page.INVENTORY
                            }
                            y >= dp(440f) && y <= dp(515f) -> {
                                page = if (x > width * 2f / 3f) Page.EVOLVE else Page.CARE
                            }
                            y >= dp(515f) && y <= dp(590f) -> {
                                if (state.overlayVisible) {
                                    (ctx as MainActivity).hideDino()
                                } else {
                                    (ctx as MainActivity).spawnDino()
                                }
                            }
                        }
                        invalidate()
                    }
                    Page.INVENTORY -> {
                        if (y > dp(392f) && y < dp(690f)) {
                            showItemDialog()
                        }
                    }
                    Page.CARE -> {
                        when {
                            y >= dp(300f) && y <= dp(365f) -> page = Page.INVENTORY
                            y >= dp(370f) && y <= dp(435f) -> page = Page.PLAY
                            y >= dp(440f) && y <= dp(520f) -> careDialog()
                        }
                        invalidate()
                    }
                    Page.PLAY -> {
                        if (y > dp(300f) && y < dp(570f)) {
                            state.play()
                            state.coins += 5
                            Toast.makeText(ctx, "Great! +5 coins and a chance at an item", Toast.LENGTH_SHORT).show()
                            invalidate()
                        }
                    }
                    Page.EVOLVE -> {
                        if (y > dp(445f) && y < dp(525f) && state.canEvolve()) {
                            evolveNow()
                        }
                    }
                    Page.SHOP -> {
                        if (y > dp(100f) && y < dp(500f)) {
                            invalidate()
                        }
                    }
                    Page.SETTINGS -> Unit
                    Page.SELECT -> {
                        if (!selectorDragging && y > dp(120f) && y < dp(330f)) {
                            val chosen = species[selectorIndex]
                            state.dinoType = chosen
                            state.stage = 0
                            selectedLocked = true
                            (ctx as MainActivity).sendActiveChanged()
                            (ctx as MainActivity).renameCompanion()
                            invalidate()
                        }
                    }
                }
                return true
            }
        }
        return true
    }

    private fun showItemDialog(){
        AlertDialog.Builder(ctx).setTitle("APPLE").setMessage("Restores Hunger +10\nRarity: Standard\n\nAre you sure you want to use this?")
            .setPositiveButton("YES"){_,_->state.hunger=(state.hunger+10).coerceAtMost(100f);state.coins=maxOf(0,state.coins);invalidate()}
            .setNegativeButton("CLOSE",null).show()
    }
}
