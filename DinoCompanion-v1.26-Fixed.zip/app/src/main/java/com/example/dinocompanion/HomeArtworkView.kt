package com.example.dinocompanion

import android.content.Context
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Glossy dashboard artwork with a small dynamic text layer. The base illustration
 * remains intact, while the dinosaur name/species/stage and rename label are drawn
 * from DinoState so renaming immediately appears throughout the dashboard.
 */
class HomeArtworkView(
    context: Context,
    private val state: DinoState,
    private val onFoodCare: () -> Unit,
    private val onRename: () -> Unit,
    private val onChoose: () -> Unit,
    private val onOverlaySettings: () -> Unit,
    private val onShop: () -> Unit
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.home_reference)
    private val brown = Color.rgb(112, 70, 28)
    private val gold = Color.rgb(239, 177, 43)
    private val bluePatch = Color.argb(235, 26, 149, 235)
    private val skyPatch = Color.argb(225, 170, 220, 246)
    private val creamPatch = Color.argb(235, 255, 249, 226)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawBitmap(bitmap, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), paint)

        // Work in the artwork's original 1024 x 1536 coordinate system.
        canvas.save()
        canvas.scale(width / 1024f, height / 1536f)

        // Cover only the old baked-in labels, then paint current state values.
        paint.style = Paint.Style.FILL
        paint.color = skyPatch
        canvas.drawRoundRect(RectF(340f, 142f, 680f, 214f), 24f, 24f, paint)
        drawCentered(canvas, state.name, 510f, 192f, 49f, gold, true)

        paint.color = skyPatch
        canvas.drawRoundRect(RectF(250f, 211f, 775f, 270f), 22f, 22f, paint)
        drawCentered(canvas, "${state.dinoType} • Stage ${state.stage + 1}/4", 512f, 250f, 31f, brown, true)

        // Dynamic rename button label. The surrounding glossy button remains from
        // the artwork, only its old "RENAME REX" lettering is covered.
        paint.color = bluePatch
        canvas.drawOval(RectF(392f, 1040f, 635f, 1168f), paint)
        drawCentered(canvas, "RENAME", 513f, 1090f, 27f, Color.WHITE, true)
        drawCentered(canvas, state.name.uppercase(), 513f, 1128f, 24f, Color.WHITE, true)

        // Dynamic care sentence inside the existing cream panel.
        paint.color = creamPatch
        canvas.drawRoundRect(RectF(75f, 825f, 690f, 906f), 20f, 20f, paint)
        drawCentered(canvas, "Keep caring for ${state.name}.", 380f, 858f, 24f, brown, true)
        drawCentered(canvas, "The clock keeps running even when", 380f, 888f, 20f, brown, false)
        drawCentered(canvas, "the app is closed.", 380f, 913f, 20f, brown, false)

        canvas.restore()
    }

    private fun drawCentered(canvas: Canvas, text: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        paint.color = color
        paint.textSize = size
        paint.typeface = Typeface.create("sans-serif-rounded", if (bold) Typeface.BOLD else Typeface.NORMAL)
        paint.textAlign = Paint.Align.CENTER
        paint.style = Paint.Style.FILL
        canvas.drawText(text.take(28), x, y, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_UP || width <= 0 || height <= 0) return true

        val x = event.x / width.toFloat() * 1024f
        val y = event.y / height.toFloat() * 1536f
        fun hit(cx: Float, cy: Float, r: Float): Boolean = hypot(x - cx, y - cy) <= r

        when {
            hit(205f, 1058f, 145f) -> onFoodCare()
            hit(512f, 1058f, 145f) -> onRename()
            hit(817f, 1058f, 145f) -> onChoose()
            hit(360f, 1282f, 145f) -> onOverlaySettings()
            hit(666f, 1282f, 145f) -> onShop()
        }
        return true
    }
}
