package com.example.dinocompanion

import android.content.Context
import android.content.Intent

/**
 * Single source of truth for the currently active companion.  Both the activity
 * and the overlay service use the same preference file, so switching dinos is
 * immediately visible to the overlay even when the service stays alive.
 */
class DinoPreferences(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    init {
        migrateLegacyStateIfNeeded()
    }

    var activeDinoId: String
        get() = prefs.getString(KEY_ID, DEFAULT_ID) ?: DEFAULT_ID
        set(value) {
            prefs.edit().putString(KEY_ID, normalizeId(value)).apply()
            broadcastChanged()
        }

    var activeDinoStage: Int
        get() = prefs.getInt(KEY_STAGE, 0).coerceIn(0, 3)
        set(value) {
            prefs.edit().putInt(KEY_STAGE, value.coerceIn(0, 3)).apply()
            broadcastChanged()
        }

    var activeDinoName: String
        get() = prefs.getString(nameKey(activeDinoId), defaultName(activeDinoId)) ?: defaultName(activeDinoId)
        set(value) {
            val clean = value.trim().take(18)
            if (clean.isNotBlank()) {
                prefs.edit().putString(nameKey(activeDinoId), clean).apply()
                broadcastChanged()
            }
        }

    fun setActiveDino(id: String, stage: Int = 0) {
        val normalized = normalizeId(id)
        prefs.edit()
            .putString(KEY_ID, normalized)
            .putInt(KEY_STAGE, stage.coerceIn(0, 3))
            .apply()
        broadcastChanged()
    }

    fun snapshot(): Snapshot = Snapshot(activeDinoId, activeDinoName, activeDinoStage)

    private fun broadcastChanged() {
        appContext.sendBroadcast(
            Intent(ACTION_ACTIVE_DINO_CHANGED)
                .setPackage(appContext.packageName)
        )
    }


    private fun migrateLegacyStateIfNeeded() {
        if (prefs.getBoolean(KEY_MIGRATED, false)) return
        val legacy = appContext.getSharedPreferences("dino_state", Context.MODE_PRIVATE)
        val legacyId = legacy.getString("species", DEFAULT_ID) ?: DEFAULT_ID
        val normalized = normalizeId(legacyId)
        val legacyStage = legacy.getInt("stage", 0).coerceIn(0, 3)
        val legacyNameKey = "name_${legacyId.lowercase().replace("[^a-z0-9]+".toRegex(), "_")}"
        val legacyName = legacy.getString(legacyNameKey, defaultName(normalized)) ?: defaultName(normalized)
        prefs.edit()
            .putString(KEY_ID, normalized)
            .putInt(KEY_STAGE, legacyStage)
            .putString(nameKey(normalized), legacyName)
            .putBoolean(KEY_MIGRATED, true)
            .apply()
    }

    private fun nameKey(id: String) = "name_${normalizeId(id).lowercase()}"

    private fun normalizeId(id: String): String = when (id.lowercase()) {
        "trex", "t-rex" -> "T-Rex"
        "triceratops" -> "Triceratops"
        "pterodactyl" -> "Pterodactyl"
        "stegosaurus" -> "Stegosaurus"
        else -> DEFAULT_ID
    }

    private fun defaultName(id: String): String = when (normalizeId(id)) {
        "T-Rex" -> "Rex"
        "Triceratops" -> "Trixie"
        "Pterodactyl" -> "Sky"
        "Stegosaurus" -> "Steggy"
        else -> "Rex"
    }

    data class Snapshot(val id: String, val name: String, val stage: Int)

    companion object {
        const val ACTION_ACTIVE_DINO_CHANGED = "com.example.dinocompanion.ACTIVE_DINO_CHANGED"
        private const val FILE = "dino_preferences"
        private const val KEY_ID = "active_dino_id"
        private const val KEY_STAGE = "active_dino_stage"
        private const val DEFAULT_ID = "T-Rex"
        private const val KEY_MIGRATED = "legacy_state_migrated"
    }
}
