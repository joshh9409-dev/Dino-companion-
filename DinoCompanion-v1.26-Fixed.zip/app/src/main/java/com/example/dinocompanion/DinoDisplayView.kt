package com.example.dinocompanion

import android.animation.ObjectAnimator
import android.content.Context
import android.view.LayoutInflater
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

/**
 * Small floating companion. The WindowManager owns the screen position; this view
 * never changes it. Only the dinosaur artwork animates in place.
 */
class DinoDisplayView(
    context: Context,
    private val state: DinoState,
    private val compact: Boolean = false,
    private val homeMode: Boolean = false,
    private val onAction: ((String) -> Unit)? = null,
    private val onDragPosition: ((Float, Float) -> Unit)? = null,
    private val onOpenMenu: (() -> Unit)? = null,
    private val onHide: (() -> Unit)? = null
) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * density).toInt()

    private val shadowPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(78, 35, 25, 15)
        maskFilter = android.graphics.BlurMaskFilter(dp(4f).toFloat(), android.graphics.BlurMaskFilter.Blur.NORMAL)
    }

    private lateinit var imageView: ImageView

    private lateinit var controls: View

    private var animation: AnimationDrawable? = null
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var idleScaleX: ObjectAnimator? = null
    private var idleScaleY: ObjectAnimator? = null
    private var hardwareState = HardwareState.NORMAL
    private var breathingGeneration = 0

    init {
        setWillNotDraw(false)
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
        isFocusable = true
        clipChildren = false
        clipToPadding = false

        // This XML is deliberately isolated from the main dashboard. It contains
        // only the sprite and the tiny overlay menu, so dashboard TextViews can
        // never leak into the floating window.
        LayoutInflater.from(context).inflate(R.layout.overlay_dino, this, true)
        imageView = findViewById(R.id.overlay_dino_image)
        controls = findViewById(R.id.overlay_menu)

        findViewById<View>(R.id.overlay_menu_button).setOnClickListener {
            onOpenMenu?.invoke()
            hideControls()
        }
        findViewById<View>(R.id.overlay_hide_button).setOnClickListener {
            hideControls()
            onHide?.invoke()
        }
        findViewById<View>(R.id.overlay_info_button).setOnClickListener {
            showStatus()
        }

        imageView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        setDinoAnimation()
        startIdleBreathing()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        // Draw the contact shadow inside the isolated overlay itself. This avoids
        // another view and keeps the shadow anchored to the sprite's feet.
        val cx = dp(58f)
        val cy = dp(116f)
        canvas.drawOval(
            cx - dp(35f).toFloat(),
            cy - dp(4f).toFloat(),
            cx + dp(35f).toFloat(),
            cy + dp(4f).toFloat(),
            shadowPaint
        )
        super.onDraw(canvas)
    }

    private fun stageNumber(): Int = (state.stage + 1).coerceIn(1, 4)

    private fun currentDinoType(): String = state.dinoType

    private fun frameIds(species: String, stage: Int): IntArray {
        val s = stage.coerceIn(1, 4)
        return when (species.lowercase()) {
            "t-rex", "trex" -> when (s) {
                1 -> intArrayOf(R.drawable.trex_stage1_f1, R.drawable.trex_stage1_f2, R.drawable.trex_stage1_f3)
                2 -> intArrayOf(R.drawable.trex_stage2_f1, R.drawable.trex_stage2_f2, R.drawable.trex_stage2_f3)
                3 -> intArrayOf(R.drawable.trex_stage3_f1, R.drawable.trex_stage3_f2, R.drawable.trex_stage3_f3)
                else -> intArrayOf(R.drawable.trex_stage4_f1, R.drawable.trex_stage4_f2, R.drawable.trex_stage4_f3)
            }
            "triceratops" -> when (s) {
                1 -> intArrayOf(R.drawable.triceratops_stage1_f1, R.drawable.triceratops_stage1_f2, R.drawable.triceratops_stage1_f3)
                2 -> intArrayOf(R.drawable.triceratops_stage2_f1, R.drawable.triceratops_stage2_f2, R.drawable.triceratops_stage2_f3)
                3 -> intArrayOf(R.drawable.triceratops_stage3_f1, R.drawable.triceratops_stage3_f2, R.drawable.triceratops_stage3_f3)
                else -> intArrayOf(R.drawable.triceratops_stage4_f1, R.drawable.triceratops_stage4_f2, R.drawable.triceratops_stage4_f3)
            }
            "pterodactyl" -> when (s) {
                1 -> intArrayOf(R.drawable.pterodactyl_stage1_f1, R.drawable.pterodactyl_stage1_f2, R.drawable.pterodactyl_stage1_f3)
                2 -> intArrayOf(R.drawable.pterodactyl_stage2_f1, R.drawable.pterodactyl_stage2_f2, R.drawable.pterodactyl_stage2_f3)
                3 -> intArrayOf(R.drawable.pterodactyl_stage3_f1, R.drawable.pterodactyl_stage3_f2, R.drawable.pterodactyl_stage3_f3)
                else -> intArrayOf(R.drawable.pterodactyl_stage4_f1, R.drawable.pterodactyl_stage4_f2, R.drawable.pterodactyl_stage4_f3)
            }
            else -> when (s) {
                1 -> intArrayOf(R.drawable.stegosaurus_stage1_f1, R.drawable.stegosaurus_stage1_f2, R.drawable.stegosaurus_stage1_f3)
                2 -> intArrayOf(R.drawable.stegosaurus_stage2_f1, R.drawable.stegosaurus_stage2_f2, R.drawable.stegosaurus_stage2_f3)
                3 -> intArrayOf(R.drawable.stegosaurus_stage3_f1, R.drawable.stegosaurus_stage3_f2, R.drawable.stegosaurus_stage3_f3)
                else -> intArrayOf(R.drawable.stegosaurus_stage4_f1, R.drawable.stegosaurus_stage4_f2, R.drawable.stegosaurus_stage4_f3)
            }
        }
    }

    private fun setDinoAnimation() {
        animation?.stop()
        val stage = stageNumber()
        val next = AnimationDrawable().apply {
            isOneShot = false
            frameIds(currentDinoType(), stage).forEach { id ->
                val drawable = resources.getDrawable(id, null)
                if (drawable is BitmapDrawable) {
                    drawable.paint.isAntiAlias = true
                    drawable.paint.isFilterBitmap = true
                    drawable.paint.isDither = true
                }
                // Deliberately slow frame cadence. The frames are used for a gentle
                // tail/body wag, not rapid facial twitching.
                addFrame(drawable, DinoBehaviors.forStage(stage).frameMs.toInt())
            }
        }
        animation = next
        imageView.setImageDrawable(next)
        imageView.animate().cancel()
        imageView.translationX = 0f
        imageView.translationY = 0f
        imageView.rotation = 0f
        imageView.scaleX = 1f
        imageView.scaleY = 1f
        imageView.pivotX = imageView.width / 2f
        imageView.pivotY = imageView.height.toFloat() * .88f
        next.start()
        resizeDinoForStage(stage)
        startIdleBreathing()
    }

    private fun resizeDinoForStage(stage: Int) {
        val size = when (stage) {
            1 -> 82
            2 -> 94
            3 -> 104
            else -> 114
        }
        val lp = (imageView.layoutParams as? FrameLayout.LayoutParams)
            ?: FrameLayout.LayoutParams(dp(size.toFloat()), dp(size.toFloat()))
        lp.width = dp(size.toFloat())
        lp.height = dp(size.toFloat())
        lp.leftMargin = dp(6f)
        lp.topMargin = dp((116 - size).coerceAtLeast(2).toFloat())
        imageView.layoutParams = lp
        imageView.pivotX = imageView.width / 2f
        imageView.pivotY = imageView.height.toFloat() * .88f
    }

    private fun startIdleBreathing() {
        idleScaleX?.cancel()
        idleScaleY?.cancel()
        breathingGeneration++
        val generation = breathingGeneration
        val behavior = DinoBehaviors.forStage(stageNumber())
        val amount = if (hardwareState == HardwareState.SLEEPING) 0.012f else behavior.breathAmount
        val duration = if (hardwareState == HardwareState.SLEEPING) 4600L else behavior.breathMs
        val base = if (hardwareState == HardwareState.SLEEPING) 0.94f else 1f
        imageView.animate().cancel()
        imageView.rotation = if (hardwareState == HardwareState.SLEEPING) -3f else 0f
        imageView.scaleX = base
        imageView.scaleY = base
        val x = ObjectAnimator.ofFloat(imageView, View.SCALE_X, base, base + amount).apply {
            this.duration = duration
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        val y = ObjectAnimator.ofFloat(imageView, View.SCALE_Y, base, base + amount * 0.96f).apply {
            this.duration = duration
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        idleScaleX = x
        idleScaleY = y
        if (generation == breathingGeneration) {
            x.start()
            y.start()
        }
    }

    enum class HardwareState { NORMAL, SLEEPING, DIZZY }

    fun setHardwareState(newState: HardwareState) {
        if (hardwareState == newState) return
        hardwareState = newState
        when (newState) {
            HardwareState.SLEEPING -> {
                hideControls()
                animation?.stop()
                startIdleBreathing()
                onAction?.invoke("Sleeping")
            }
            HardwareState.DIZZY -> {
                idleScaleX?.cancel()
                idleScaleY?.cancel()
                imageView.animate().cancel()
                imageView.animate()
                    .rotationBy(14f)
                    .scaleX(1.07f)
                    .scaleY(0.95f)
                    .setDuration(260L)
                    .withEndAction {
                        imageView.animate()
                            .rotationBy(-28f)
                            .setDuration(520L)
                            .withEndAction {
                                imageView.animate().rotation(0f).scaleX(1f).scaleY(1f)
                                    .setDuration(420L)
                                    .withEndAction { setHardwareState(HardwareState.NORMAL) }
                                    .start()
                            }.start()
                    }.start()
                onAction?.invoke("Dizzy")
            }
            HardwareState.NORMAL -> {
                setDinoAnimation()
                startIdleBreathing()
            }
        }
    }

    fun refresh() {
        val currentTag = "${currentDinoType()}:${stageNumber()}"
        if (imageView.tag != currentTag) {
            imageView.tag = currentTag
            setDinoAnimation()
        }
        animation?.let { if (!it.isRunning) it.start() }
    }

    /** Reactions animate the body only. They never change the WindowManager X/Y anchor. */
    /** Reactions animate only the sprite. WindowManager X/Y is never touched. */
    fun showAction(action: String, showStats: Boolean = true) {
        state.currentAction = action
        val behavior = DinoBehaviors.forStage(stageNumber())
        if (hardwareState != HardwareState.NORMAL) return
        idleScaleX?.cancel()
        idleScaleY?.cancel()
        imageView.animate().cancel()
        val duration = (260L + stageNumber() * 25L)
        when {
            action.contains("Pet", true) || action.contains("petted", true) || action == behavior.tapAction ->
                imageView.animate().scaleX(behavior.tapScale).scaleY(behavior.tapScale)
                    .setDuration(duration)
                    .withEndAction { imageView.animate().scaleX(1f).scaleY(1f).setDuration(650L).start() }.start()
            action.contains("Eat", true) || action.contains("Eating", true) ->
                imageView.animate().scaleX(behavior.doubleTapScale).scaleY(.985f)
                    .setDuration(duration + 40L)
                    .withEndAction { imageView.animate().scaleX(1f).scaleY(1f).setDuration(700L).start() }.start()
            action.contains("Play", true) ->
                imageView.animate().rotation(2.5f).scaleX(1.03f).scaleY(1.03f).setDuration(360L)
                    .withEndAction { imageView.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(700L).start() }.start()
            else -> startIdleBreathing()
        }
        postDelayed({ if (hardwareState == HardwareState.NORMAL) startIdleBreathing() }, if (showStats) 2200L else 2800L)
        onAction?.invoke(action)
    }

    private fun showStatus() {
        Toast.makeText(
            context,
            "${state.name} • Happy ${state.happiness.toInt()}% • Hunger ${state.hunger.toInt()}% • Thirst ${state.thirst.toInt()}% • Energy ${state.energy.toInt()}% • Health ${state.health.toInt()}% • Bond ${state.bond.toInt()}%",
            Toast.LENGTH_LONG
        ).show()
        hideControls()
    }

    private fun hideControls() {
        controls.animate().cancel()
        controls.animate().alpha(0f).setDuration(90).withEndAction {
            controls.visibility = GONE
        }.start()
    }

    private fun revealControls() {
        controls.visibility = VISIBLE
        controls.animate().cancel()
        controls.animate().alpha(1f).setDuration(130).start()
    }

    private fun controlsContains(x: Float, y: Float): Boolean {
        return controls.visibility == VISIBLE && x >= controls.left && x <= controls.right &&
            y >= controls.top && y <= controls.bottom
    }

    private fun dinoContains(x: Float, y: Float): Boolean {
        return x >= imageView.left - dp(8f) && x <= imageView.right + dp(8f) &&
            y >= imageView.top - dp(8f) && y <= imageView.bottom + dp(8f)
    }

    override fun onDetachedFromWindow() {
        idleScaleX?.cancel()
        idleScaleY?.cancel()
        idleScaleX = null
        idleScaleY = null
        animation?.stop()
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragging && hypot(dx.toDouble(), dy.toDouble()) > dp(7f)) dragging = true
                if (dragging) onDragPosition?.invoke(dx, dy)
                return true
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (dragging) return true

                val x = event.x
                val y = event.y
                if (controlsContains(x, y)) return true

                if (!dinoContains(x, y)) {
                    // Any tap on the transparent area of the compact overlay dismisses
                    // the menu immediately. It never opens a fullscreen popup.
                    if (controls.visibility == VISIBLE) hideControls()
                    return true
                }

                revealControls()
                val now = System.currentTimeMillis()
                if (now - lastTap < 700L) {
                    state.feed(20f)
                    showAction("Eating", false)
                } else {
                    state.pet()
                    showAction(DinoBehaviors.forStage(stageNumber()).tapAction, false)
                }
                lastTap = now
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }
}
