package com.example.dinocompanion

/**
 * Behaviour changes with evolution. Stage is 1-based here.
 * Timings are intentionally calm so the companion feels alive without twitching.
 */
data class DinoBehavior(
    val frameMs: Long,
    val breathMs: Long,
    val breathAmount: Float,
    val tapScale: Float,
    val doubleTapScale: Float,
    val tapAction: String,
    val idleAction: String
)

object DinoBehaviors {
    fun forStage(stage: Int): DinoBehavior = when (stage.coerceIn(1, 4)) {
        1 -> DinoBehavior(1800L, 3600L, 0.020f, 1.025f, 1.035f, "Happy little wiggle", "Watching")
        2 -> DinoBehavior(1450L, 3300L, 0.022f, 1.035f, 1.045f, "Juvenile bounce", "Curious")
        3 -> DinoBehavior(1150L, 3000L, 0.024f, 1.045f, 1.055f, "Young dino reacts", "Alert")
        else -> DinoBehavior(950L, 2700L, 0.026f, 1.055f, 1.065f, "Adult dino reacts", "Guarding")
    }
}
