# Dino Companion 1.23

New base design and functional flow based on the agreed Dino Companion home, inventory, food & care, play, evolve, shop, selection and floating-overlay concepts.

- Four Baby dinos: T-Rex, Triceratops, Pterodactyl, Stegosaurus.
- Egg character carousel: swipe left/right, front Dino is larger, tap front to lock it in.
- Species-specific chosen names with rename popup.
- Home: evolution progress + Shop + Settings, six stats, Inventory / Food & Care / Evolve, Spawn/Hide Dino.
- Inventory: items, rarity tiers, confirmation popup, stat explanations foundation.
- Food & Care: Feed -> Food inventory, Play -> three mini-games, Care -> automatic Wash / Sleep / Doctor.
- Play: Bubble Pop, Catch the Food, Fruit Toss foundation with coin rewards.
- Evolve: Baby -> Juvenile -> Young -> Adult, locked silhouettes, requirements and evolve animation flow.
- Shop: coins plus premium-only cosmetic Legendary item concept.
- Overlay retains the existing floating companion service, saved position, battery/keyboard/fold/shake handling and compact MENU/HIDE/INFO controls.
