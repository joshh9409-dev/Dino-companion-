package com.example.dinocompanion

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.hypot

/**
 * Small, full-body floating companion.
 * The artwork itself is transparent. Three frames loop continuously so the
 * head, eyes and tail have subtle life instead of looking like one dead PNG.
 */
class DinoDisplayView(
    context: Context,
    private val state: DinoState,
    private val compact: Boolean = false,
    private val homeMode: Boolean = false,
    private val onAction: ((String) -> Unit)? = null,
    private val onDragPosition: ((Float, Float) -> Unit)? = null
) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Int = (v * density).toInt()

    private val imageView = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        adjustViewBounds = true
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = false
        isFocusable = false
        // Keep the dinosaur's feet visually planted at the bottom of the overlay.
        pivotX = 0.5f
        pivotY = 1f
    }

    private var animation: AnimationDrawable? = null
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var actionReset: Runnable? = null

    init {
        setWillNotDraw(true)
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
        isFocusable = true

        // Deliberately compact. The dinosaur should feel like a companion,
        // not a giant sticker covering the app underneath it.
        val imageW = if (compact) dp(100f) else dp(135f)
        val imageH = if (compact) dp(118f) else dp(155f)
        addView(imageView, LayoutParams(imageW, imageH).apply {
            gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
            bottomMargin = 0
        })
        setDinoAnimation()
    }

    private fun stageNumber(): Int = (state.stage + 1).coerceIn(1, 4)

    private fun frameIds(species: String, stage: Int): IntArray {
        val s = stage.coerceIn(1, 4)
        return when (species.lowercase()) {
            "t-rex", "trex" -> when (s) {
                1 -> intArrayOf(R.drawable.trex_stage1_f1, R.drawable.trex_stage1_f2, R.drawable.trex_stage1_f3)
                2 -> intArrayOf(R.drawable.trex_stage2_f1, R.drawable.trex_stage2_f2, R.drawable.trex_stage2_f3)
                3 -> intArrayOf(R.drawable.trex_stage3_f1, R.drawable.trex_stage3_f2, R.drawable.trex_stage3_f3)
                else -> intArrayOf(R.drawable.trex_stage4_f1, R.drawable.trex_stage4_f2, R.drawable.trex_stage4_f3)
            }
            "triceratops" -> when (s) {
                1 -> intArrayOf(R.drawable.triceratops_stage1_f1, R.drawable.triceratops_stage1_f2, R.drawable.triceratops_stage1_f3)
                2 -> intArrayOf(R.drawable.triceratops_stage2_f1, R.drawable.triceratops_stage2_f2, R.drawable.triceratops_stage2_f3)
                3 -> intArrayOf(R.drawable.triceratops_stage3_f1, R.drawable.triceratops_stage3_f2, R.drawable.triceratops_stage3_f3)
                else -> intArrayOf(R.drawable.triceratops_stage4_f1, R.drawable.triceratops_stage4_f2, R.drawable.triceratops_stage4_f3)
            }
            "pterodactyl" -> when (s) {
                1 -> intArrayOf(R.drawable.pterodactyl_stage1_f1, R.drawable.pterodactyl_stage1_f2, R.drawable.pterodactyl_stage1_f3)
                2 -> intArrayOf(R.drawable.pterodactyl_stage2_f1, R.drawable.pterodactyl_stage2_f2, R.drawable.pterodactyl_stage2_f3)
                3 -> intArrayOf(R.drawable.pterodactyl_stage3_f1, R.drawable.pterodactyl_stage3_f2, R.drawable.pterodactyl_stage3_f3)
                else -> intArrayOf(R.drawable.pterodactyl_stage4_f1, R.drawable.pterodactyl_stage4_f2, R.drawable.pterodactyl_stage4_f3)
            }
            "stegosaurus" -> when (s) {
                1 -> intArrayOf(R.drawable.stegosaurus_stage1_f1, R.drawable.stegosaurus_stage1_f2, R.drawable.stegosaurus_stage1_f3)
                2 -> intArrayOf(R.drawable.stegosaurus_stage2_f1, R.drawable.stegosaurus_stage2_f2, R.drawable.stegosaurus_stage2_f3)
                3 -> intArrayOf(R.drawable.stegosaurus_stage3_f1, R.drawable.stegosaurus_stage3_f2, R.drawable.stegosaurus_stage3_f3)
                else -> intArrayOf(R.drawable.stegosaurus_stage4_f1, R.drawable.stegosaurus_stage4_f2, R.drawable.stegosaurus_stage4_f3)
            }
            else -> intArrayOf(R.drawable.trex_stage1_f1, R.drawable.trex_stage1_f2, R.drawable.trex_stage1_f3)
        }
    }

    private fun setDinoAnimation() {
        animation?.stop()
        val next = AnimationDrawable().apply {
            isOneShot = false
            frameIds(state.species, stageNumber()).forEach { id ->
                addFrame(resources.getDrawable(id, null), 210)
            }
        }
        animation = next
        imageView.setImageDrawable(next)
        next.start()
    }

    fun refresh() {
        val currentTag = "${state.species}:${stageNumber()}"
        if (imageView.tag != currentTag) {
            imageView.tag = currentTag
            setDinoAnimation()
        }
        animation?.let { if (!it.isRunning) it.start() }
    }

    fun showAction(action: String, showStats: Boolean = true) {
        state.currentAction = action
        val anim = animation ?: return
        for (i in 0 until anim.numberOfFrames) anim.setDuration(i, 125)

        imageView.animate().cancel()
        when {
            action.contains("Pet", true) || action.contains("petted", true) -> {
                imageView.animate().rotation(-3f).translationY(-dp(4f)).setDuration(120).withEndAction {
                    imageView.animate().rotation(0f).translationY(0f).setDuration(220).start()
                }.start()
            }
            action.contains("Eat", true) || action.contains("Eating", true) -> {
                imageView.animate().scaleX(1.05f).scaleY(1.05f).setDuration(120).withEndAction {
                    imageView.animate().scaleX(1f).scaleY(1f).setDuration(220).start()
                }.start()
            }
            action.contains("Play", true) || action.contains("Moving", true) -> {
                imageView.animate().rotation(3f).setDuration(110).withEndAction {
                    imageView.animate().rotation(0f).setDuration(180).start()
                }.start()
            }
        }
        actionReset?.let { removeCallbacks(it) }
        actionReset = Runnable {
            animation?.let { a -> for (i in 0 until a.numberOfFrames) a.setDuration(i, 210) }
            state.currentAction = ""
        }
        postDelayed(actionReset!!, 1800L)
        onAction?.invoke(action)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragging && hypot(dx.toDouble(), dy.toDouble()) > dp(7f)) dragging = true
                if (dragging) {
                    onDragPosition?.invoke(dx, dy)
                    showAction("Moving me", false)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (dragging) return true
                val now = System.currentTimeMillis()
                if (now - lastTap < 420L) {
                    state.feed(20f)
                    showAction("Eating", false)
                } else {
                    state.pet()
                    showAction("Being petted", false)
                }
                lastTap = now
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }
}
